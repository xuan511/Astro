#include "../src/api.hpp"
#include <cassert>
#include <iostream>
int main() {
    using namespace qt;
    ApiConfig c;
    c.key = "fixture-only";
    assert(
        Parser(translationBody(c, "hello")).parse().at("stream_options").at("include_usage").text ==
        "true");
    c.includeUsage = false;
    assert(!Parser(translationBody(c, "hello")).parse().object.count("stream_options"));
    c.includeUsage = true;
    c.stream = false;
    assert(!Parser(translationBody(c, "hello")).parse().object.count("stream_options"));
    auto parse = [](const std::string &s) { return ApiUsage::fromResponse(Parser(s).parse()); };
    assert(!parse("{}").any() && !parse("{\"usage\":null}").any());
    auto u = parse(
        R"({"usage":{"input_tokens":22,"output_tokens":7,"input_tokens_details":{"cached_tokens":10}}})");
    assert(u.full() && u.total == 29 && u.cached == 10);
    for (auto body : {R"({"usage":{"prompt_tokens":-1}})", R"({"usage":{"prompt_tokens":"42"}})",
                      R"({"usage":{"prompt_tokens":20,"completion_tokens":3,"total_tokens":99}})",
                      R"({"usage":{"prompt_tokens":20,"completion_tokens":3,"cached_tokens":21}})"})
        assert(parse(body).invalid);
    unsigned events = 0;
    ApiUsage observed;
    auto callback = [&](const ApiUsage &v) {
        ++events;
        observed = v;
    };
    auto translated = completion(
        R"({"choices":[{"message":{"content":"译文"},"finish_reason":"stop"}],"usage":{"prompt_tokens":40,"completion_tokens":10,"total_tokens":50}})",
        callback);
    assert(translated == "译文" && events == 1 && observed.total == 50);
    bool error = false;
    try {
        completion(
            R"({"choices":[{"message":{"content":"部分"},"finish_reason":"length"}],"usage":{"prompt_tokens":40,"completion_tokens":10,"total_tokens":50}})",
            callback);
    } catch (...) {
        error = true;
    }
    assert(error && events == 2 && observed.total == 50);
    std::string text =
        "data: {\"choices\":[{\"delta\":{\"content\":\"译文\"},\"finish_reason\":\"stop\"}]}\n\n";
    text += "data: "
            "{\"choices\":[],\"usage\":{\"prompt_tokens\":40,\"completion_tokens\":10,\"total_"
            "tokens\":50}}\n\ndata: [DONE]\n\n";
    for (size_t fragment = 1; fragment < 70; ++fragment) {
        events = 0;
        ApiStream parser(false, [](const auto &) {}, callback);
        for (size_t p = 0; p < text.size(); p += fragment)
            parser.feed(text.data() + p, std::min(fragment, text.size() - p));
        assert(parser.finish() == "译文" && parser.complete() && events == 1 &&
               observed.total == 50);
    }
    events = 0;
    std::string noUsage = "data: "
                          "{\"choices\":[{\"delta\":{\"content\":\"ok\"},\"finish_reason\":"
                          "\"stop\"}]}\n\ndata: [DONE]\n\n";
    ApiStream missing(false, [](const auto &) {}, callback);
    missing.feed(noUsage.data(), noUsage.size());
    assert(missing.finish() == "ok" && events == 0);
    auto invalidText = completion(
        R"({"choices":[{"message":{"content":"still works"},"finish_reason":"stop"}],"usage":{"prompt_tokens":"invalid"}})",
        callback);
    assert(invalidText == "still works" && observed.invalid);
    auto max = parse(
        R"({"usage":{"prompt_tokens":100000000,"completion_tokens":100000000,"total_tokens":200000000}})");
    assert(max.full() && ApiUsage::parse(Parser(max.json()).parse()).full());
    std::cout << "PASS API usage: stream include_usage compatibility toggle, JSON and fragmented "
                 "SSE terminal usage, counts before truncated completion errors, aliases/cache "
                 "subset, missing vs invalid, no token estimation\n";
}
