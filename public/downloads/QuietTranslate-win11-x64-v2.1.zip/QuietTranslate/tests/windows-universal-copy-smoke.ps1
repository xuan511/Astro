﻿param([string]$Exe=(Join-Path $PSScriptRoot '..\QuietTranslate.exe'),[switch]$AllowInputAndClipboardChanges,[switch]$AllowSkip)
$ErrorActionPreference='Stop'
if(-not $AllowInputAndClipboardChanges){Write-Warning 'SKIP: this controlled test sends Ctrl+Insert to its OWN fixture and changes current clipboard. Explicit opt-in required.';exit 0}
$Exe=(Resolve-Path $Exe).Path
# Run in built-in Windows PowerShell 5.1: creates a temporary .NET Framework Windows fixture EXE.
# A generic custom control deliberately avoids the native Edit/RichEdit/Scintilla adapter.
$fixture=Join-Path ([IO.Path]::GetTempPath()) ('QuietTranslate-CopyFixture-'+[guid]::NewGuid().ToString('N')+'.exe')
$fixtureProcess=$null;$worker=$null
try{
Add-Type -OutputAssembly $fixture -OutputType WindowsApplication -ReferencedAssemblies System.Windows.Forms,System.Drawing -TypeDefinition @'
using System;
using System.Drawing;
using System.Windows.Forms;
public sealed class CopyBox:Control {
    public CopyBox(){SetStyle(ControlStyles.Selectable,true);TabStop=true;AccessibleName="Controlled copy test";}
    protected override void OnPaint(PaintEventArgs e){e.Graphics.DrawString("Public fixture: alpha beta (copies only these words)",SystemFonts.DefaultFont,Brushes.Black,10,10);}
    protected override void OnKeyDown(KeyEventArgs e){
        if(e.KeyCode==Keys.Insert && e.Control && !e.Shift && !e.Alt){Clipboard.SetText("alpha beta");e.Handled=true;}
        else if(e.KeyCode==Keys.Insert || e.KeyCode==Keys.C || e.KeyCode==Keys.V || e.KeyCode==Keys.X){Environment.Exit(99);}
        base.OnKeyDown(e);
    }
}
public static class ControlledCopyProgram {
    [STAThread]public static void Main(){
        var form=new Form();form.Width=620;form.Height=220;form.TopMost=true;form.Text="QuietTranslate - controlled universal copy test";
        var box=new CopyBox();box.Dock=DockStyle.Fill;form.Controls.Add(box);
        form.Shown+=delegate{form.BeginInvoke((MethodInvoker)delegate{form.Activate();box.Focus();Console.WriteLine(form.Handle.ToInt64());Console.Out.Flush();});};
        Application.Run(form);
    }
}
'@
Add-Type -TypeDefinition @'
using System;using System.Runtime.InteropServices;
public static class CopyTestState {
 [DllImport("user32.dll")]public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")]public static extern short GetAsyncKeyState(int key);
}
'@
    $info=New-Object Diagnostics.ProcessStartInfo;$info.FileName=$fixture;$info.UseShellExecute=$false;$info.RedirectStandardOutput=$true
    $fixtureProcess=New-Object Diagnostics.Process;$fixtureProcess.StartInfo=$info;[void]$fixtureProcess.Start()
    $ready=$fixtureProcess.StandardOutput.ReadLineAsync()
    if(-not $ready.Wait(6000)){throw 'Fixture startup timeout'}
    [long]$target=$ready.GetAwaiter().GetResult()
    if([CopyTestState]::GetForegroundWindow().ToInt64() -ne $target){if($AllowSkip){Write-Warning 'SKIP: no foreground desktop. No copy keys sent; universal copy NOT verified.';exit 0};throw 'Foreground fixture required'}
    $info=New-Object Diagnostics.ProcessStartInfo;$info.FileName=$Exe;$info.Arguments="--capture-universal $target"
    $info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true
    $worker=New-Object Diagnostics.Process;$worker.StartInfo=$info;$memory=New-Object IO.MemoryStream
    [void]$worker.Start();$reader=$worker.StandardOutput.BaseStream.CopyToAsync($memory)
    if(-not $worker.WaitForExit(10000)){throw 'Universal copy worker timeout'}
    $reader.GetAwaiter().GetResult();$raw=$memory.ToArray();$offset=0;$source=$null;$route=$null;$failure=$null
    while($offset -lt $raw.Length){
        if($raw.Length-$offset -lt 8){throw 'Truncated frame'}
        $type=[BitConverter]::ToUInt32($raw,$offset);$len=[BitConverter]::ToUInt32($raw,$offset+4);$offset+=8
        if($len -gt 65536 -or $offset+$len -gt $raw.Length){throw 'Invalid frame'}
        $value=[Text.Encoding]::UTF8.GetString($raw,$offset,$len);$offset+=$len
        if($type -eq 1){$source=$value}elseif($type -eq 6){$route=$value}elseif($type -eq 3){$failure=$value}else{throw 'Unexpected frame'}
    }
    if($source -ne 'alpha beta' -or $route -notmatch 'Ctrl\+Insert'){throw "Universal copy failed: $failure"}
    if([CopyTestState]::GetAsyncKeyState(0x11) -band 0x8000){throw 'Ctrl remained down'}
    if([CopyTestState]::GetAsyncKeyState(0x2d) -band 0x8000){throw 'Insert remained down'}
    if($fixtureProcess.HasExited){throw "Fixture exited unexpectedly: $($fixtureProcess.ExitCode)"}
    Write-Output 'PASS: actual SendInput Ctrl+Insert to owned generic control, fresh target-owned clipboard text, balanced key release. No real editor/browser/Office/PDF tested.'
}finally{
    if($worker){if(-not $worker.HasExited){$worker.Kill()};$worker.Dispose()}
    if($fixtureProcess){if(-not $fixtureProcess.HasExited){[void]$fixtureProcess.CloseMainWindow();if(-not $fixtureProcess.WaitForExit(1000)){$fixtureProcess.Kill()}};$fixtureProcess.Dispose()}
    if(Test-Path $fixture){Remove-Item -LiteralPath $fixture -Force}
}
