param([string]$Exe = (Join-Path $PSScriptRoot '..\QuietTranslate.OCR.exe'))
$ErrorActionPreference = 'Stop'
$info = New-Object Diagnostics.ProcessStartInfo
$info.FileName = (Resolve-Path $Exe).Path
$info.Arguments = '--self-test'
$info.UseShellExecute = $false
$info.CreateNoWindow = $true
$info.RedirectStandardOutput = $true
$info.RedirectStandardError = $true
$p = New-Object Diagnostics.Process
$p.StartInfo = $info
try {
    [void]$p.Start()
    $read = $p.StandardOutput.ReadToEndAsync()
    $err = $p.StandardError.ReadToEndAsync()
    if (-not $p.WaitForExit(25000)) { $p.Kill(); throw 'OCR fixture timeout' }
    $output = $read.GetAwaiter().GetResult()
    [void]$err.GetAwaiter().GetResult()
    if ($p.ExitCode -ne 0 -or $output -notmatch 'PASS Windows OCR Tesseract/model') { throw 'Actual Windows OCR fixed fixture failed; no real screen was captured' }
    Write-Output 'PASS: actual helper/model recognizes an in-memory GDI-rendered public English sample; no screen, clipboard, user files or network. This does not test interactive region selection.'
} finally { if (-not $p.HasExited) { $p.Kill() }; $p.Dispose() }
