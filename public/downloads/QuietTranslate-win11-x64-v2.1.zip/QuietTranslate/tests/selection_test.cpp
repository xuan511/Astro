#include "../src/selection.hpp"
#include <cassert>
#include <iostream>
#include <random>
#include <vector>
int main() {
    auto check = [](const std::u16string &input) {
        return qt::copiedText(input.c_str(), input.size() + 1);
    };
    assert(check(u"alpha beta") == u"alpha beta");
    assert(check(u"English 中文 😀") == u"English 中文 😀");
    assert(check(std::u16string(4000, u'x')).size() == 4000);
    bool rejected = false;
    try {
        check(std::u16string(4001, u'x'));
    } catch (...) {
        rejected = true;
    }
    assert(rejected);
    const char16_t noNull[] = {u'a', u'b'};
    rejected = false;
    try {
        qt::copiedText(noNull, 2);
    } catch (...) {
        rejected = true;
    }
    assert(rejected);
    const char16_t afterNull[] = {u'a', 0, 0xd800};
    assert(qt::copiedText(afterNull, 3) == u"a");
    for (const auto &broken :
         std::vector<std::u16string>{u"", std::u16string(1, 0xd800), std::u16string(1, 0xdc00),
                                     std::u16string({0xd800, u'x'})}) {
        rejected = false;
        try {
            check(broken);
        } catch (...) {
            rejected = true;
        }
        assert(rejected);
    }
    rejected = false;
    try {
        qt::copiedText(nullptr, 20);
    } catch (...) {
        rejected = true;
    }
    assert(rejected);
    qt::CopiedSequenceGuard guard;
    guard.reset(100);
    assert(!guard.accept(0) && !guard.accept(100));
    assert(guard.accept(101));
    assert(!guard.accept(101));
    guard.reset(0xffffffff);
    assert(guard.accept(1)); // sequence wrap must not use a greater-than comparison
    std::mt19937 rng(88);
    for (int i = 0; i < 1000; ++i) {
        std::u16string s(1 + rng() % 4000, u'a');
        assert(check(s) == s);
    }
    std::cout << "PASS: bounded UTF-16 clipboard block scan, malformed/NUL/surrogate checks, "
                 "stale-copy sequence guard and 1000 valid blocks. No real clipboard access.\n";
}
