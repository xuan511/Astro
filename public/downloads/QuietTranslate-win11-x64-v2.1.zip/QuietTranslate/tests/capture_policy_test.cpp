#include "../src/capture_policy.hpp"
#include <cassert>
#include <iostream>
using namespace qt;
template <class F> void fails(F f) {
    bool error = false;
    try {
        f();
    } catch (...) {
        error = true;
    }
    assert(error);
}
int main() {
    assert(copyKeys.size() == 4);
    assert(copyKeys[0].vk == 0x11 && !copyKeys[0].up);
    assert(copyKeys[1].vk == 0x2d && !copyKeys[1].up && copyKeys[1].extended);
    assert(copyKeys[2].vk == 0x2d && copyKeys[2].up && copyKeys[2].extended);
    assert(copyKeys[3].vk == 0x11 && copyKeys[3].up);
    for (auto k : copyKeys)
        assert(k.vk != 0x43 && k.vk != 0x56 && k.vk != 0x58 && k.vk != 0x10);
    assert(releaseKeyAllowed(0x11, 0x45));
    assert(releaseKeyAllowed(0x45, 0x45));
    assert(!releaseKeyAllowed(0x58, 0x45));
    assert(!releaseKeyAllowed(0x2d, 0x45));
    assert(!releaseKeyAllowed(0x5b, 0x45));
    ReleaseGate gate(1000);
    assert(!gate.ready(1000, true, true));
    assert(!gate.ready(1100, false, true));
    assert(!gate.ready(1139, false, true));
    assert(gate.ready(1140, false, true));
    ReleaseGate reset(1000);
    assert(!reset.ready(1000, false, true));
    assert(!reset.ready(1040, true, true));
    assert(!reset.ready(1041, false, true));
    assert(!reset.ready(1080, false, true));
    assert(reset.ready(1081, false, true));
    ReleaseGate hold(100);
    fails([&] { hold.ready(1901, true, true); });
    ReleaseGate changed(100);
    fails([&] { changed.ready(110, false, false); });
    ReleaseGate rewind(100);
    fails([&] { rewind.ready(90, false, true); });
    assert(copyOwner(0, 1, 12, 34, 12));
    assert(copyOwner(7, 8, 12, 34, 34));
    assert(copyOwner(0xffffffff, 1, 12, 34, 34));
    assert(!copyOwner(7, 7, 12, 34, 12));
    assert(!copyOwner(7, 0, 12, 34, 12));
    assert(!copyOwner(7, 8, 12, 34, 56));
    assert(!copyOwner(7, 8, 12, 34, 0));
    assert(allowedCopyInput(17, 17, 21));
    assert(allowedCopyInput(21, 17, 21));
    assert(!allowedCopyInput(22, 17, 21));
    for (auto p : {"cmd.exe", "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\PowerShell.EXE",
                   "/bin/pwsh.exe", "WindowsTerminal.exe", "conhost.exe", "OpenConsole.EXE",
                   "putty.exe", "mintty.exe"})
        assert(terminalProcess(p));
    for (auto p : {"Code.exe", "C:\\Office\\WINWORD.EXE", "EXCEL.EXE", "chrome.exe", "msedge.exe",
                   "firefox.exe", "AcroRd32.exe", "Typora.exe", "notepad.exe"})
        assert(!terminalProcess(p));
    bool specialized = false;
    try {
        throw NoSelection("empty caret");
    } catch (const NoSelection &) {
        specialized = true;
    }
    assert(specialized);
    std::cout << "PASS: copy-only balanced extended-key packet, shortcut "
                 "release/quiet/deadline/focus state machine, clipboard freshness/owner PID and "
                 "input-time guards, active terminal process classification. No keys injected.\n";
}
