param([string]$Exe = (Join-Path $PSScriptRoot '..\QuietTranslate.exe'))
$ErrorActionPreference = 'Stop'
$info = New-Object Diagnostics.ProcessStartInfo
$info.FileName = (Resolve-Path $Exe).Path
$info.Arguments = '--billing-test'
$info.UseShellExecute = $false
$info.CreateNoWindow = $true
$info.RedirectStandardOutput = $true
$p = New-Object Diagnostics.Process
$p.StartInfo = $info
try {
    [void]$p.Start()
    $read = $p.StandardOutput.ReadToEndAsync()
    if (-not $p.WaitForExit(10000)) { $p.Kill(); throw 'Billing fixture timeout' }
    $output = $read.GetAwaiter().GetResult()
    if ($p.ExitCode -ne 0 -or $output -notmatch 'PASS billing fixed fixture') { throw 'Billing storage fixture failed' }
    Write-Output 'PASS: fixed usage/cost + actual Windows DPAPI round trip; unique fixture file only, no real billing data, key or network.'
} finally { if (-not $p.HasExited) { $p.Kill() }; $p.Dispose() }
