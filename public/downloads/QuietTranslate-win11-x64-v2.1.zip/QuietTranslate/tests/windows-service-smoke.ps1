﻿param([string]$Exe = (Join-Path $PSScriptRoot '..\QuietTranslate.exe'))
$ErrorActionPreference = 'Stop'
$Exe = (Resolve-Path $Exe).Path
# The service-test mode uses a fixed in-process fake translator. No network or UI automation.
function Invoke-ServiceBatch([string[]]$Samples, [bool]$Cache) {
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $Exe
    $info.Arguments = '--service-test ' + [int]$Cache
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardInput = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $p = New-Object Diagnostics.Process
    $p.StartInfo = $info
    $started = $false
    $buffer = New-Object IO.MemoryStream
    try {
        [void]$p.Start(); $started = $true
        $readTask = $p.StandardOutput.BaseStream.CopyToAsync($buffer)
        foreach ($sample in $Samples) {
            $b = [Text.Encoding]::UTF8.GetBytes($sample)
            $header = [BitConverter]::GetBytes([uint32]10) + [BitConverter]::GetBytes([uint32]$b.Length)
            $p.StandardInput.BaseStream.Write($header, 0, 8)
            $p.StandardInput.BaseStream.Write($b, 0, $b.Length)
        }
        $p.StandardInput.Close()
        if (-not $p.WaitForExit(5000)) { $p.Kill(); throw 'Service timeout' }
        $readTask.GetAwaiter().GetResult()
        if ($p.ExitCode -ne 0) { throw 'Service exited abnormally' }
        $raw = $buffer.ToArray(); $offset = 0; $frames = @()
        while ($offset -lt $raw.Length) {
            if ($raw.Length - $offset -lt 8) { throw 'Truncated frame' }
            $type = [BitConverter]::ToUInt32($raw, $offset)
            $len = [BitConverter]::ToUInt32($raw, $offset + 4); $offset += 8
            if ($len -gt 65536 -or $offset + $len -gt $raw.Length) { throw 'Invalid frame size' }
            $frames += [pscustomobject]@{ Type=$type; Text=[Text.Encoding]::UTF8.GetString($raw, $offset, $len) }
            $offset += $len
        }
        return ,$frames
    } finally {
        if ($started -and -not $p.HasExited) { $p.Kill() }
        $buffer.Dispose(); $p.Dispose()
    }
}
$long = ('A' * 500) + ('B' * 500)
$frames = Invoke-ServiceBatch @($long, $long, 'FAIL', 'after-error') $true
if (@($frames | Where-Object Type -eq 2).Count -ne 3) { throw 'Persistent requests failed' }
if (@($frames | Where-Object Type -eq 3).Count -ne 1) { throw 'Error recovery failed' }
if (@($frames | Where-Object { $_.Type -eq 5 -and $_.Text -match '网络 0 · 缓存 2' }).Count -ne 1) { throw 'Repeated text was not cached' }
$firstFinal = 0
while ($frames[$firstFinal].Type -ne 2) { $firstFinal++ }
if ($frames[0].Type -ne 4 -or $firstFinal -lt 4) { throw 'No progressive result before completion' }
$frames = Invoke-ServiceBatch @($long, $long) $false
if (@($frames | Where-Object { $_.Type -eq 5 -and $_.Text -match '网络 2 · 缓存 0' }).Count -ne 2) { throw 'Cache disable failed' }
$partialFail = ('C' * 500) + 'FAIL'
$frames = Invoke-ServiceBatch @($partialFail, $partialFail) $true
if (@($frames | Where-Object Type -eq 3).Count -ne 2) { throw 'Failure was cached as success' }
if (@($frames | Where-Object { $_.Type -eq 5 -and $_.Text -match '网络 0 · 缓存 1' }).Count -ne 1) { throw 'Successful prefix was not reused on retry' }
Write-Output 'PASS: persistent service, progress frames, repeated-query cache, cache disable, partial failure/retry and recovery. No live network used.'
