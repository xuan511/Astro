#include "../src/study.hpp"
#include <cassert>
#include <iostream>
#include <random>
#include <chrono>
static bool has(const std::vector<qt::Keyword> &keys, const std::string &term) {
    for (auto &k : keys)
        if (k.term == term)
            return true;
    return false;
}
int main() {
    std::set<std::string> unique;
    for (auto &c : qt::studyCards()) {
        assert(unique.insert(c.term).second);
        assert(c.term == qt::normalize(c.term));
        assert(!c.pos.empty() && !c.meaning.empty() && !c.usage.empty() && !c.patterns.empty() &&
               !c.example.empty() && !c.translation.empty());
        auto display = qt::studyText(c);
        assert(display.find(c.example) != std::string::npos &&
               display.find(c.translation) != std::string::npos);
    }
    assert(qt::studyCards().size() >= 50);
    assert(qt::findStudyCard(" ASSERT "));
    auto keys = qt::keywords("The register shall remain disabled unless the clock is stable.");
    assert(has(keys, "shall") && has(keys, "disable") && has(keys, "unless") &&
           has(keys, "register"));
    assert(!has(keys, "the"));
    keys = qt::keywords("The controller asserts reset.");
    assert(has(keys, "assert"));
    bool form = false;
    for (auto &k : keys)
        if (k.term == "assert")
            form = k.surface == "asserts";
    assert(form);
    keys = qt::keywords("The result may depend on the memory barrier.");
    assert(has(keys, "depend on") && has(keys, "memory barrier") && has(keys, "may"));
    assert(!has(qt::keywords("nonvolatile bytes"), "volatile"));
    assert(qt::keywords("DMA_ENABLED 0xFFFF user_id C8T6").empty());
    keys = qt::keywords("enabling ENABLED enable read-only read-modify-write");
    size_t enables = 0;
    for (auto &k : keys)
        if (k.term == "enable")
            ++enables;
    assert(enables == 1 && has(keys, "read-only") && has(keys, "read-modify-write"));
    assert(qt::keywords("require", 0).empty());
    assert(qt::keywords("请看：require 与 prevent").size() == 2);
    assert(qt::dictionaryWord("don't") && qt::dictionaryWord("read-only"));
    for (auto &invalid :
         {"a/b", "../word", "word?x=y", "x\r\ny", "_private", "0x01", "-word", "word-", ""})
        assert(!qt::dictionaryWord(invalid));
    assert(!qt::dictionaryWord(std::string(41, 'x')));
    std::string json =
        R"([{"word":"require","phonetics":[{"text":"rɪˈkwaɪə","audio":"https://not-fetched.invalid/audio"}],"license":{"name":"Fixture license","url":"https://example.invalid/license"},"sourceUrls":["https://example.invalid/require"],"meanings":[{"partOfSpeech":"verb","definitions":[{"definition":"To need."},{"definition":"To make necessary.","example":"The driver requires a stable clock."}]},{"partOfSpeech":"noun","definitions":[{"definition":"A test noun sense."}]}]}])";
    auto entry = qt::parseDictionary(json, "require");
    assert(entry.word == "require" && entry.senses.size() == 2 && !entry.phonetic.empty());
    assert(entry.senses[0].definition == "To make necessary.");
    assert(entry.senses[1].example.empty());
    assert(entry.report().find("该义项未提供例句") != std::string::npos);
    assert(entry.report().find("Fixture license") != std::string::npos &&
           entry.report().find("example.invalid/require") != std::string::npos);
    assert(entry.translationInput().find("Example: The driver requires a stable clock.") !=
           std::string::npos);
    assert(entry.translationInput().size() < 4000);
    auto noexample = qt::parseDictionary(
        R"([{"meanings":[{"partOfSpeech":"verb","definitions":[{"definition":"To need."}]}]}])",
        "require");
    assert(noexample.translationInput().find("Example:") == std::string::npos);
    assert(noexample.report().find("响应未提供许可") != std::string::npos);
    for (auto &invalid : {"{}", "[]", "null", R"([{"meanings":false}])",
                          R"([{"meanings":[{"definitions":[{"definition":123}]}]}])"}) {
        bool rejected = false;
        try {
            qt::parseDictionary(invalid, "word");
        } catch (...) {
            rejected = true;
        }
        assert(rejected);
    }
    assert(qt::limited("中文😀", 1) == "…");
    assert(qt::limited("中文😀", 6) == "中文…");
    std::mt19937 rng(12);
    std::string words[] = {"requires",       "unless",    "enabled", "register",  "DMA_ENABLED",
                           "memory barrier", "read-only", "the",     "available", "asserted"};
    auto start = std::chrono::steady_clock::now();
    for (int i = 0; i < 1000; ++i) {
        std::string source;
        for (int j = 0; j < 40; ++j)
            source += words[rng() % 10] + " ";
        auto result = qt::keywords(source);
        assert(result.size() <= 8);
        std::set<std::string> terms;
        for (auto &k : result) {
            assert(terms.insert(k.term).second);
            assert(k.position < source.size());
            assert(source.substr(k.position, k.surface.size()) == k.surface);
        }
    }
    bool bounded = false;
    try {
        qt::keywords(std::string(12001, 'x'));
    } catch (...) {
        bounded = true;
    }
    assert(bounded);
    std::cout << "PASS: " << qt::studyCards().size()
              << " complete study cards; keyword boundaries/word forms/phrases; dictionary schema, "
                 "missing examples, attribution, UTF-8 limits; 1000 candidate fuzz cases\n";
    std::cout << "Keyword fuzz wall time (this Linux sanitizer build only): "
              << std::chrono::duration_cast<std::chrono::milliseconds>(
                     std::chrono::steady_clock::now() - start)
                     .count()
              << " ms\n";
}
