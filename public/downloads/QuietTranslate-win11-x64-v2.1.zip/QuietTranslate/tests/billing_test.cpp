#include "../src/billing.hpp"
#include <cassert>
#include <iostream>
template <class F> void fails(F f) {
    bool error = false;
    try {
        f();
    } catch (const std::exception &) {
        error = true;
    }
    assert(error);
}
std::string id(unsigned n) {
    std::ostringstream s;
    s << "aaaaaaaa-aaaa-4aaa-8aaa-" << std::setw(12) << std::setfill('0') << std::hex << n;
    return s.str();
}
int main() {
    using namespace qt;
    assert(priceMicros("0.7") == 700000 && priceMicros("1.950000") == 1950000 &&
           priceMicros("0") == 0);
    for (auto s : {"-1", "1,000", "1e2", "NaN", "0.1234567", "10000.01", "", "."})
        fails([&] { priceMicros(s); });
    auto usage = ApiUsage::fromResponse(
        Parser(
            R"({"usage":{"prompt_tokens":1000,"completion_tokens":200,"total_tokens":1200,"prompt_tokens_details":{"cached_tokens":400}}})")
            .parse());
    assert(usage.full() && usage.cached == 400 && usage.total == 1200);
    BillingRate rate;
    rate.enabled = true;
    rate.input = priceMicros("0.7");
    rate.output = priceMicros("1.95");
    uint64_t amount = 0;
    assert(rate.cost(usage, amount) && amount == 1090000000ULL && moneyText(amount) == "0.001090");
    rate.cachedEnabled = true;
    rate.cached = priceMicros("0.14");
    assert(rate.cost(usage, amount) && amount == 866000000ULL && moneyText(amount) == "0.000866");
    auto invalidCached = usage;
    invalidCached.cached = invalidCached.input + 1;
    assert(!rate.cost(invalidCached, amount));
    assert(moneyText(1) == "<0.000001" && moneyText(0) == "0.000000");
    BillingBook book;
    std::string scope(64, 'a');
    book.setPrice({scope, "example.invalid", "model", rate});
    BillEntry e;
    e.id = id(1);
    e.scope = scope;
    e.host = "example.invalid";
    e.model = "model";
    e.at = 100;
    e.purpose = 0;
    book.begin(e);
    book.started(e.id);
    book.observe(e.id, usage);
    book.observe(e.id, usage);
    assert(book.stats().total == 1200);
    book.finish(e.id, BillState::Success);
    auto first = book.find(e.id)->rate.input;
    auto updated = rate;
    updated.input = priceMicros("10");
    book.setPrice({scope, e.host, e.model, updated});
    assert(book.find(e.id)->rate.input == first && book.stats().cny == 866000000ULL);
    e.id = id(2);
    book.begin(e);
    book.finish(e.id, BillState::Cache);
    assert(book.stats().attempts == 1 && book.stats().cache == 1 && book.stats().total == 1200);
    e.id = id(3);
    book.begin(e);
    book.started(e.id);
    book.finish(e.id, BillState::Cancelled);
    assert(book.stats().missing == 1 && book.stats().unpriced == 1 && book.stats().attempts == 2);
    e.id = id(4);
    book.begin(e);
    book.finish(e.id, BillState::Failed);
    assert(book.find(e.id)->state == BillState::NotSent && book.stats().attempts == 2);
    updated.currency = "USD";
    book.setPrice({scope, e.host, e.model, updated});
    e.id = id(5);
    book.begin(e);
    book.started(e.id);
    book.observe(e.id, usage);
    book.finish(e.id, BillState::Failed);
    assert(book.stats().usd > 0 && book.stats().cny == 866000000ULL);
    auto round = BillingBook::parse(book.json());
    assert(round.json() == book.json());
    e.id = id(6);
    book.begin(e);
    book.started(e.id);
    round = BillingBook::parse(book.json());
    assert(round.find(e.id)->state == BillState::Interrupted && round.stats().missing == 2);
    fails([&] { BillingBook::parse("{}"); });
    assert(book.json().find("api-key") == std::string::npos);
    BillingBook rolling;
    rolling.setPrice({scope, e.host, e.model, rate});
    for (unsigned n = 0; n < billingKeep + 10; ++n) {
        e.id = id(n + 100);
        rolling.begin(e);
        rolling.started(e.id);
        rolling.observe(e.id, usage);
        rolling.finish(e.id, BillState::Success);
    }
    assert(rolling.entries().size() == billingKeep &&
           rolling.stats().attempts == billingKeep + 10 &&
           rolling.stats().total == 1200 * (billingKeep + 10));
    auto sum = rolling.stats();
    auto loaded = BillingBook::parse(rolling.json());
    assert(loaded.stats().total == sum.total && loaded.stats().cny == sum.cny);
    BillingBook unpriced;
    e.id = id(9000);
    unpriced.begin(e);
    unpriced.started(e.id);
    unpriced.observe(e.id, usage);
    unpriced.finish(e.id, BillState::Success);
    assert(unpriced.stats().unpriced == 1);
    unpriced.setPrice({scope, e.host, e.model, rate});
    assert(unpriced.reprice(scope) == 1 && unpriced.stats().unpriced == 0 &&
           unpriced.stats().cny == 866000000ULL);
    assert(unpriced.reprice(scope) == 0);
    auto partial = ApiUsage::fromResponse(Parser(R"({"usage":{"input_tokens":12}})").parse());
    e.id = id(9001);
    unpriced.begin(e);
    unpriced.started(e.id);
    unpriced.observe(e.id, partial);
    unpriced.finish(e.id, BillState::Success);
    assert(unpriced.stats().total == 1212 && unpriced.stats().missing == 1 &&
           unpriced.stats().unpriced == 1);
    BillingStats high;
    high.cny = UINT64_MAX;
    high.overflow = true;
    auto highRound = BillingStats::parse(Parser(high.json()).parse());
    assert(highRound.cny == UINT64_MAX && highRound.overflow);
    std::cout
        << "PASS billing: exact fixed-point input/output/cache pricing, currency separation, "
           "snapshot immutability, repeated usage not summed, cache/no-send exclusions, cancelled "
           "unknowns, crash recovery, 2000-row archive totals, reprice and partial use\n";
}
