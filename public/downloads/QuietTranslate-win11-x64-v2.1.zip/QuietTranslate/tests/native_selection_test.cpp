#include "../src/native_selection.hpp"
#include <cassert>
#include <iostream>
#include <random>
#include <set>
using namespace qt;
template <class F> void fails(F f) {
    bool error = false;
    try {
        f();
    } catch (...) {
        error = true;
    }
    assert(error);
}
struct Control {
    int mode = 0, count = 1, cp = 65001;
    int64_t length = 1000000000000LL;
    bool legacy = false, virtualSpace = false;
    std::vector<SelectedSpan> spans{{900000000000LL, 900000000010LL}};
    std::string selected = "alpha beta";
    std::vector<int64_t> readPositions;
    unsigned reads = 0;
    bool mutate = false, move = false;
    int64_t query(uint32_t m, int64_t p) {
        switch (m) {
        case sci::length:
            return length;
        case sci::selectionMode:
            return mode;
        case sci::selections:
            return legacy ? 0 : count;
        case sci::codePage:
            return cp;
        case sci::caretVirtual:
        case sci::anchorVirtual:
            return virtualSpace ? 1 : 0;
        case sci::nthStart:
        case sci::start:
            return spans.at((size_t)p).begin + (move && reads ? 1 : 0);
        case sci::nthEnd:
        case sci::end:
            return spans.at((size_t)p).end + (move && reads ? 1 : 0);
        case sci::character: {
            bool allowed = false;
            for (auto s : spans)
                if (p >= s.begin && p < s.end)
                    allowed = true;
            assert(allowed);
            readPositions.push_back(p);
            ++reads;
            auto c = (unsigned char)selected.at((size_t)(p - spans[0].begin));
            if (mutate && reads > selected.size())
                return c == 'a' ? 'b' : 'a';
            return (int8_t)c; // Some Scintilla versions expose signed char values.
        }
        default:
            assert(false);
            throw std::runtime_error("non-whitelisted message");
        }
    }
    NativeSelection read() {
        return scintillaSelection([&](auto m, auto p) { return query(m, p); });
    }
};
int main() {
    Control c;
    auto got = c.read();
    assert(got.bytes == "alpha beta" && got.codePage == 65001 && got.ranges == 1);
    assert(c.readPositions.size() == 20);
    c = Control{};
    c.legacy = true;
    assert(c.read().bytes == "alpha beta");
    c = Control{};
    c.selected = "English 中文 😀";
    c.spans[0].end = c.spans[0].begin + c.selected.size();
    assert(c.read().bytes == c.selected);
    c = Control{};
    c.mutate = true;
    fails([&] { c.read(); });
    c = Control{};
    c.move = true;
    fails([&] { c.read(); });
    for (auto mode : {1, 3, 99}) {
        c = Control{};
        c.mode = mode;
        fails([&] { c.read(); });
        assert(c.readPositions.empty());
    }
    c = Control{};
    c.count = 9;
    fails([&] { c.read(); });
    assert(c.readPositions.empty());
    c = Control{};
    c.virtualSpace = true;
    fails([&] { c.read(); });
    assert(c.readPositions.empty());
    c = Control{};
    c.spans[0].end = c.spans[0].begin;
    fails([&] { c.read(); });
    assert(c.readPositions.empty());
    c = Control{};
    c.spans[0].begin = -1;
    fails([&] { c.read(); });
    assert(c.readPositions.empty());
    c = Control{};
    c.spans[0].end = c.length + 1;
    fails([&] { c.read(); });
    assert(c.readPositions.empty());
    c = Control{};
    c.selected.assign(4000, 'x');
    c.spans[0].end = c.spans[0].begin + 4000;
    assert(c.read().bytes.size() == 4000);
    c = Control{};
    c.spans[0].end = c.spans[0].begin + 4001;
    fails([&] { c.read(); });
    assert(c.readPositions.empty());
    c = Control{};
    c.selected[0] = 0;
    fails([&] { c.read(); });
    fails([&] {
        scintillaSelection(
            [](uint32_t, int64_t) -> int64_t { throw std::runtime_error("message timeout"); });
    });
    // Multi-range gap must never be read; line separators are synthesized locally.
    std::set<int64_t> visited;
    auto multi = scintillaSelection([&](uint32_t m, int64_t p) -> int64_t {
        if (m == sci::selectionMode)
            return 0;
        if (m == sci::selections)
            return 2;
        if (m == sci::length)
            return 100000;
        if (m == sci::codePage)
            return 65001;
        if (m == sci::caretVirtual || m == sci::anchorVirtual)
            return 0;
        if (m == sci::nthStart)
            return p ? 99990 : 2;
        if (m == sci::nthEnd)
            return p ? 99992 : 4;
        assert(m == sci::character);
        assert(p == 2 || p == 3 || p == 99990 || p == 99991);
        visited.insert(p);
        return p < 100 ? 'a' : 'b';
    });
    assert(multi.bytes == "aa\nbb" && visited.size() == 4);
    std::mt19937 rng(77);
    for (int i = 0; i < 1000; ++i) {
        c = Control{};
        c.selected.assign(1 + rng() % 4000, 'a');
        c.spans[0].begin = 100000 + (rng() % 10000000);
        c.spans[0].end = c.spans[0].begin + c.selected.size();
        assert(c.read().bytes == c.selected);
    }
    assert(freshCopy(0, 1, 123, 123));
    assert(freshCopy(0xffffffff, 1, 123, 123));
    assert(!freshCopy(123, 123, 123, 123));
    assert(!freshCopy(123, 0, 123, 123));
    assert(!freshCopy(1, 2, 123, 456));
    assert(!freshCopy(1, 2, 0, 0));
    std::cout << "PASS: Scintilla exact selected-byte boundaries, 64-bit offsets, signed UTF-8 "
                 "bytes, multi-range gaps, edit/selection races, 1000 ranges, bounds, timeout "
                 "propagation; fresh-copy PID/sequence checks. No Windows execution.\n";
}
