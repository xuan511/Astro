#include "../src/notebook.hpp"
#include <cassert>
#include <iostream>
template <class F> void fails(F f) {
    bool b = false;
    try {
        f();
    } catch (const std::exception &) {
        b = true;
    }
    assert(b);
}
int main() {
    const std::string a = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
                      b = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb", key(64, 'a');
    qt::Notebook x;
    x.record(key, "interrupt", "中断", "fixture", a, 100);
    assert(x.find(key)->hits() == 1);
    auto e = *x.find(key);
    x.merge(e);
    x.record(key, "interrupt", "中断", "fixture", a, 101);
    auto local = *x.find(key);
    auto remote = e;
    remote.counts[b] = 3;
    remote.rev = qt::revision(102, b);
    remote.note = "other device";
    x.merge(remote);
    assert(x.find(key)->hits() == 5 && x.find(key)->note == "other device");
    auto merged = *x.find(key);
    x.merge(merged);
    x.merge(merged);
    assert(x.find(key)->hits() == 5);
    x.edit(key, "笔记", true, false, "词典用法", a, 103);
    auto newer = *x.find(key);
    x.merge(merged);
    assert(x.find(key)->note == "笔记");
    assert(qt::mergeEntry(local, remote).json() == qt::mergeEntry(remote, local).json());
    x.erase(key, a, 104);
    auto deleted = *x.find(key);
    x.merge(e);
    assert(x.find(key)->deleted && x.find(key)->source.empty() && x.sorted().empty());
    x.merge(deleted);
    x.record(key, "interrupt", "中断", "fixture", a, 105);
    assert(!x.find(key)->deleted && x.find(key)->hits() == 6);
    x.review(key, true, a, 106);
    assert(x.find(key)->level == 1 && x.find(key)->due == 106 + 3 * 86400000ULL);
    assert(x.sorted("", false, false, true, 106).empty());
    x.review(key, false, a, 107);
    assert(x.find(key)->level == 0 && !x.find(key)->known);
    assert(x.sorted("interrupt").size() == 1 && x.sorted("missing").empty());
    auto round = qt::Notebook::parse(x.json());
    assert(round.json() == x.json());
    auto legacy = "{\"schema\":1,\"entries\":[" + e.json() + "],\"dirty\":[\"" + key + "\"]}";
    auto importedLegacy = qt::Notebook::parse(legacy);
    assert(importedLegacy.find(key)->hits() == 1);
    assert(importedLegacy.json().find("\"dirty\":[]") != std::string::npos);
    fails([&] { qt::Notebook::parse("{}"); });
    fails([&] {
        auto bad = newer;
        bad.rev = "bad";
        qt::BookEntry::parse(qt::Parser(bad.json()).parse());
    });
    fails([&] { x.edit(key, std::string(2001, 'x'), true, false, "", a, 200); });
    fails([&] {
        auto bad = newer;
        bad.counts[a] = 1000000001;
        qt::BookEntry::parse(qt::Parser(bad.json()).parse());
    });
    assert(qt::shortLearningQuery("memory ordering") && !qt::shortLearningQuery("line\nbreak"));
    for (int i = 0; i < 1000; ++i) {
        auto v = remote;
        v.rev = qt::revision(300 + i, b);
        v.counts[b] = i + 3;
        auto m = qt::mergeEntry(newer, v);
        assert(qt::mergeEntry(m, v).json() == m.json());
        assert(qt::mergeEntry(v, newer).json() == m.json());
    }
    qt::Notebook full;
    for (unsigned i = 0; i < qt::bookCount; ++i) {
        std::ostringstream id;
        id << std::setw(64) << std::setfill('0') << std::hex << i;
        full.record(id.str(), "capacity fixture", "", "fixture", a, 100);
    }
    assert(qt::Notebook::parse(full.json()).entries().size() == qt::bookCount);
    assert(full.serializedBytes() == full.json().size());
    qt::Notebook batch;
    auto edited = full.entries().begin()->second;
    edited.rev = qt::revision(500, a);
    edited.translation = "";
    batch.merge(edited);
    auto extra = edited;
    extra.key = std::string(64, 'f');
    extra.source = "one too many in a batch";
    batch.merge(extra);
    auto initial = full.json();
    fails([&] { full.importBatch(batch); });
    assert(full.json() == initial);
    fails([&] { full.record(std::string(64, 'f'), "one too many", "", "fixture", a, 100); });
    bool rejected = false;
    std::string unfilled;
    for (auto &item : full.entries()) {
        auto v = item.second;
        v.rev = qt::revision(101, a);
        v.translation = std::string(16000, 'x');
        auto before = item.second.json();
        auto size = full.serializedBytes();
        try {
            full.importEntry(v);
        } catch (const std::exception &) {
            rejected = true;
            unfilled = v.key;
            assert(full.find(v.key)->json() == before && full.serializedBytes() == size);
            break;
        }
    }
    assert(rejected && full.serializedBytes() <= qt::bookLimit &&
           full.serializedBytes() == full.json().size());
    auto close = *full.find(unfilled);
    auto gap = qt::bookLimit - full.serializedBytes();
    assert(gap > 10 && gap < 16000);
    close.translation = std::string(gap - 10, 'x');
    close.rev = qt::revision(102, a);
    full.importEntry(close);
    assert(full.serializedBytes() == qt::bookLimit - 10);
    auto exact = full.json();
    fails([&] { full.edit(unfilled, std::string(100, 'n'), true, false, "", a, 103); });
    assert(full.json() == exact);
    auto remoteLarge = close;
    remoteLarge.note = std::string(100, 'n');
    remoteLarge.rev = qt::revision(104, b);
    fails([&] { full.merge(remoteLarge); });
    assert(full.json() == exact);
    assert(!full.merge(close));
    assert(!full.merge(close));
    assert(full.serializedBytes() == full.json().size());
    auto snapshot = x.json();
    fails([&] { x.record(key, "interrupt", "bad clock", "fixture", a, 9000000000000001ULL); });
    assert(x.json() == snapshot);
    fails([&] {
        qt::Notebook::parse("{\"schema\":1,\"entries\":[" + e.json() + "," + e.json() +
                            "],\"dirty\":[]}");
    });
    qt::Notebook backup;
    backup.merge(e);
    auto hits = x.find(key)->hits();
    x.importBatch(backup);
    assert(x.find(key)->hits() == hits);
    assert(x.importBatch(backup) == 0 && x.find(key)->hits() == hits);
    std::cout << "PASS notebook: local counters/idempotent backup merge, revisions, legacy "
                 "pending-field removal, "
                 "delete/restore, review, bounds, round trip\n";
}
