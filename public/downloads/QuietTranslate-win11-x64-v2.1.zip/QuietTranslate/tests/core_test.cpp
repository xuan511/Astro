#include "../src/glossary.hpp"
#include <iostream>
#include <cassert>
#include <random>
int main() {
    assert(qt::lookup("  VOLATILE. ").find("易变") != std::string::npos);
    assert(!qt::lookup("file descriptor").empty());
    assert(qt::lookup("unlisted term").empty());
    assert(qt::url("a&b +中") == "a%26b%20%2B%E4%B8%AD");
    assert(
        qt::translation(
            R"({"responseStatus":200,"responseData":{"translatedText":"\u4f60\u597d \ud83d\ude00"}})") ==
        "你好 😀");
    assert(qt::html("&lt;T&gt; &amp; &quot;x&quot;") == "<T> & \"x\"");
    for (auto bad : {"", "{", "[] junk", "{\"x\":1,}", "{\"x\":1,\"x\":2}", "\"\\uD800\"",
                     "\"\\uDC00\"", "01", "1.", "1e", "\"a\nb\""}) {
        bool failed = false;
        try {
            qt::Parser(bad).parse();
        } catch (...) {
            failed = true;
        }
        assert(failed);
    }
    for (auto bad : {R"({"responseStatus":429,"responseData":{"translatedText":"x"}})",
                     R"({"responseStatus":200,"responseData":{}})",
                     R"({"responseStatus":200,"responseData":{"translatedText":null}})"}) {
        bool failed = false;
        try {
            qt::translation(bad);
        } catch (...) {
            failed = true;
        }
        assert(failed);
    }
    std::mt19937 rng(73);
    for (int i = 0; i < 2000; ++i) {
        std::string s;
        for (int j = 0, n = rng() % 3000; j < n; ++j)
            s += (rng() % 3) ? "A" : "中";
        auto cs = qt::chunks(s);
        std::string again;
        for (auto c : cs) {
            assert(c.size() <= 450 && !c.empty());
            assert(((unsigned char)c.front() & 0xc0) != 0x80);
            again += c;
        }
        assert(again == s);
    }
    assert(qt::glossary().size() >= 100);
    assert(qt::english("CRC32"));
    assert(!qt::english("中文 123"));
    std::cout << "PASS: glossary, percent encoding, bounded JSON parser, surrogate pairs, response "
                 "errors, 2000 UTF-8 chunk round trips\n";
}
