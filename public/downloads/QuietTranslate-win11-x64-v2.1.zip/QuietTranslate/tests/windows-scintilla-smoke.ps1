﻿param([string]$Exe=(Join-Path $PSScriptRoot '..\QuietTranslate.exe'),[string]$ScintillaDll,[switch]$AllowSkip)
$ErrorActionPreference='Stop'
if(-not $ScintillaDll){Write-Warning 'SKIP: provide -ScintillaDll with a trusted real Scintilla DLL. Real Scintilla compatibility NOT verified.';exit 0}
$Exe=(Resolve-Path $Exe).Path;$ScintillaDll=(Resolve-Path $ScintillaDll).Path
# Loads only the explicitly provided DLL and creates its OWN public sample document.
# No SendInput, clipboard data access or user documents. Requires an unlocked interactive desktop.
Add-Type -ReferencedAssemblies System.Windows.Forms,System.Drawing -TypeDefinition @'
using System;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;
public class SciBox:Control {
    protected override CreateParams CreateParams {get{var p=base.CreateParams;p.ClassName="Scintilla";return p;}}
}
public static class SciFixture {
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)]static extern IntPtr LoadLibrary(string path);
    [DllImport("user32.dll")]static extern IntPtr SendMessage(IntPtr h,uint msg,IntPtr w,IntPtr l);
    [DllImport("user32.dll")]public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]public static extern uint GetClipboardSequenceNumber();
    static Thread thread;static Form form;static SciBox box;static ManualResetEvent ready;
    static IntPtr module;public static IntPtr Handle;public static Exception Error;
    public static string Expected;
    public static bool Start(string path,bool select){
        if(module==IntPtr.Zero){module=LoadLibrary(path);if(module==IntPtr.Zero)throw new Exception("Cannot load trusted Scintilla DLL");}
        ready=new ManualResetEvent(false);Error=null;Handle=IntPtr.Zero;
        thread=new Thread(delegate(){try{
            form=new Form();form.Width=680;form.Height=240;form.TopMost=true;form.Text="QuietTranslate - real Scintilla controlled fixture";
            box=new SciBox();box.Dock=DockStyle.Fill;form.Controls.Add(box);
            form.Shown+=delegate{form.BeginInvoke((MethodInvoker)delegate{try{
                string prefix=new string('a',70000)+" ";Expected="alpha 中文 beta";
                byte[] source=Encoding.UTF8.GetBytes(prefix+Expected+" last\0");
                IntPtr mem=Marshal.AllocHGlobal(source.Length);
                try{Marshal.Copy(source,0,mem,source.Length);SendMessage(box.Handle,2037,new IntPtr(65001),IntPtr.Zero);SendMessage(box.Handle,2181,IntPtr.Zero,mem);}finally{Marshal.FreeHGlobal(mem);}
                int start=Encoding.UTF8.GetByteCount(prefix),end=start+(select?Encoding.UTF8.GetByteCount(Expected):0);
                SendMessage(box.Handle,2160,new IntPtr(start),new IntPtr(end));form.Activate();box.Focus();Handle=form.Handle;
            }catch(Exception e){Error=e;}finally{ready.Set();}});};
            Application.Run(form);
        }catch(Exception e){Error=e;ready.Set();}});
        thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);thread.Start();return ready.WaitOne(8000);
    }
    public static void Stop(){if(form!=null&&!form.IsDisposed)try{form.BeginInvoke((MethodInvoker)delegate{form.Close();});}catch{}if(thread!=null)thread.Join(2000);}
}
'@
foreach($select in @($true,$false)){
 try{
    if(-not [SciFixture]::Start($ScintillaDll,$select)){throw 'Scintilla fixture startup timeout'}
    if([SciFixture]::Error){throw [SciFixture]::Error}
    if([SciFixture]::GetForegroundWindow() -ne [SciFixture]::Handle){if($AllowSkip){Write-Warning 'SKIP: interactive foreground unavailable. Scintilla NOT verified.';exit 0};throw 'Foreground desktop required'}
    $before=[SciFixture]::GetClipboardSequenceNumber()
    $info=New-Object Diagnostics.ProcessStartInfo
    $info.FileName=$Exe;$info.Arguments='--capture-only '+[SciFixture]::Handle.ToInt64()+' 0 0'
    $info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true
    $p=New-Object Diagnostics.Process;$p.StartInfo=$info;$buffer=New-Object IO.MemoryStream
    try{
        [void]$p.Start();$reader=$p.StandardOutput.BaseStream.CopyToAsync($buffer)
        if(-not $p.WaitForExit(8000)){$p.Kill();throw 'Scintilla capture timeout'}
        $reader.GetAwaiter().GetResult();$raw=$buffer.ToArray();$offset=0;$source=$null;$errorText=$null;$route=$null
        while($offset -lt $raw.Length){
            if($raw.Length-$offset -lt 8){throw 'Truncated frame'}
            $type=[BitConverter]::ToUInt32($raw,$offset);$len=[BitConverter]::ToUInt32($raw,$offset+4);$offset+=8
            if($len -gt 65536 -or $offset+$len -gt $raw.Length){throw 'Invalid frame'}
            $value=[Text.Encoding]::UTF8.GetString($raw,$offset,$len);$offset+=$len
            if($type -eq 1){$source=$value}elseif($type -eq 3){$errorText=$value}elseif($type -eq 6){$route=$value}else{throw 'Unexpected frame'}
        }
        if($select){if($source -ne [SciFixture]::Expected -or $route -notmatch 'Scintilla'){throw "Real Scintilla selected text mismatch: $errorText"}}
        else{if($null -ne $source -or -not $errorText){throw 'Empty selection exposed text'}}
        if([SciFixture]::GetClipboardSequenceNumber() -ne $before){throw 'Clipboard sequence changed during native capture (or outside interaction)'}
        Write-Output "PASS: real provided Scintilla DLL, selected=$select, offset > 65535, UTF-8 selection, unchanged clipboard sequence"
    }finally{if($p -and -not $p.HasExited){$p.Kill()};$p.Dispose();$buffer.Dispose()}
 }finally{[SciFixture]::Stop()}
}
