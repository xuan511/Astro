#include "../src/learning_draft.hpp"
#include <cassert>
#include <iostream>
template <class F> void fails(F f) {
    bool error = false;
    try {
        f();
    } catch (const std::exception &) {
        error = true;
    }
    assert(error);
}
int main() {
    std::string key(64, 'a'), device = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
                              peer = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb";
    qt::Notebook book;
    book.record(key, "interrupt", "中断", "fixture", device, 100);
    qt::LearningDraft draft;
    draft.load(book.find(key), "local");
    assert(!draft.dirty());
    draft.update("写到一半的笔记", false, false);
    assert(draft.dirty());
    auto before = book.json();
    fails([&] { draft.commit(book, "changed-context", device, 200); });
    assert(book.json() == before && draft.dirty());
    auto remote = *book.find(key);
    remote.rev = qt::revision(201, peer);
    remote.star = true;
    remote.known = true;
    remote.translation = "备份中的译文";
    book.merge(remote);
    assert(draft.commit(book, "local", device, 202));
    assert(!draft.dirty());
    assert(book.find(key)->note == "写到一半的笔记" && book.find(key)->star &&
           book.find(key)->known && book.find(key)->translation == remote.translation);
    auto saved = book.json();
    assert(!draft.commit(book, "local", device, 203));
    assert(book.json() == saved);
    draft.update(std::string(2001, 'x'), true, true);
    fails([&] { draft.commit(book, "local", device, 204); });
    assert(book.json() == saved && draft.dirty());
    draft.load(book.find(key), "local");
    draft.update("保留草稿", true, true);
    book.erase(key, device, 205);
    saved = book.json();
    fails([&] { draft.commit(book, "local", device, 206); });
    assert(book.json() == saved && draft.dirty());
    // A deleted peer entry is not resurrected by an unsaved note. User must discard or copy it.
    draft.load(nullptr, "local");
    assert(!draft.dirty());
    book.record(key, "interrupt", "中断", "fixture", device, 207, false, "词典真实返回的用法",
                true);
    assert(book.find(key)->star && book.find(key)->detail == "词典真实返回的用法" &&
           book.find(key)->due == 0 && book.find(key)->level == 0);
    draft.load(book.find(key), "local");
    draft.update(book.find(key)->note, false, false);
    assert(draft.commit(book, "local", device, 208));
    assert(!book.find(key)->star);
    std::cout << "PASS scope-bound note draft: edit context guard, concurrent untouched fields "
                 "preserved, "
                 "no-op save, invalid/deleted draft retention, explicit restore resets review\n";
}
