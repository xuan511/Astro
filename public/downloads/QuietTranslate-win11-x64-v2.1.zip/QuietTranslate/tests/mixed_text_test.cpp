#include "../src/api.hpp"
#include <cassert>
#include <iostream>
#include <random>
using namespace qt;
int main() {
    const std::string source = "中文说明很长：  Access is denied.  请检查权限。";
    auto p = planMixed(source);
    assert(p.mode == MixedMode::Extract && p.request == "Access is denied.");
    assert(p.request.size() < source.size() && !hasHan(p.request));
    assert(p.render(source, "访问被拒绝。") == "中文说明很长：  访问被拒绝。  请检查权限。");
    assert(p.render(source, "访问") == "中文说明很长：  访问  请检查权限。");
    auto q = planMixed("另一条备注：Access is denied.。 ");
    assert(q.request == p.request);
    assert(q.render("另一条备注：Access is denied.。 ", "拒绝访问") == "另一条备注：拒绝访问。 ");
    bool threw = false;
    try {
        p.render("unrelated source", "译文");
    } catch (...) {
        threw = true;
    }
    assert(threw);
    threw = false;
    try {
        p.render(source, std::string(30000, 'x'));
    } catch (...) {
        threw = true;
    }
    assert(threw);
    for (const std::string s :
         {"只有中文，无需翻译。", "在 Windows 11 上使用 Linux", "检查 API、SDK 和 VS Code。",
          "参数：boot_initial_cfg", "地址：https://example.invalid/a", "地址：C:\\Tools\\app.exe",
          "值：0xFF01", "运行 `git status` 后查看中文。",
          "代码：```c\nint main() { /* 中文 */ }\n```"}) {
        auto local = planMixed(s);
        assert(local.mode == MixedMode::Local && local.request.empty());
        assert(local.render(s, "ignored") == s);
    }
    assert(planMixed("错误：ERROR").request == "ERROR");
    assert(planMixed("系统：Windows", true, false).mode == MixedMode::Extract);
    assert(planMixed("提示：flash").request == "flash");
    assert(planMixed("在 Linux 上发生 Access denied").request == "Access denied");
    assert(planMixed("先运行 `foo_bar`，再检查 Permission denied。").request ==
           "Permission denied");
    const std::vector<std::string> whole = {"The driver requires a stable clock.",
                                            "Windows are open.",
                                            "这是 first error，然后 second error。",
                                            "第一句：Access denied\n下一句：File not found",
                                            "路径：`unclosed",
                                            "中文 café。",
                                            "中文 カタカナ text",
                                            "中文 😀 text",
                                            "中文 ＥＲＲＯＲ",
                                            "中文 ｶﾀｶﾅ",
                                            "中文" + std::string("\xc0\xaf", 2),
                                            "中文" + std::string("\xed\xa0\x80", 3),
                                            "中文" + std::string("\xf4\x90\x80\x80", 4),
                                            "中文" + std::string("\xe4\xb8", 2),
                                            "中文" + std::string(4000, 'a')};
    for (const auto &s : whole) {
        auto full = planMixed(s);
        assert(full.mode == MixedMode::Whole && full.request == s);
    }
    assert(hasHan("𠀀文本") && !hasHan("text"));
    assert(planMixed("𠀀说明：Access denied。").request == "Access denied");
    assert(planMixed(source, false).request == source);
    assert(planMixed(source, false).mode == MixedMode::Whole);
    // Transport spy: one request for an extracted or fallback job, no calls for local text.
    ApiConfig config;
    config.key = "fixture-not-a-key";
    for (int protocol : {0, 1, 2}) {
        config.protocol = protocol;
        config.model = protocol == 2 ? "qwen-mt-flash" : "fixture-model";
        for (const auto &s :
             {source, std::string("中文：first，另一个 second"), std::string("中文和 API")}) {
            auto plan = planMixed(s);
            unsigned calls = 0;
            if (plan.mode != MixedMode::Local) {
                ++calls;
                auto body = Parser(translationBody(config, plan.request)).parse();
                assert(body.at("messages").array.back().at("content").text == plan.request);
                if (plan.mode == MixedMode::Extract)
                    assert(!hasHan(plan.request));
                assert(!plan.render(s, "译文").empty());
            }
            assert(calls == (plan.mode == MixedMode::Local ? 0u : 1u));
        }
    }
    config.smartMixed = false;
    assert(!ApiConfig::parse(config.serialize()).smartMixed);
    auto legacy = config.serialize();
    auto at = legacy.find(",\"smart_mixed\":false");
    assert(at != std::string::npos);
    legacy.erase(at, std::string(",\"smart_mixed\":false").size());
    assert(ApiConfig::parse(legacy).smartMixed);
    std::mt19937 random(76);
    for (int k = 0; k < 10000; ++k) {
        std::string s = "中文";
        for (unsigned n = random() % 120; n; --n)
            s += char(random() % 256);
        auto plan = planMixed(s);
        assert(plan.mode != MixedMode::Extract ||
               s.substr(plan.begin, plan.end - plan.begin) == plan.request);
        assert(plan.mode != MixedMode::Extract || !hasHan(plan.request));
    }
    std::cout << "Mixed Chinese preservation, bounded UTF-8, reconstruction and single-request "
                 "policy passed\n";
}
