param([string]$Exe = (Join-Path $PSScriptRoot '..\QuietTranslate.exe'))
$ErrorActionPreference = 'Stop'
$info = New-Object Diagnostics.ProcessStartInfo
$info.FileName = (Resolve-Path $Exe).Path
$info.Arguments = '--learning-test'
$info.UseShellExecute = $false
$info.CreateNoWindow = $true
$info.RedirectStandardOutput = $true
$p = New-Object Diagnostics.Process
$p.StartInfo = $info
try {
    [void]$p.Start()
    $read = $p.StandardOutput.ReadToEndAsync()
    if (-not $p.WaitForExit(10000)) { $p.Kill(); throw 'Learning storage fixture timeout' }
    $output = $read.GetAwaiter().GetResult()
    if ($p.ExitCode -ne 0 -or $output -notmatch 'PASS learning SHA256') { throw 'Learning storage fixture failed' }
    Write-Output $output.Substring(8)
} finally {
    if (-not $p.HasExited) { $p.Kill() }
    $p.Dispose()
}
