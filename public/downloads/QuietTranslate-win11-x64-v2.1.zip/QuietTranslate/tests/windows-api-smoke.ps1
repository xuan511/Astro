﻿param([string]$Exe = (Join-Path $PSScriptRoot '..\QuietTranslate.exe'))
$ErrorActionPreference = 'Stop'
$Exe = (Resolve-Path $Exe).Path
# In-process fake API transport, no real key, settings, or network.
function Invoke-ApiBatch([string[]]$Samples, [bool]$Cache, [string]$Config) {
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $Exe
    $info.Arguments = '--api-test-service ' + [int]$Cache
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardInput = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $p = New-Object Diagnostics.Process
    $p.StartInfo = $info
    $started = $false
    $buffer = New-Object IO.MemoryStream
    try {
        [void]$p.Start(); $started = $true
        $readTask = $p.StandardOutput.BaseStream.CopyToAsync($buffer)
        $cfg = [Text.Encoding]::UTF8.GetBytes($Config)
        $head = [BitConverter]::GetBytes([uint32]20) + [BitConverter]::GetBytes([uint32]$cfg.Length)
        $p.StandardInput.BaseStream.Write($head, 0, 8)
        $p.StandardInput.BaseStream.Write($cfg, 0, $cfg.Length)
        foreach ($sample in $Samples) {
            $b = [Text.Encoding]::UTF8.GetBytes($sample)
            $header = [BitConverter]::GetBytes([uint32]10) + [BitConverter]::GetBytes([uint32]$b.Length)
            $p.StandardInput.BaseStream.Write($header, 0, 8)
            $p.StandardInput.BaseStream.Write($b, 0, $b.Length)
        }
        $p.StandardInput.Close()
        if (-not $p.WaitForExit(5000)) { $p.Kill(); throw 'Service timeout' }
        $readTask.GetAwaiter().GetResult()
        if ($p.ExitCode -ne 0) { throw 'Service exited abnormally' }
        $raw = $buffer.ToArray(); $offset = 0; $frames = @()
        while ($offset -lt $raw.Length) {
            if ($raw.Length - $offset -lt 8) { throw 'Truncated frame' }
            $type = [BitConverter]::ToUInt32($raw, $offset)
            $len = [BitConverter]::ToUInt32($raw, $offset + 4); $offset += 8
            if ($len -gt 65536 -or $offset + $len -gt $raw.Length) { throw 'Invalid frame size' }
            $frames += [pscustomobject]@{ Type=$type; Text=[Text.Encoding]::UTF8.GetString($raw, $offset, $len) }
            $offset += $len
        }
        return ,$frames
    } finally {
        if ($started -and -not $p.HasExited) { $p.Kill() }
        $buffer.Dispose(); $p.Dispose()
    }
}
$cfg = '{"base":"https://example.invalid/v1","model":"custom/tiny","key":"fixture-only-not-a-real-key","protocol":0,"stream":true,"max_tokens":2048,"modern_limit":false}'
$frames = Invoke-ApiBatch @('alpha', 'alpha', 'FAIL', 'after-error') $true $cfg
if (@($frames | Where-Object Type -eq 2).Count -ne 3) { throw 'API persistent requests failed' }
if (@($frames | Where-Object Type -eq 3).Count -ne 1) { throw 'API error recovery failed' }
if (@($frames | Where-Object Type -eq 5).Count -ne 1) { throw 'API cache missed' }
if (@($frames | Where-Object Type -eq 4).Count -ne 2) { throw 'Expected one progress result per uncached success' }
if (@($frames | Where-Object Type -eq 9).Count -ne 3) { throw 'API attempt metadata count mismatch (cache must not start a request)' }
$usageFrames = @($frames | Where-Object Type -eq 8)
if ($usageFrames.Count -ne 2) { throw 'Expected one usage frame per uncached fake success' }
foreach ($f in $usageFrames) { $u = $f.Text | ConvertFrom-Json; if ($u.input_tokens -ne 10 -or $u.output_tokens -ne 5 -or $u.total_tokens -ne 15) { throw 'Usage metadata mismatch' } }
if (($frames | ConvertTo-Json -Depth 5) -match 'fixture-only-not-a-real-key') { throw 'Key leaked into result protocol' }
$frames = Invoke-ApiBatch @('alpha', 'alpha') $false $cfg
if (@($frames | Where-Object Type -eq 5).Count -ne 0) { throw 'API cache disable failed' }
$frames = Invoke-ApiBatch @('alpha') $true ($cfg.Replace('custom/tiny','different/model'))
if (@($frames | Where-Object Type -eq 5).Count -ne 0) { throw 'API cache crossed a worker configuration' }
# Technical names are returned locally, with no API-attempt/usage frames even without cache.
$frames = Invoke-ApiBatch @('Windows', 'Windows 11', 'VS Code', 'API', 'STM32F407') $false $cfg
if (@($frames | Where-Object Type -eq 2).Count -ne 5 -or @($frames | Where-Object Type -eq 3).Count -ne 0) { throw 'Local technical name handling failed' }
if (@($frames | Where-Object { $_.Type -eq 8 -or $_.Type -eq 9 }).Count -ne 0) { throw 'Technical name handling created API usage' }
$names = @($frames | Where-Object Type -eq 2 | ForEach-Object Text)
if (($names -join '|') -cne 'Windows|Windows 11|VS Code|API|STM32F407') { throw 'Technical names not preserved verbatim' }
$frames = Invoke-ApiBatch @('windows', 'Windows requires a restart.') $false $cfg
if (@($frames | Where-Object Type -eq 9).Count -ne 2) { throw 'Ordinary words/sentences were incorrectly skipped' }
$literalCfg = $cfg.Replace('"modern_limit":false', '"modern_limit":false,"keep_terms":false')
$frames = Invoke-ApiBatch @('Windows') $false $literalCfg
if (@($frames | Where-Object Type -eq 9).Count -ne 1) { throw 'Disabled term preservation was ignored' }
# DPAPI fixture runs through the actual Windows API, without changing application preferences.
$info = New-Object Diagnostics.ProcessStartInfo
$info.FileName = $Exe; $info.Arguments = '--api-key-test'
$info.UseShellExecute = $false; $info.CreateNoWindow = $true; $info.RedirectStandardOutput = $true
$p = New-Object Diagnostics.Process; $p.StartInfo = $info
try {
    [void]$p.Start(); $readTask = $p.StandardOutput.ReadToEndAsync()
    if (-not $p.WaitForExit(5000)) { $p.Kill(); throw 'DPAPI timeout' }
    $output = $readTask.GetAwaiter().GetResult()
    if ($p.ExitCode -ne 0 -or $output -notmatch 'PASS DPAPI') { throw 'DPAPI fixture failed' }
} finally { $p.Dispose() }
Write-Output 'PASS: API IPC/configuration, cache boundaries, error recovery, no key in result frames, DPAPI current-user fixture. No live API tested.'
