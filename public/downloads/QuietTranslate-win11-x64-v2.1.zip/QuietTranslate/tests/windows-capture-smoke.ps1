﻿param([string]$Exe=(Join-Path $PSScriptRoot '..\QuietTranslate.exe'),[switch]$AllowSkip,[switch]$AllowClipboardChanges)
$ErrorActionPreference='Stop'
$Exe=(Resolve-Path $Exe).Path
# Interactive test: own fixtures only. Default: no clipboard writes.
# Explicit -AllowClipboardChanges also tests WM_COPY and replaces CURRENT clipboard contents with fixture text.
Add-Type -ReferencedAssemblies System.Windows.Forms,System.Drawing -TypeDefinition @'
using System;
using System.Threading;
using System.Windows.Forms;
using System.Runtime.InteropServices;
public static class CaptureFixture {
    static Thread thread; static Form window; static ManualResetEvent ready;
    public static IntPtr Handle;public static int X,Y;
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    public static bool Start(string kind, bool select) {
        ready=new ManualResetEvent(false); Handle=IntPtr.Zero;
        thread=new Thread(delegate() {
            window=new Form(); window.Text="QuietTranslate - controlled capture fixture";
            window.Width=640;window.Height=240;window.TopMost=true;
            Control box;
            if(kind=="label")box=new Label();
            else if(kind=="rich")box=new RichTextBox();
            else {var edit=new TextBox();edit.Multiline=kind!="password";edit.UseSystemPasswordChar=kind=="password";box=edit;}
            box.Dock=DockStyle.Fill;box.Text="First alpha beta last";window.Controls.Add(box);
            window.Shown+=delegate { window.BeginInvoke((MethodInvoker)delegate {
                window.Activate();box.Focus();if(box is TextBoxBase)((TextBoxBase)box).Select(6,select?10:0);var point=box.PointToScreen(new System.Drawing.Point(20,20));X=point.X;Y=point.Y;Handle=window.Handle;ready.Set();
            }); };
            Application.Run(window);
        });
        thread.IsBackground=true;thread.SetApartmentState(ApartmentState.STA);thread.Start();
        return ready.WaitOne(5000);
    }
    public static string Text() {return (string)window.Invoke((Func<string>)(delegate{return window.Controls[0].Text;}));}
    public static void Stop() {
        if(window!=null&&!window.IsDisposed)try{window.BeginInvoke((MethodInvoker)delegate{window.Close();});}catch{}
        if(thread!=null)thread.Join(2000);
    }
}
'@
function Invoke-Capture([long]$Target,[bool]$Copy=$false,[bool]$Point=$false) {
    $info=New-Object Diagnostics.ProcessStartInfo
    $info.FileName=$Exe;$info.Arguments=if($Point){"--point-only $Target $([CaptureFixture]::X) $([CaptureFixture]::Y)"}elseif($Copy){"--capture-copy $Target"}else{"--capture-only $Target 0 0"}
    $info.UseShellExecute=$false;$info.CreateNoWindow=$true
    $info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
    $p=New-Object Diagnostics.Process;$p.StartInfo=$info
    $memory=New-Object IO.MemoryStream;$started=$false
    try {
        [void]$p.Start();$started=$true
        $reader=$p.StandardOutput.BaseStream.CopyToAsync($memory)
        if(-not $p.WaitForExit(8000)){$p.Kill();throw 'Capture worker timeout'}
        $reader.GetAwaiter().GetResult();$raw=$memory.ToArray()
        if($raw.Length -lt 8){throw 'Missing capture response'}
        $offset=0; $result=$null
        while($offset -lt $raw.Length){
            if($raw.Length-$offset -lt 8){throw 'Truncated capture frame'}
            $type=[BitConverter]::ToUInt32($raw,$offset);$count=[BitConverter]::ToUInt32($raw,$offset+4);$offset+=8
            if($count -gt 65536 -or $offset+$count -gt $raw.Length){throw 'Invalid capture frame'}
            $text=[Text.Encoding]::UTF8.GetString($raw,$offset,$count);$offset+=$count
            if($type -eq 6){continue}
            if($result){throw 'Multiple final capture results'}
            $result=[pscustomobject]@{Type=$type;Text=$text}
        }
        if(-not $result){throw 'Missing final capture result'}
        return $result
    } finally {if($started -and -not $p.HasExited){$p.Kill()};$memory.Dispose();$p.Dispose()}
}
foreach($kind in @('edit','rich','password','empty','point')) {
    try {
        $widget=if($kind -eq 'empty'){'edit'}elseif($kind -eq 'point'){'label'}else{$kind}
        if(-not [CaptureFixture]::Start($widget,($kind -ne 'empty'))){throw 'Fixture did not initialize'}
        $target=[CaptureFixture]::Handle.ToInt64()
        if([CaptureFixture]::GetForegroundWindow().ToInt64() -ne $target){
            if($AllowSkip){Write-Warning 'SKIP: interactive foreground desktop unavailable; capture compatibility NOT verified.';exit 0}
            throw 'An interactive unlocked Windows desktop is required. No user window was inspected.'
        }
        $result=Invoke-Capture $target $false ($kind -eq 'point')
        if($kind -eq 'point'){if($result.Type -ne 1 -or $result.Text -ne 'First alpha beta last'){throw "point label test failed: $($result.Text)"}}
        elseif($kind -eq 'edit' -or $kind -eq 'rich'){
            if($result.Type -ne 1 -or $result.Text -ne 'alpha beta'){throw "$kind selected-range test failed: $($result.Text)"}
        }else{
            if($result.Type -ne 3 -or $result.Text.Contains('alpha beta')){throw "$kind must not expose source text"}
        }
        if([CaptureFixture]::Text() -ne 'First alpha beta last'){throw "$kind document changed"}
        if($AllowClipboardChanges -and $kind -ne 'point'){
            $copy=Invoke-Capture $target $true
            if($kind -eq 'edit' -or $kind -eq 'rich'){
                if($copy.Type -ne 1 -or $copy.Text -ne 'alpha beta'){throw "$kind one-key WM_COPY failed: $($copy.Text)"}
            }else{if($copy.Type -ne 3){throw "$kind copied without valid selection"}}
            if([CaptureFixture]::Text() -ne 'First alpha beta last'){throw "$kind changed after WM_COPY"}
            Write-Output "PASS: controlled $kind one-key WM_COPY; clipboard changed when selection valid"
        }
        Write-Output "PASS: controlled $kind fixture"
    } finally {[CaptureFixture]::Stop()}
}
