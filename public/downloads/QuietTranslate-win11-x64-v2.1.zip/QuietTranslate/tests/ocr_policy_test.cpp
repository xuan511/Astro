#include "../src/ocr_policy.hpp"
#include <cassert>
#include <iostream>
template <class F> void fails(F f) {
    bool threw = false;
    try {
        f();
    } catch (const std::exception &) {
        threw = true;
    }
    assert(threw);
}
int main() {
    qt::OcrBounds bounds{-1920, -400, 3840, 2160};
    auto r = qt::ocrDrag(-10, 100, -400, -100, bounds);
    assert(r.x == -400 && r.y == -100 && r.width == 390 && r.height == 200);
    qt::validateOcrRegion(r, bounds);
    r = qt::ocrDrag(-9999, -9999, 100, 100, bounds);
    assert(r.x == -1920 && r.y == -400);
    for (auto bad : {qt::OcrRegion{0, 0, 0, 200},
                     {-2000, 0, 200, 200},
                     {0, 0, 4097, 10},
                     {0, 0, 3000, 2001},
                     {3830, 0, 20, 100},
                     {INT32_MAX, INT32_MAX, 20, 20}})
        fails([&] { qt::validateOcrRegion(bad, bounds); });
    assert(qt::ocrCoordinate("-2147483648") == INT32_MIN &&
           qt::ocrCoordinate("2147483647") == INT32_MAX);
    for (auto bad : {"2147483648", "-2147483649", "4junk", "1;calc", "", "-", "9999999999999"})
        fails([&] { qt::ocrCoordinate(bad); });
    std::vector<uint8_t> image(100 * 40 * 4, 255);
    auto light = qt::ocrGray(image.data(), image.size(), 100, 40);
    assert(light.scale == 2 && !light.inverted && light.width == 232 && light.height == 112 &&
           light.pixels.front() == 255);
    std::fill(image.begin(), image.end(), 0);
    auto dark = qt::ocrGray(image.data(), image.size(), 100, 40);
    assert(dark.inverted && dark.pixels[16 * dark.width + 16] == 255);
    image[0] = 0;
    image[1] = 0;
    image[2] = 255;
    auto color = qt::ocrGray(image.data(), image.size(), 100, 40);
    assert(color.pixels[16 * color.width + 16] == 255 - 76);
    fails([&] { qt::ocrGray(image.data(), image.size() - 1, 100, 40); });
    fails([&] { qt::ocrGray(nullptr, 0, 100, 40); });
    std::vector<uint8_t> large(3000 * 2000 * 4, 255);
    auto cap = qt::ocrGray(large.data(), large.size(), 3000, 2000);
    assert(cap.scale == 1 && cap.width == 3000 && cap.height == 2000 &&
           cap.pixels.size() == 6000000);
    assert(qt::ocrText("  hello\nworld\n ") == "hello\nworld");
    for (auto s :
         {std::string(""), std::string("123456"), std::string(4001, 'a'), std::string("word\x01")})
        fails([&] { qt::ocrText(s); });
    for (int i = 0; i < 1000; ++i) {
        auto rr = qt::ocrDrag(i - 1500, 20, i - 1400, 80, bounds);
        qt::validateOcrRegion(rr, bounds);
        assert(rr.width == 100 && rr.height == 60);
    }
    std::cout << "PASS OCR policy: physical/negative-monitor coordinates, reverse drag, clamp, "
                 "integer overflow, region/pixel bounds, light/dark grayscale, scaling/border cap, "
                 "output length/control rejection; no screenshot or Windows APIs\n";
}
