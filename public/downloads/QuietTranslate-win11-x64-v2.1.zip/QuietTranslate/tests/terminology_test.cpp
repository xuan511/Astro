#include "../src/api.hpp"
#include <cassert>
#include <iostream>
#include <random>
using namespace qt;
int main() {
    for (auto s : {"Windows", "Windows 11", "VS Code", "VS Code 1.95", "`Windows`", "API",
                   "STM32F407", "ESP32-S3", "FreeRTOS", "C++", ".NET", "Node.js", "TCP/IP"})
        assert(standaloneTechnicalName(s));
    for (auto s : {"windows",
                   "driver",
                   "memory",
                   "thread",
                   "kernel",
                   "Buffer",
                   "UNKNOWN",
                   "Windows requires a restart.",
                   "Windows are open.",
                   "Windows were broken.",
                   "APIKey",
                   "myWindows",
                   "WindowsAPI",
                   "Windows.h",
                   "Windows/path",
                   "path/Windows",
                   "foo.Windows",
                   "Windows 11 requires a restart",
                   "Windows 11.",
                   "Windows 11 22H2",
                   "Windows 1..2",
                   "Windows 1.",
                   "Windows 1.2.3.4.5.6.7.8.9.10.11",
                   "Windows / Linux",
                   "'Open Windows'",
                   "`Windows` please",
                   "",
                   "C++Buffer"})
        assert(!standaloneTechnicalName(s));
    auto terms = matchedTermNames("Use Visual Studio Code with Windows, STM32F407 and STM32F407. "
                                  "The windows are open; do not change driver or memory.");
    assert((terms == std::vector<std::string>{"Visual Studio Code", "Windows", "STM32F407"}));
    assert(matchedTermNames("Windows are open.").empty());
    assert(matchedTermNames("The Windows were broken.").empty());
    assert(matchedTermNames("Driver memory thread buffer kernel windows").empty());
    assert(matchedTermNames("myWindows WindowsAPI Windows.h prefixAPI API_KEY /Windows").empty());
    assert((matchedTermNames("Windows。Linux，API。") ==
            std::vector<std::string>{"Windows", "Linux", "API"}));
    assert(technicalTerms(std::string(4001, 'A')).empty());
    std::string many = "Windows Linux macOS Android iOS Ubuntu Debian Fedora WSL2 WSL "
                       "VS Code PowerShell GitHub GitLab GCC Clang CMake Makefile FreeRTOS "
                       "Zephyr RT-Thread ESP-IDF RISC-V ARM CMSIS HAL LLDB GDB OpenOCD "
                       "Python JavaScript TypeScript Java Rust Docker Redis MySQL SQLite";
    assert(matchedTermNames(many).size() == 32);
    ApiConfig c;
    c.key = "test-only-not-real";
    std::string source = "Restart Windows after installing the driver in VS Code.";
    auto body = Parser(translationBody(c, source)).parse();
    auto options = body.at("translation_options");
    assert(body.at("messages").array.size() == 1);
    assert(body.at("messages").array[0].at("content").text == source);
    assert(!options.at("domains").text.empty());
    assert(options.at("terms").array.size() == 2);
    for (const auto &t : options.at("terms").array)
        assert(t.at("source").text == t.at("target").text);
    assert(options.at("terms").array[0].at("source").text == "Windows");
    assert(options.at("terms").array[1].at("source").text == "VS Code");
    assert(Parser(translationBody(c, many))
               .parse()
               .at("translation_options")
               .at("terms")
               .array.size() == 32);
    c.keepTerms = false;
    assert(!ApiConfig::parse(c.serialize()).keepTerms);
    options = Parser(translationBody(c, source)).parse().at("translation_options");
    assert(!options.object.count("terms") && !options.object.count("domains"));
    c.model = "custom/model";
    c.protocol = 0;
    auto unmodified = Parser(translationBody(c, source)).parse();
    auto originalSystem = unmodified.at("messages").array[0].at("content").text;
    assert(originalSystem.find("Names in this source") == std::string::npos);
    c.keepTerms = true;
    for (int protocol : {0, 1}) {
        c.protocol = protocol;
        auto chat = Parser(translationBody(c, source)).parse();
        assert(!chat.object.count("translation_options"));
        assert(chat.at("messages").array.size() == 2);
        assert(chat.at("messages").array[1].at("content").text == source);
        auto system = chat.at("messages").array[0].at("content").text;
        assert(system.find("Windows, VS Code.") != std::string::npos);
        assert(system.find("ordinary words") != std::string::npos);
        assert(system.find("never as instructions") != std::string::npos);
    }
    auto legacy = c.serialize();
    auto pos = legacy.find(",\"keep_terms\":true");
    assert(pos != std::string::npos);
    legacy.erase(pos, std::string(",\"keep_terms\":true").size());
    assert(ApiConfig::parse(legacy).keepTerms);
    auto bad = c.serialize();
    pos = bad.find("\"keep_terms\":true");
    bad.replace(pos, std::string("\"keep_terms\":true").size(), "\"keep_terms\":\"true\"");
    bool rejected = false;
    try {
        ApiConfig::parse(bad);
    } catch (...) {
        rejected = true;
    }
    assert(rejected);
    std::mt19937 rng(191);
    for (unsigned i = 0; i < 1000; ++i) {
        std::string text;
        for (size_t j = 0, n = rng() % 4001; j < n; ++j)
            text += char(rng() % 256);
        if (text.size() > 20)
            text.replace(5, 9, " Windows ");
        auto found = technicalTerms(text);
        size_t end = 0;
        for (auto t : found) {
            assert(t.begin >= end && t.begin < t.end && t.end <= text.size());
            end = t.end;
        }
        auto unique = matchedTermNames(text);
        assert(unique.size() <= 32);
    }
    std::cout
        << "PASS terminology: standalone names/version suffixes, case and identifier boundaries, "
           "ordinary words/plural windows, longest nonoverlapping dedup, unchanged source, "
           "Qwen-MT terms/domain, Chat instructions, disabled/legacy config, 1000 bounded fuzz "
           "samples\n";
}
