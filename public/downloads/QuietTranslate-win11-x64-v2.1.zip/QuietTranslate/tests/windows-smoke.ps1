﻿param([string]$Exe = (Join-Path $PSScriptRoot '..\QuietTranslate.exe'))
$ErrorActionPreference = 'Stop'
$Exe = (Resolve-Path $Exe).Path
function Invoke-Offline([string]$Sample) {
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = $Exe
    $info.Arguments = '--translate 0'
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardInput = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $info
    $started = $false
    try {
        [void]$p.Start()
        $started = $true
        $bytes = [Text.Encoding]::UTF8.GetBytes($Sample)
        $p.StandardInput.BaseStream.Write($bytes, 0, $bytes.Length)
        $p.StandardInput.Close()
        $buffer = New-Object IO.MemoryStream
        $readTask = $p.StandardOutput.BaseStream.CopyToAsync($buffer)
        if (-not $p.WaitForExit(5000)) { $p.Kill(); throw 'Worker timeout' }
        $readTask.GetAwaiter().GetResult()
        $raw = $buffer.ToArray()
        $buffer.Dispose()
        $offset = 0
        $frames = @()
        while ($offset -lt $raw.Length) {
            if ($raw.Length - $offset -lt 8) { throw 'Truncated frame header' }
            $type = [BitConverter]::ToUInt32($raw, $offset)
            $len = [BitConverter]::ToUInt32($raw, $offset + 4)
            $offset += 8
            if ($len -gt 65536 -or $offset + $len -gt $raw.Length) { throw 'Invalid frame length' }
            $value = [Text.Encoding]::UTF8.GetString($raw, $offset, $len)
            $frames += [pscustomobject]@{ Type=$type; Text=$value }
            $offset += $len
        }
        return ,$frames
    } finally { if ($started -and -not $p.HasExited) { $p.Kill() }; $p.Dispose() }
}
$frames = Invoke-Offline 'volatile'
if ($frames.Count -ne 2 -or $frames[0].Type -ne 1 -or $frames[1].Type -ne 2 -or $frames[1].Text -notmatch 'volatile|限定符') { throw 'Glossary test failed' }
$frames = Invoke-Offline 'undefined behavior'
if ($frames.Count -ne 2 -or $frames[1].Text -notmatch 'UB') { throw 'Phrase test failed' }
$frames = Invoke-Offline 'not-in-the-built-in-dictionary-xyz'
if ($frames.Count -ne 2 -or $frames[1].Type -ne 2) { throw 'Missing term test failed' }
$frames = Invoke-Offline ''
if ($frames.Count -ne 1 -or $frames[0].Type -ne 3) { throw 'Empty input test failed' }
Write-Output 'PASS: native offline worker framing, glossary, phrase, missing term and empty input.'
