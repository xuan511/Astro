#include "../src/ocr_engine.hpp"
#include <fstream>
#include <iterator>
#include <iostream>
int main(int argc, char **argv) {
    if (argc != 5 && argc != 6) {
        std::cerr << "model grayscale.raw width height\n";
        return 2;
    }
    try {
        std::ifstream m(argv[1], std::ios::binary), f(argv[2], std::ios::binary);
        std::string model((std::istreambuf_iterator<char>(m)), {}),
            input((std::istreambuf_iterator<char>(f)), {});
        int width = std::stoi(argv[3]), height = std::stoi(argv[4]);
        if (width < 8 || height < 8 || (uint64_t)width * height > qt::ocrMaxPixels ||
            input.size() != (uint64_t)width * height * 4)
            throw std::runtime_error("fixture dimensions invalid");
        auto gray = qt::ocrGray((const uint8_t *)input.data(), input.size(), width, height);
        auto result = qt::recognizeEnglish(gray, model);
        if ((argc == 6 && result.text.find(argv[5]) == std::string::npos) ||
            (argc == 5 && (result.text.find("driver") == std::string::npos ||
                           result.text.find("transfer") == std::string::npos)))
            throw std::runtime_error("actual OCR lost fixture keywords");
        std::cout << "PASS actual OCR " << tesseract::TessBaseAPI::Version() << ": "
                  << result.confidence << "% engine confidence; " << result.text << "\n";
        return 0;
    } catch (const std::exception &e) {
        std::cerr << e.what() << "\n";
        return 1;
    }
}
