#include "../src/online.hpp"
#include <cassert>
#include <iostream>
#include <random>
#include <stdexcept>

static std::string encoded(uint32_t type, const std::string &s) {
    std::string out;
    for (int i = 0; i < 4; ++i)
        out += char(type >> (8 * i));
    for (int i = 0; i < 4; ++i)
        out += char(uint32_t(s.size()) >> (8 * i));
    return out + s;
}
int main() {
    qt::MemoryCache cache(2, 20, 100);
    std::string out;
    cache.put("a", "one", 10);
    cache.put("b", "two", 20);
    assert(cache.bytes() == 8);
    assert(cache.nextExpiry() == 110);
    assert(cache.get("a", 30, out) && out == "one");
    cache.put("c", "three", 40);
    assert(!cache.get("b", 45, out));
    assert(cache.get("a", 45, out));
    cache.expire(110);
    assert(!cache.get("a", 110, out));
    assert(cache.get("c", 110, out));
    cache.put("x", std::string(30, 'x'), 120);
    assert(cache.bytes() <= 20);
    assert(!cache.get("x", 121, out));
    cache.clear();
    assert(cache.size() == 0 && cache.bytes() == 0 && cache.nextExpiry() == 0);
    cache.put("q", "z", 1000);
    assert(!cache.get("q", 999, out)); // monotonic clock rollback: fail closed
    qt::MemoryCache byteBound(100, 10);
    byteBound.put("a", "12345", 0);
    byteBound.put("b", "67890", 1);
    assert(byteBound.size() == 1 && byteBound.bytes() == 6);
    qt::OnlineEngine engine;
    uint64_t now = 0;
    size_t calls = 0;
    std::vector<size_t> seen;
    std::string source = std::string(500, 'A') + std::string(500, 'B');
    auto request = [&](const std::string &part) {
        ++calls;
        ++now;
        assert(part.size() <= 500);
        return "译:" + part;
    };
    auto progress = [&](const qt::TranslationProgress &p) {
        assert(p.completed == seen.size() + 1);
        seen.push_back(calls);
    };
    auto first = engine.translate(source, true, request, [&] { return now; }, progress);
    assert(first.requests == 2 && first.hits == 0 && calls == 2);
    assert((seen == std::vector<size_t>{1, 2}));
    seen.clear();
    auto repeat = engine.translate(source, true, request, [&] { return now; }, progress);
    assert(repeat.requests == 0 && repeat.hits == 2 && calls == 2 && repeat.text == first.text);
    auto changed = engine.translate(
        std::string(500, 'A') + std::string(500, 'C'), true, request, [&] { return now; },
        [](auto &) {});
    assert(changed.requests == 1 && changed.hits == 1 && calls == 3);
    auto disabled = engine.translate(source, false, request, [&] { return now; }, [](auto &) {});
    assert(disabled.requests == 2 && disabled.hits == 0 && calls == 5);
    now = 700000;
    auto expired = engine.translate(source, true, request, [&] { return now; }, [](auto &) {});
    assert(expired.requests == 2 && expired.hits == 0);
    qt::OnlineEngine failing;
    size_t attempt = 0;
    bool failed = false;
    std::string partial;
    try {
        failing.translate(
            source, true,
            [&](const std::string &part) {
                if (++attempt == 2)
                    throw std::runtime_error("network");
                return part;
            },
            [&] { return now; }, [&](auto &p) { partial = p.text; });
    } catch (...) {
        failed = true;
    }
    assert(failed && partial == std::string(500, 'A'));
    auto retry = failing.translate(source, true, request, [&] { return now; }, [](auto &) {});
    assert(retry.requests == 1 &&
           retry.hits == 1); // successful prefix retained, failed segment not cached
    for (auto invalid : {std::string(), std::string("123"), std::string(4001, 'x')}) {
        bool rejected = false;
        try {
            engine.translate(invalid, true, request, [&] { return now; }, [](auto &) {});
        } catch (...) {
            rejected = true;
        }
        assert(rejected);
    }
    assert(qt::chunks(source, 450).size() == 3 && qt::chunks(source, 500).size() == 2);
    // Feed the same IPC framing used by the actual UI in random pipe-sized fragments.
    std::string stream = encoded(4, "中文片段 😀") + encoded(5, "2/3") + encoded(2, "完成");
    std::mt19937 rng(21);
    for (int run = 0; run < 1000; ++run) {
        qt::FrameDecoder decoder;
        std::vector<qt::Frame> frames;
        size_t pos = 0;
        while (pos < stream.size()) {
            size_t n = std::min<size_t>(1 + rng() % 13, stream.size() - pos);
            decoder.feed(stream.data() + pos, n);
            pos += n;
            qt::Frame f;
            while (decoder.pop(f))
                frames.push_back(f);
        }
        assert(decoder.empty() && frames.size() == 3 && frames[0].text == "中文片段 😀" &&
               frames[2].type == 2);
    }
    bool bad = false;
    try {
        qt::FrameDecoder d;
        std::string huge = encoded(1, "");
        huge[4] = 1;
        huge[5] = 0;
        huge[6] = 1;
        d.feed(huge.data(), 8);
        qt::Frame f;
        d.pop(f);
    } catch (...) {
        bad = true;
    }
    assert(bad);
    std::cout << "PASS: bounded LRU/TTL, cache disable/clear, first-part progress, failure/retry, "
                 "1000 fragmented IPC cases\n";
    std::cout << "Synthetic 1000-byte sample: old splitting=3 requests; new cold=2; repeated "
                 "warm=0. Not a network latency benchmark.\n";
}
