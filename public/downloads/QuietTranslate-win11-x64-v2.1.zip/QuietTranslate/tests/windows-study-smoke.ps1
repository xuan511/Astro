﻿param([string]$Exe = (Join-Path $PSScriptRoot '..\QuietTranslate.exe'))
$ErrorActionPreference = 'Stop'
$Exe = (Resolve-Path $Exe).Path
function Invoke-Study([string]$Word) {
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $Exe
    $info.Arguments = '--study-test'
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardInput = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $p = New-Object Diagnostics.Process
    $p.StartInfo = $info
    $started = $false
    $buffer = New-Object IO.MemoryStream
    try {
        [void]$p.Start(); $started = $true
        $readTask = $p.StandardOutput.BaseStream.CopyToAsync($buffer)
        $bytes = [Text.Encoding]::UTF8.GetBytes($Word)
        $header = [BitConverter]::GetBytes([uint32]10) + [BitConverter]::GetBytes([uint32]$bytes.Length)
        $p.StandardInput.BaseStream.Write($header, 0, 8)
        if ($bytes.Length -le 40) { $p.StandardInput.BaseStream.Write($bytes, 0, $bytes.Length) }
        $p.StandardInput.Close()
        if (-not $p.WaitForExit(5000)) { $p.Kill(); throw 'Study worker timeout' }
        $readTask.GetAwaiter().GetResult()
        $raw = $buffer.ToArray(); $offset=0; $frames=@()
        while ($offset -lt $raw.Length) {
            if ($raw.Length-$offset -lt 8) { throw 'Truncated study frame' }
            $kind=[BitConverter]::ToUInt32($raw,$offset)
            $len=[BitConverter]::ToUInt32($raw,$offset+4); $offset+=8
            if ($len -gt 65536 -or $offset+$len -gt $raw.Length) { throw 'Invalid study frame length' }
            $frames += [pscustomobject]@{ Type=$kind; Text=[Text.Encoding]::UTF8.GetString($raw,$offset,$len) }
            $offset+=$len
        }
        return ,$frames
    } finally {
        if ($started -and -not $p.HasExited) { $p.Kill() }
        $buffer.Dispose(); $p.Dispose()
    }
}
$frames=Invoke-Study 'require'
if ($frames.Count -ne 2 -or $frames[0].Type -ne 4 -or $frames[1].Type -ne 2) { throw 'Study progress/final protocol failed' }
if ($frames[0].Text -notmatch 'stable clock' -or $frames[1].Text -notmatch '需要稳定的时钟' -or $frames[1].Text -notmatch 'Test fixture') { throw 'Study example/translation/attribution failed' }
$frames=Invoke-Study '../private'
if ($frames.Count -ne 1 -or $frames[0].Type -ne 3) { throw 'Unsafe word input not rejected' }
$frames=Invoke-Study ('x' * 41)
if ($frames.Count -ne 1 -or $frames[0].Type -ne 3) { throw 'Oversized word input not rejected' }
Write-Output 'PASS: study worker progress, bilingual fixture, attribution and invalid input. No live network used.'
