@echo off
setlocal
where cl >nul 2>nul
if errorlevel 1 (
  echo Please use the x64 Native Tools Command Prompt for VS 2022.
  exit /b 1
)
if not exist build mkdir build
rc /nologo /c 65001 /fo build\app.res app.rc
if errorlevel 1 exit /b 1
cl /nologo /std:c++17 /EHsc /utf-8 /O2 /W4 /MT /Fobuild\main.obj src\main.cpp build\app.res /Febuild\QuietTranslate.exe /link /SUBSYSTEM:WINDOWS /MANIFEST:NO /DYNAMICBASE /NXCOMPAT /HIGHENTROPYVA /OPT:REF /OPT:ICF user32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib winhttp.lib comctl32.lib gdi32.lib crypt32.lib comdlg32.lib dwmapi.lib
if errorlevel 1 exit /b 1
echo Built build\QuietTranslate.exe

echo OCR helper is a separate build: run build-ocr-windows.ps1 in this developer prompt.
