#pragma once
#include "terminology.hpp"
#include <cstdint>

namespace qt {
// All offsets are UTF-8 byte offsets. Invalid/unsupported text always keeps the full request.
struct MixedUnit {
    size_t begin, end;
    uint32_t cp;
};
inline bool hanCodepoint(uint32_t c) {
    return (c >= 0x3400 && c <= 0x4dbf) || (c >= 0x4e00 && c <= 0x9fff) ||
           (c >= 0xf900 && c <= 0xfaff) || (c >= 0x20000 && c <= 0x323af);
}
inline bool mixedUnits(const std::string &s, std::vector<MixedUnit> &out) {
    if (s.size() > 4000)
        return false;
    for (size_t i = 0; i < s.size();) {
        size_t begin = i;
        unsigned char first = s[i++];
        uint32_t cp = first;
        unsigned n = 0;
        if (first >= 0xc2 && first <= 0xdf) {
            cp = first & 31;
            n = 1;
        } else if (first >= 0xe0 && first <= 0xef) {
            cp = first & 15;
            n = 2;
        } else if (first >= 0xf0 && first <= 0xf4) {
            cp = first & 7;
            n = 3;
        } else if (first >= 128 || first == 0)
            return false;
        for (unsigned k = 0; k < n; ++k) {
            if (i >= s.size() || ((unsigned char)s[i] & 0xc0) != 0x80)
                return false;
            cp = (cp << 6) | ((unsigned char)s[i++] & 63);
        }
        if ((n == 1 && cp < 0x80) || (n == 2 && cp < 0x800) || (n == 3 && cp < 0x10000) ||
            (cp >= 0xd800 && cp <= 0xdfff) || cp > 0x10ffff)
            return false;
        out.push_back({begin, i, cp});
    }
    return true;
}
inline bool hasHan(const std::string &s) {
    std::vector<MixedUnit> units;
    if (!mixedUnits(s, units))
        return false;
    return std::any_of(units.begin(), units.end(),
                       [](const MixedUnit &u) { return hanCodepoint(u.cp); });
}
enum class MixedMode { Whole, Local, Extract };
struct MixedPlan {
    MixedMode mode = MixedMode::Whole;
    std::string request;
    size_t begin = 0, end = 0;
    std::string render(const std::string &original, const std::string &translated) const {
        if (mode == MixedMode::Local)
            return original;
        if (mode != MixedMode::Extract)
            return translated;
        if (begin > end || end > original.size() || original.substr(begin, end - begin) != request)
            throw std::runtime_error("混合文本位置无效。");
        if (translated.size() > 30000 ||
            original.size() - (end - begin) > 30000 - translated.size())
            throw std::runtime_error("译文过长。");
        return original.substr(0, begin) + translated + original.substr(end);
    }
};
inline bool mixedEdge(char c) {
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '"' || c == '\'';
}
inline bool mixedLiteral(const std::string &s, bool keepTerms) {
    if (keepTerms && standaloneTechnicalName(s))
        return true;
    if (s.find_first_of(" \t\r\n") != std::string::npos)
        return false;
    // Only explicit syntax, never guesses based on capitalization (ERROR needs translation).
    if (s.rfind("https://", 0) == 0 || s.rfind("http://", 0) == 0 || s.rfind("file://", 0) == 0 ||
        s.rfind("/", 0) == 0 || s.rfind("./", 0) == 0 || s.rfind("../", 0) == 0 ||
        s.rfind("\\\\", 0) == 0 ||
        (s.size() > 2 && std::isalpha((unsigned char)s[0]) && s[1] == ':' &&
         (s[2] == '\\' || s[2] == '/')))
        return true;
    if (s.size() > 2 && s[0] == '0' && (s[1] == 'x' || s[1] == 'X') &&
        std::all_of(s.begin() + 2, s.end(), [](unsigned char c) { return std::isxdigit(c); }))
        return true;
    return s.find('_') != std::string::npos && std::all_of(s.begin(), s.end(), [](unsigned char c) {
               return std::isalnum(c) || c == '_';
           });
}
inline MixedPlan planMixed(const std::string &source, bool enabled = true, bool keepTerms = true) {
    MixedPlan plan;
    plan.request = source;
    if (!enabled || source.empty())
        return plan;
    std::vector<MixedUnit> units;
    if (!mixedUnits(source, units))
        return plan;
    bool han = false;
    for (const auto &u : units) {
        han = han || hanCodepoint(u.cp);
        // Do not misidentify Japanese, Korean, Cyrillic, emoji or accented prose as Chinese.
        if (u.cp > 127 && !hanCodepoint(u.cp) && !(u.cp >= 0x3000 && u.cp <= 0x303f) &&
            !(u.cp >= 0xff01 && u.cp <= 0xff20) && !(u.cp >= 0xff3b && u.cp <= 0xff40) &&
            !(u.cp >= 0xff5b && u.cp <= 0xff65) && u.cp != 0x2018 && u.cp != 0x2019 &&
            u.cp != 0x201c && u.cp != 0x201d && u.cp != 0x2014 && u.cp != 0x2026)
            return plan;
        if (u.cp >= 0xff21 && u.cp <= 0xff5a)
            return plan; // Full-width Latin is not locally identified as English.
    }
    if (!han)
        return plan;
    size_t run = 0, candidateBegin = 0, candidateEnd = 0;
    unsigned candidates = 0;
    auto flush = [&](size_t end) {
        size_t a = run, b = end;
        while (a < b && mixedEdge(source[a]))
            ++a;
        while (b > a && mixedEdge(source[b - 1]))
            --b;
        auto part = source.substr(a, b - a);
        if (english(part) && !mixedLiteral(part, keepTerms)) {
            ++candidates;
            candidateBegin = a;
            candidateEnd = b;
        }
    };
    for (size_t i = 0; i < units.size(); ++i) {
        const auto &u = units[i];
        if (u.cp == '`') {
            flush(u.begin);
            size_t fence = 1;
            while (i + fence < units.size() && units[i + fence].cp == '`')
                ++fence;
            size_t from = u.begin + fence;
            auto close = source.find(std::string(fence, '`'), from);
            if (close == std::string::npos)
                return plan;
            size_t end = close + fence;
            while (i + 1 < units.size() && units[i + 1].begin < end)
                ++i;
            run = end;
        } else if (u.cp > 127 || u.cp == '\n' || u.cp == '\r') {
            flush(u.begin);
            run = u.end;
        }
        if (candidates > 1)
            return plan; // One original request, no fragment fan-out or paid retry.
    }
    flush(source.size());
    if (candidates > 1)
        return plan;
    if (!candidates) {
        plan.mode = MixedMode::Local;
        plan.request.clear();
    } else {
        plan.mode = MixedMode::Extract;
        plan.begin = candidateBegin;
        plan.end = candidateEnd;
        plan.request = source.substr(plan.begin, plan.end - plan.begin);
    }
    return plan;
}
} // namespace qt
