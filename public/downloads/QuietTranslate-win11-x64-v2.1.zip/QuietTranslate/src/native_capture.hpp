#pragma once
// Included after withinTarget and UTF conversion helpers.
struct FocusTarget {
    HWND top = nullptr, edit = nullptr;
    DWORD thread = 0, pid = 0;
    std::wstring className;
    explicit FocusTarget(HWND window) : top(window) {
        if (!top || GetForegroundWindow() != top)
            throw std::runtime_error("前台窗口已变化，请重新选择。");
        thread = GetWindowThreadProcessId(top, &pid);
        GUITHREADINFO info{};
        info.cbSize = sizeof(info);
        if (!thread || !GetGUIThreadInfo(thread, &info) || !withinTarget(top, info.hwndFocus))
            throw std::runtime_error("无法确认当前编辑焦点，请重新点击编辑区。");
        edit = info.hwndFocus;
        wchar_t name[128]{};
        if (!GetClassNameW(edit, name, 128))
            throw std::runtime_error("无法识别编辑控件。");
        className = name;
        std::transform(className.begin(), className.end(), className.begin(),
                       [](wchar_t c) { return (wchar_t)towlower(c); });
        DWORD editPid = 0;
        GetWindowThreadProcessId(edit, &editPid);
        if (editPid != pid)
            throw std::runtime_error("编辑控件与前台进程不一致，已取消。");
        if (isTextEdit() && (GetWindowLongPtrW(edit, GWL_STYLE) & ES_PASSWORD))
            throw std::runtime_error("当前焦点属于密码控件，已拒绝取词。");
    }
    bool isScintilla() const {
        return className == L"scintilla" || className.rfind(L"windowsforms10.scintilla.", 0) == 0;
    }
    bool isTextEdit() const {
        return className == L"edit" || className.rfind(L"richedit", 0) == 0 ||
               className.rfind(L"windowsforms10.edit.", 0) == 0 ||
               className.rfind(L"windowsforms10.richedit", 0) == 0;
    }
    void verify() const {
        GUITHREADINFO info{};
        info.cbSize = sizeof(info);
        DWORD currentPid = 0;
        if (GetForegroundWindow() != top || !GetGUIThreadInfo(thread, &info) ||
            info.hwndFocus != edit || !IsWindow(edit) || !withinTarget(top, edit) ||
            !GetWindowThreadProcessId(edit, &currentPid) || currentPid != pid)
            throw std::runtime_error("窗口或编辑焦点已变化，已取消本次取词。");
    }
    int64_t query(UINT message, WPARAM w = 0, LPARAM l = 0, UINT timeout = 100) const {
        DWORD_PTR value = 0;
        SetLastError(ERROR_SUCCESS);
        if (!SendMessageTimeoutW(edit, message, w, l,
                                 SMTO_BLOCK | SMTO_ABORTIFHUNG | SMTO_ERRORONEXIT, timeout,
                                 &value)) {
            if (GetLastError() == ERROR_ACCESS_DENIED)
                throw std::runtime_error("目标编辑器权限高于轻译，请在相同普通用户权限下运行。");
            throw std::runtime_error("编辑控件未及时响应，已停止取词。");
        }
        return (int64_t)(intptr_t)value;
    }
};
static std::string nativeScintilla(const FocusTarget &target) {
    target.verify();
    ULONGLONG deadline = GetTickCount64() + 2200;
    unsigned calls = 0;
    auto selected = qt::scintillaSelection([&](uint32_t msg, int64_t w) {
        if (GetTickCount64() > deadline)
            throw std::runtime_error("Scintilla 取词超时，请缩短选区。");
        if ((calls++ % 32) == 0)
            target.verify();
        return target.query(msg, (WPARAM)w);
    });
    target.verify();
    UINT cp = selected.codePage ? selected.codePage : CP_ACP;
    if (cp != 65001 && cp != CP_ACP && cp != 932 && cp != 936 && cp != 949 && cp != 950 &&
        cp != 1361 && !(cp >= 1250 && cp <= 1258))
        throw std::runtime_error("该 Scintilla 编码暂不支持，请用 UTF-8 或手动复制模式。");
    int size = MultiByteToWideChar(cp, MB_ERR_INVALID_CHARS, selected.bytes.data(),
                                   (int)selected.bytes.size(), nullptr, 0);
    if (!size)
        throw std::runtime_error("Scintilla 选区编码无效，已停止取词。");
    std::wstring out(size, 0);
    if (!MultiByteToWideChar(cp, MB_ERR_INVALID_CHARS, selected.bytes.data(),
                             (int)selected.bytes.size(), out.data(), size))
        throw std::runtime_error("无法解码 Scintilla 选区。");
    auto value = qt::trim(narrow(out));
    if (value.size() > 4000 || (!qt::english(value) && !qt::hasHan(value)))
        throw std::runtime_error("请选择不超过 4000 UTF-8 字节的英文。");
    return value;
}
