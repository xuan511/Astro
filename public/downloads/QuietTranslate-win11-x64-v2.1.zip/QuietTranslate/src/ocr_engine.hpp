#pragma once
#include "ocr_policy.hpp"
#include <tesseract/baseapi.h>
#include <memory>
#include <cstdlib>
namespace qt {
struct OcrResult {
    std::string text;
    int confidence = 0;
};
inline bool ocrNoExternalFile(const char *, std::vector<char> *) {
    return false;
}
inline OcrResult recognizeEnglish(const OcrGray &gray, const std::string &model) {
#ifdef _WIN32
    _putenv_s("TESSDATA_PREFIX", ""); // Child only: never consult another app's OCR-data path.
#else
    unsetenv("TESSDATA_PREFIX");
#endif
    if (model.size() != 4113088)
        throw std::runtime_error("OCR 英文模型缺失或版本不匹配，请完整解压应用包。");
    if (gray.width < 8 || gray.height < 8 || (uint64_t)gray.width * gray.height > ocrMaxPixels ||
        gray.pixels.size() != (uint64_t)gray.width * gray.height)
        throw std::runtime_error("OCR 灰度图像边界无效。");
    tesseract::TessBaseAPI engine;
    if (engine.Init(model.data(), (int)model.size(), "eng", tesseract::OEM_LSTM_ONLY, nullptr, 0,
                    nullptr, nullptr, false, ocrNoExternalFile) != 0)
        throw std::runtime_error("无法初始化 OCR 英文模型，请重新解压完整应用包。");
    engine.SetPageSegMode(tesseract::PSM_AUTO);
    engine.SetVariable("user_defined_dpi", "200");
    engine.SetImage(gray.pixels.data(), gray.width, gray.height, 1, gray.width);
    engine.SetSourceResolution(200);
    if (engine.Recognize(nullptr) != 0)
        throw std::runtime_error("OCR 识别未完成，请缩小选区后重试。");
    std::unique_ptr<char[]> raw(engine.GetUTF8Text());
    if (!raw)
        throw std::runtime_error("OCR 未返回文字。");
    std::string output;
    while (output.size() <= 4000 && raw[output.size()])
        output += raw[output.size()];
    if (output.size() > 4000)
        throw std::runtime_error(
            "识别文字超过 4000 UTF-8 字节，请缩小框选区域，未自动截断或发送翻译。");
    OcrResult result{ocrText(output), std::max(0, std::min(100, engine.MeanTextConf()))};
    engine.End();
    return result;
}
} // namespace qt
