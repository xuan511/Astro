#pragma once
#include "core.hpp"
#include <algorithm>
#include <vector>
#include <limits>
namespace qt {
constexpr uint64_t ocrMaxPixels = 6000000;
struct OcrBounds {
    int32_t left, top, right, bottom;
};
struct OcrRegion {
    int32_t x, y, width, height;
};
inline int32_t ocrCoordinate(const std::string &s) {
    if (s.empty() || s.size() > 11)
        throw std::runtime_error("OCR 坐标格式无效。");
    size_t at = s[0] == '-' ? 1 : 0;
    if (at == s.size())
        throw std::runtime_error("OCR 坐标格式无效。");
    int64_t n = 0;
    for (; at < s.size(); ++at) {
        char c = s[at];
        if (c < '0' || c > '9')
            throw std::runtime_error("OCR 坐标格式无效。");
        n = n * 10 + c - '0';
        if (n > 2147483648LL)
            throw std::runtime_error("OCR 坐标越界。");
    }
    if (s[0] == '-')
        n = -n;
    if (n < INT32_MIN || n > INT32_MAX)
        throw std::runtime_error("OCR 坐标越界。");
    return (int32_t)n;
}
inline void validateOcrRegion(const OcrRegion &r, const OcrBounds &b) {
    if (b.right <= b.left || b.bottom <= b.top || r.width < 8 || r.height < 8)
        throw std::runtime_error("框选区域太小，请重新框选英文文字。");
    if (r.width > 4096 || r.height > 4096 || (uint64_t)r.width * r.height > ocrMaxPixels)
        throw std::runtime_error(
            "OCR 区域过大，请只框选需要翻译的段落（最多 600 万像素，单边 4096）。");
    if (r.x < b.left || r.y < b.top || (int64_t)r.x + r.width > b.right ||
        (int64_t)r.y + r.height > b.bottom)
        throw std::runtime_error("屏幕布局已改变或选区越界，请重新框选。");
}
inline OcrRegion ocrDrag(int32_t x1, int32_t y1, int32_t x2, int32_t y2, const OcrBounds &b) {
    auto clamp = [](int32_t v, int32_t lo, int32_t hi) { return std::max(lo, std::min(v, hi)); };
    x1 = clamp(x1, b.left, b.right);
    x2 = clamp(x2, b.left, b.right);
    y1 = clamp(y1, b.top, b.bottom);
    y2 = clamp(y2, b.top, b.bottom);
    auto w = (int64_t)std::max(x1, x2) - std::min(x1, x2),
         h = (int64_t)std::max(y1, y2) - std::min(y1, y2);
    if (w > INT32_MAX || h > INT32_MAX)
        throw std::runtime_error("OCR 屏幕坐标范围过大。");
    return {std::min(x1, x2), std::min(y1, y2), (int32_t)w, (int32_t)h};
}
struct OcrGray {
    int width = 0, height = 0, scale = 1;
    bool inverted = false;
    std::vector<uint8_t> pixels;
};
inline OcrGray ocrGray(const uint8_t *bgra, size_t count, int width, int height) {
    if (!bgra || width < 8 || height < 8 || width > 4096 || height > 4096 ||
        (uint64_t)width * height > ocrMaxPixels || count != (uint64_t)width * height * 4)
        throw std::runtime_error("OCR 像素缓冲格式无效。");
    OcrGray out;
    const int border = 16;
    if ((int64_t)width * 2 + 32 <= 4096 && (int64_t)height * 2 + 32 <= 4096 &&
        ((uint64_t)width * 2 + 32) * ((uint64_t)height * 2 + 32) <= ocrMaxPixels)
        out.scale = 2;
    out.width = width * out.scale + border * 2;
    out.height = height * out.scale + border * 2;
    // A source at the cap may not have room for a border: never exceed the work budget.
    int edge = border;
    if ((uint64_t)out.width * out.height > ocrMaxPixels || out.width > 4096 || out.height > 4096) {
        edge = 0;
        out.width = width;
        out.height = height;
        out.scale = 1;
    }
    uint64_t sum = 0;
    for (size_t p = 0; p < count; p += 4)
        sum += (77u * bgra[p + 2] + 150u * bgra[p + 1] + 29u * bgra[p]) >> 8;
    out.inverted = sum < (uint64_t)width * height * 110;
    out.pixels.assign((size_t)out.width * out.height, 255);
    for (int y = 0; y < height; ++y)
        for (int x = 0; x < width; ++x) {
            size_t p = ((size_t)y * width + x) * 4;
            uint8_t v = (uint8_t)((77u * bgra[p + 2] + 150u * bgra[p + 1] + 29u * bgra[p]) >> 8);
            if (out.inverted)
                v = 255 - v;
            for (int yy = 0; yy < out.scale; ++yy)
                for (int xx = 0; xx < out.scale; ++xx)
                    out.pixels[(size_t)(edge + y * out.scale + yy) * out.width + edge +
                               x * out.scale + xx] = v;
        }
    return out;
}
inline std::string ocrText(std::string text) {
    text = trim(text);
    if (text.empty() || !english(text))
        throw std::runtime_error(
            "未识别到可翻译的英文。请放大文字、缩小选区或调整页面缩放后重试。");
    if (text.size() > 4000)
        throw std::runtime_error(
            "识别文字超过 4000 UTF-8 字节，请缩小框选区域，未自动截断或发送翻译。");
    for (unsigned char c : text)
        if (c < 32 && c != '\r' && c != '\n' && c != '\t')
            throw std::runtime_error("OCR 返回了无效控制字符，未发送翻译。");
    return text;
}
} // namespace qt
