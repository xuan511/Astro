#pragma once
static bool apiToolActive = false, apiToolList = false, apiFilling = false;
static ULONGLONG apiToolDeadline = 0;
static void stopApiTool() {
    billingEnd(2, qt::BillState::Cancelled);
    KillTimer(host, 5);
    apiToolActive = false;
    apiToolTask.close();
}
static void modelHint() {
    auto id = narrow(text(apiModel));
    const wchar_t *hint = id == "qwen-mt-lite"    ? L"专用翻译 · 轻量"
                          : id == "qwen-mt-flash" ? L"专用翻译 · 均衡"
                          : id == "qwen-mt-plus"  ? L"专用翻译 · 质量优先"
                          : id == "qwen-flash"    ? L"通用模型"
                                                  : L"";
    SetWindowTextW(apiHint, hint);
}
static qt::ApiConfig readApiForm(bool forModels = false) {
    qt::ApiConfig c;
    c.base = qt::endpoint(narrow(text(apiBase))).base;
    c.model = qt::trim(narrow(text(apiModel)));
    if (forModels && c.model.empty())
        c.model = "models-list-only";
    c.modernLimit = SendMessageW(apiLimit, CB_GETCURSEL, 0, 0) == 1;
    c.protocol = (int)SendMessageW(apiProtocol, CB_GETCURSEL, 0, 0);
    c.stream = SendMessageW(apiStream, BM_GETCHECK, 0, 0) == BST_CHECKED;
    c.includeUsage = SendMessageW(apiIncludeUsage, BM_GETCHECK, 0, 0) == BST_CHECKED;
    c.keepTerms = SendMessageW(apiKeepTerms, BM_GETCHECK, 0, 0) == BST_CHECKED;
    c.smartMixed = SendMessageW(apiSmartMixed, BM_GETCHECK, 0, 0) == BST_CHECKED;
    auto token = narrow(text(apiTokens));
    c.maxTokens = 0;
    if (token.empty() || token.size() > 4)
        throw std::runtime_error("请填写 128—4096 的输出 Token 上限。");
    for (char v : token) {
        if (v < '0' || v > '9')
            throw std::runtime_error("Token 上限必须是整数。");
        c.maxTokens = c.maxTokens * 10 + v - '0';
    }
    c.key = narrow(text(apiKey));
    if (c.key.empty()) {
        if (c.base != apiConfig.base)
            throw std::runtime_error(
                "地址已更改，请重新填写新地址对应的 Key；不会把旧 Key 发往新地址。");
        c.key = apiConfig.key;
    }
    c.validate();
    return c;
}
static void showApi() {
    if (!ensureToolWindow(apiWindow, L"QuietTranslate.API", L"API 配置", 720, 660))
        return;
    stopApiTool();
    apiFilling = true;
    SetWindowTextW(apiBase, wide(apiConfig.base).c_str());
    SetWindowTextW(apiModel, wide(apiConfig.model).c_str());
    SetWindowTextW(apiKey, L"");
    SetWindowTextW(apiTokens, std::to_wstring(apiConfig.maxTokens).c_str());
    SendMessageW(apiProtocol, CB_SETCURSEL, apiConfig.protocol, 0);
    SendMessageW(apiLimit, CB_SETCURSEL, apiConfig.modernLimit ? 1 : 0, 0);
    SendMessageW(apiPreset, CB_SETCURSEL, 2, 0);
    SendMessageW(apiStream, BM_SETCHECK, apiConfig.stream ? BST_CHECKED : BST_UNCHECKED, 0);
    SendMessageW(apiIncludeUsage, BM_SETCHECK, apiConfig.includeUsage ? BST_CHECKED : BST_UNCHECKED,
                 0);
    SendMessageW(apiKeepTerms, BM_SETCHECK, apiConfig.keepTerms ? BST_CHECKED : BST_UNCHECKED, 0);
    SendMessageW(apiSmartMixed, BM_SETCHECK, apiConfig.smartMixed ? BST_CHECKED : BST_UNCHECKED, 0);
    SetWindowTextW(apiStatus,
                   apiConfig.key.empty() ? L"请填写 API Key。" : L"Key 已保存；留空沿用。");
    modelHint();
    apiFilling = false;
    ShowWindow(apiWindow, SW_SHOW);
    SetForegroundWindow(apiWindow);
}
static void startApiTool(bool list) {
    stopApiTool();
    try {
        auto c = readApiForm(list);
        if (!spawn(apiToolTask, list ? L"--api-tool models" : L"--api-tool test", true))
            throw std::runtime_error("无法启动 API 测试。");
        if (!list)
            billingBegin(2, c);
        if (!apiToolTask.send(20, c.serialize()) ||
            (!list && !apiToolTask.send(10, "The driver requires a stable clock."))) {
            billingEnd(2, qt::BillState::NotSent);
            throw std::runtime_error("无法提交 API 测试。");
        }
        apiToolList = list;
        apiToolActive = true;
        apiToolDeadline = GetTickCount64() + 35000;
        SetTimer(host, 5, 30, nullptr);
        SetWindowTextW(apiStatus, list ? L"正在获取模型…" : L"正在测试（可能计费）…");
    } catch (const std::exception &e) {
        stopApiTool();
        SetWindowTextW(apiStatus, wide(e.what()).c_str());
    }
}
static void pollApiTool() {
    if (!apiToolActive)
        return;
    try {
        DWORD available = 0;
        while (PeekNamedPipe(apiToolTask.read, nullptr, 0, nullptr, &available, nullptr) &&
               available) {
            char b[4096];
            DWORD n = 0;
            if (!ReadFile(apiToolTask.read, b, sizeof(b), &n, nullptr) || !n)
                break;
            apiToolTask.decoder.feed(b, n);
            qt::Frame f;
            while (apiToolTask.decoder.pop(f)) {
                if (billingFrame(2, f))
                    continue;
                wide(f.text);
                if (f.type == 3) {
                    billingEnd(2, qt::BillState::Failed);
                    throw std::runtime_error(f.text);
                }
                if (f.type == 2) {
                    if (!apiToolList)
                        billingEnd(2, qt::BillState::Success);
                    if (apiToolList) {
                        auto current = text(apiModel);
                        apiFilling = true;
                        SendMessageW(apiModel, CB_RESETCONTENT, 0, 0);
                        size_t start = 0;
                        unsigned count = 0;
                        while (start < f.text.size()) {
                            auto end = f.text.find('\n', start);
                            if (end == std::string::npos)
                                end = f.text.size();
                            auto id = f.text.substr(start, end - start);
                            if (qt::modelId(id)) {
                                SendMessageW(apiModel, CB_ADDSTRING, 0, (LPARAM)wide(id).c_str());
                                ++count;
                            }
                            start = end + 1;
                        }
                        SetWindowTextW(apiModel, current.c_str());
                        apiFilling = false;
                        SetWindowTextW(apiStatus,
                                       (L"已获取 " + std::to_wstring(count) +
                                        L" 个模型。未替换当前选择；展开下拉框选择，也可手动填写。")
                                           .c_str());
                    } else {
                        SetWindowTextW(apiStatus, wide("测试返回（未自动启用）：" + f.text +
                                                       "\r\n" + billingLastTest)
                                                      .c_str());
                    }
                    stopApiTool();
                    return;
                }
            }
        }
        if (GetTickCount64() > apiToolDeadline)
            throw std::runtime_error("API 测试超时，已取消本机等待；服务端可能已计费用量。");
        if (!apiToolTask.running()) {
            DWORD pending = 0;
            if (PeekNamedPipe(apiToolTask.read, nullptr, 0, nullptr, &pending, nullptr) && pending)
                return;
            throw std::runtime_error("API 测试退出但没有完整响应。");
        }
    } catch (const std::exception &e) {
        stopApiTool();
        SetWindowTextW(apiStatus, wide(e.what()).c_str());
    }
}
static LRESULT CALLBACK ApiProc(HWND h, UINT msg, WPARAM w, LPARAM l) {
    switch (msg) {
    case WM_CREATE: {
        child(h, L"STATIC", L"API 翻译", SS_LEFT, 620);
        apiPreset = child(h, L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP, API_PRESET);
        for (auto label : {L"阿里云百炼 · 北京", L"阿里云百炼 · 新加坡", L"自定义兼容服务"})
            SendMessageW(apiPreset, CB_ADDSTRING, 0, (LPARAM)label);
        child(h, L"STATIC", L"Base URL", SS_LEFT, 621);
        apiBase = child(h, L"EDIT", L"", ES_AUTOHSCROLL | WS_TABSTOP, API_BASE);
        SendMessageW(apiBase, EM_SETLIMITTEXT, 2048, 0);
        child(h, L"STATIC", L"API Key（留空沿用）", SS_LEFT, 622);
        apiKey = child(h, L"EDIT", L"", ES_PASSWORD | ES_AUTOHSCROLL | WS_TABSTOP, API_KEY);
        SendMessageW(apiKey, EM_SETLIMITTEXT, 4096, 0);
        child(h, L"BUTTON", L"删除已存 Key", BS_PUSHBUTTON | WS_TABSTOP, API_FORGET);
        child(h, L"STATIC", L"模型 ID", SS_LEFT, 623);
        apiModel = child(h, L"COMBOBOX", L"",
                         CBS_DROPDOWN | CBS_AUTOHSCROLL | WS_VSCROLL | WS_TABSTOP, API_MODEL);
        SendMessageW(apiModel, CB_LIMITTEXT, 200, 0);
        for (auto id : {L"qwen-mt-lite", L"qwen-mt-flash", L"qwen-mt-plus", L"qwen-flash"})
            SendMessageW(apiModel, CB_ADDSTRING, 0, (LPARAM)id);
        apiHint = child(h, L"STATIC", L"", SS_LEFT, 624);
        child(h, L"STATIC", L"请求类型", SS_LEFT, 625);
        apiProtocol = child(h, L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP, API_PROTOCOL);
        for (auto label :
             {L"标准 OpenAI 兼容 Chat Completions", L"千问通用 Chat（enable_thinking=false）",
              L"Qwen-MT 专用翻译（English → Chinese）"})
            SendMessageW(apiProtocol, CB_ADDSTRING, 0, (LPARAM)label);
        child(h, L"STATIC", L"输出 Token 上限", SS_LEFT, 626);
        apiTokens = child(h, L"EDIT", L"2048", ES_NUMBER | WS_TABSTOP, API_TOKENS);
        SendMessageW(apiTokens, EM_SETLIMITTEXT, 4, 0);
        apiLimit = child(h, L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP, API_LIMIT);
        SendMessageW(apiLimit, CB_ADDSTRING, 0, (LPARAM)L"max_tokens（常用 / MT）");
        SendMessageW(apiLimit, CB_ADDSTRING, 0, (LPARAM)L"max_completion_tokens（新式）");
        apiStream = child(h, L"BUTTON", L"流式输出", BS_AUTOCHECKBOX | WS_TABSTOP, API_STREAM);
        apiIncludeUsage = child(h, L"BUTTON", L"请求流式用量回传", BS_AUTOCHECKBOX | WS_TABSTOP,
                                API_INCLUDE_USAGE);
        apiKeepTerms =
            child(h, L"BUTTON", L"保留技术名称", BS_AUTOCHECKBOX | WS_TABSTOP, API_KEEP_TERMS);
        apiSmartMixed =
            child(h, L"BUTTON", L"智能保留中文", BS_AUTOCHECKBOX | WS_TABSTOP, API_SMART_MIXED);
        child(h, L"BUTTON", L"获取模型列表", BS_PUSHBUTTON | WS_TABSTOP, API_MODELS);
        child(h, L"BUTTON", L"短句测试（会计费）", BS_PUSHBUTTON | WS_TABSTOP, API_TEST);
        child(h, L"BUTTON", L"用量 / 单价", BS_PUSHBUTTON | WS_TABSTOP, API_BILL);
        apiStatus =
            child(h, L"EDIT", L"",
                  ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL | WS_TABSTOP, 628);
        child(h, L"BUTTON", L"保存并启用 API", BS_PUSHBUTTON | WS_TABSTOP, API_SAVE);
        child(h, L"BUTTON", L"取消", BS_PUSHBUTTON | WS_TABSTOP, API_CANCEL);
        return 0;
    }
    case WM_SIZE:
        place(GetDlgItem(h, 620), 20, 12, 665, 26);
        place(apiPreset, 20, 44, 665, 160);
        place(GetDlgItem(h, 621), 20, 80, 665, 22);
        place(apiBase, 20, 104, 665, 28);
        place(GetDlgItem(h, 622), 20, 140, 665, 22);
        place(apiKey, 20, 164, 508, 28);
        place(GetDlgItem(h, API_FORGET), 538, 164, 147, 28);
        place(GetDlgItem(h, 623), 20, 200, 665, 22);
        place(apiModel, 20, 224, 665, 175);
        place(apiHint, 20, 260, 665, 36);
        place(GetDlgItem(h, 625), 20, 301, 665, 22);
        place(apiProtocol, 20, 325, 665, 145);
        place(GetDlgItem(h, 626), 20, 363, 310, 24);
        place(apiTokens, 340, 361, 105, 27);
        place(apiLimit, 455, 361, 230, 100);
        place(apiStream, 20, 396, 340, 28);
        place(apiIncludeUsage, 380, 396, 305, 28);
        place(apiKeepTerms, 20, 429, 320, 28);
        place(apiSmartMixed, 380, 429, 305, 28);
        place(GetDlgItem(h, API_MODELS), 20, 465, 160, 30);
        place(GetDlgItem(h, API_TEST), 194, 465, 195, 30);
        place(GetDlgItem(h, API_BILL), 405, 465, 280, 30);
        place(apiStatus, 20, 505, 665, 54);
        place(GetDlgItem(h, API_SAVE), 20, 573, 180, 32);
        place(GetDlgItem(h, API_CANCEL), 214, 573, 90, 32);
        return 0;
    case WM_COMMAND: {
        int id = LOWORD(w), event = HIWORD(w);
        if (!apiFilling &&
            ((event == EN_CHANGE && (id == API_BASE || id == API_KEY || id == API_TOKENS)) ||
             (event == CBN_SELCHANGE &&
              (id == API_MODEL || id == API_PROTOCOL || id == API_PRESET || id == API_LIMIT)) ||
             (event == CBN_EDITCHANGE && id == API_MODEL) || id == API_STREAM ||
             id == API_INCLUDE_USAGE || id == API_KEEP_TERMS || id == API_SMART_MIXED)) {
            if (apiToolActive) {
                stopApiTool();
                SetWindowTextW(apiStatus, L"表单已改动，已取消旧测试结果。可重新测试。");
            }
        }
        if (id == API_PRESET && event == CBN_SELCHANGE) {
            int preset = (int)SendMessageW(apiPreset, CB_GETCURSEL, 0, 0);
            apiFilling = true;
            if (preset == 0 || preset == 1) {
                SetWindowTextW(apiBase,
                               preset == 0
                                   ? L"https://dashscope.aliyuncs.com/compatible-mode/v1"
                                   : L"https://dashscope-intl.aliyuncs.com/compatible-mode/v1");
                SetWindowTextW(apiModel, L"qwen-mt-flash");
                SendMessageW(apiProtocol, CB_SETCURSEL, 2, 0);
            } else {
                SetWindowTextW(apiBase, L"");
                SetWindowTextW(apiModel, L"");
                SendMessageW(apiProtocol, CB_SETCURSEL, 0, 0);
            }
            SetWindowTextW(apiKey, L"");
            apiFilling = false;
            modelHint();
            SetWindowTextW(apiStatus, L"请填写对应 Key。");
            return 0;
        }
        if (id == API_MODEL && (event == CBN_SELCHANGE || event == CBN_EDITCHANGE)) {
            std::wstring idText = text(apiModel);
            if (event == CBN_SELCHANGE) {
                int i = (int)SendMessageW(apiModel, CB_GETCURSEL, 0, 0);
                wchar_t b[256]{};
                if (i >= 0) {
                    SendMessageW(apiModel, CB_GETLBTEXT, i, (LPARAM)b);
                    idText = b;
                    SetWindowTextW(apiModel, b);
                }
            }
            if (idText.find(L"qwen-mt-") == 0)
                SendMessageW(apiProtocol, CB_SETCURSEL, 2, 0);
            else if (idText == L"qwen-flash")
                SendMessageW(apiProtocol, CB_SETCURSEL, 1, 0);
            modelHint();
            return 0;
        }
        if (id == API_MODELS) {
            startApiTool(true);
            return 0;
        }
        if (id == API_TEST) {
            startApiTool(false);
            return 0;
        }
        if (id == API_BILL) {
            auto base = qt::trim(narrow(text(apiBase))), model = qt::trim(narrow(text(apiModel)));
            if (base.empty() || model.empty())
                SetWindowTextW(apiStatus, L"请先填写地址与模型 ID，再设置对应单价。");
            else
                showBilling(base, model);
            return 0;
        }
        if (id == API_FORGET) {
            stopApiTool();
            forgetCache();
            if (config.empty() ||
                !WritePrivateProfileStringW(L"Settings", L"Online", L"0", config.c_str()) ||
                !WritePrivateProfileStringW(L"API", L"ProtectedKey", L"", config.c_str()) ||
                !WritePrivateProfileStringW(L"API", L"Enabled", L"0", config.c_str())) {
                SetWindowTextW(apiStatus, L"删除 Key 失败。请重试。");
                return 0;
            }
            if (!apiConfig.key.empty())
                SecureZeroMemory(apiConfig.key.data(), apiConfig.key.size());
            apiConfig.key.clear();
            apiEnabled = false;
            online = false;
            saveConfig();
            SendMessageW(onlineCheck, BM_SETCHECK, BST_UNCHECKED, 0);
            SetWindowTextW(apiKey, L"");
            SendMessageW(engineCombo, CB_SETCURSEL, 0, 0);
            SetWindowTextW(apiStatus, L"已删除本机 Key，API 已停用。");
            return 0;
        }
        if (id == API_SAVE) {
            try {
                auto c = readApiForm();
                if (!saveApiPrefs(c, true))
                    throw std::runtime_error("API 设置保存失败，未启用。请重新打开并核对配置。");
                forgetCache();
                if (!apiConfig.key.empty())
                    SecureZeroMemory(apiConfig.key.data(), apiConfig.key.size());
                apiConfig = c;
                apiEnabled = true;
                online = true;
                keyLoadFailed = false;
                SetWindowTextW(apiKey, L"");
                SendMessageW(engineCombo, CB_SETCURSEL, 1, 0);
                SendMessageW(onlineCheck, BM_SETCHECK, BST_CHECKED, 0);
                if (!saveConfig())
                    MessageBoxW(h, L"API 设置已保存，本次已联网；联网总开关未能持久保存。", APP,
                                MB_OK | MB_ICONWARNING);
                status(
                    wide("当前翻译：" + engineLabel() + " · " + qt::endpoint(apiConfig.base).host)
                        .c_str());
                if (IsWindowVisible(popup))
                    result(L"API 已切换，旧缓存已清除。点击翻译 / 重试使用新模型。");
                ShowWindow(h, SW_HIDE);
                ShowWindow(settings, SW_HIDE);
            } catch (const std::exception &e) {
                SetWindowTextW(apiStatus, wide(e.what()).c_str());
            }
            return 0;
        }
        if (id == API_CANCEL) {
            stopApiTool();
            SetWindowTextW(apiKey, L"");
            ShowWindow(h, SW_HIDE);
            return 0;
        }
        break;
    }
    case WM_CLOSE:
        stopApiTool();
        SetWindowTextW(apiKey, L"");
        ShowWindow(h, SW_HIDE);
        return 0;
    case WM_CTLCOLORSTATIC:
        SetBkMode((HDC)w, TRANSPARENT);
        SetTextColor((HDC)w, RGB(36, 49, 68));
        return (LRESULT)bg;
    }
    return DefWindowProcW(h, msg, w, l);
}
