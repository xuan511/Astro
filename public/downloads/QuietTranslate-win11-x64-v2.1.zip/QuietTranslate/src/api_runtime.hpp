#pragma once
// Included after Win32 handle wrappers, UTF conversion, and bounded IPC helpers.
static std::string readFrameInput(uint32_t type, uint32_t limit) {
    uint32_t h[2];
    auto in = GetStdHandle(STD_INPUT_HANDLE);
    readExact(in, h, 8);
    if (h[0] != type || h[1] > limit)
        throw std::runtime_error("API 输入协议无效。");
    std::string s(h[1], 0);
    if (h[1])
        readExact(in, s.data(), h[1]);
    return s;
}
static qt::ApiConfig readApiInput() {
    return qt::ApiConfig::parse(readFrameInput(20, 16384));
}
static std::wstring protectKey(const std::string &key) {
    if (key.empty())
        return {};
    DATA_BLOB input{(DWORD)key.size(), (BYTE *)key.data()}, out{};
    if (!CryptProtectData(&input, L"QuietTranslate API key", nullptr, nullptr, nullptr,
                          CRYPTPROTECT_UI_FORBIDDEN, &out))
        throw std::runtime_error("Windows 无法加密 API Key，未保存。");
    const wchar_t *hex = L"0123456789abcdef";
    std::wstring value;
    for (DWORD i = 0; i < out.cbData; ++i) {
        value += hex[out.pbData[i] >> 4];
        value += hex[out.pbData[i] & 15];
    }
    SecureZeroMemory(out.pbData, out.cbData);
    LocalFree(out.pbData);
    return value;
}
static std::string unprotectKey(const std::wstring &hex) {
    if (hex.empty())
        return {};
    if (hex.size() % 2 || hex.size() > 24000)
        throw std::runtime_error("已保存的 Key 数据无效，请重新填写。");
    auto digit = [](wchar_t c) -> unsigned {
        if (c >= '0' && c <= '9')
            return c - '0';
        if (c >= 'a' && c <= 'f')
            return c - 'a' + 10;
        throw std::runtime_error("已保存的 Key 数据无效。");
    };
    std::vector<BYTE> bytes;
    for (size_t i = 0; i < hex.size(); i += 2)
        bytes.push_back((BYTE)(digit(hex[i]) * 16 + digit(hex[i + 1])));
    DATA_BLOB in{(DWORD)bytes.size(), bytes.data()}, out{};
    if (!CryptUnprotectData(&in, nullptr, nullptr, nullptr, nullptr, CRYPTPROTECT_UI_FORBIDDEN,
                            &out))
        throw std::runtime_error("无法解密已保存的 Key。请在当前 Windows 用户下重新填写。");
    std::string key((char *)out.pbData, out.cbData);
    SecureZeroMemory(out.pbData, out.cbData);
    LocalFree(out.pbData);
    return key;
}
static std::wstring iniApi(const wchar_t *name, const wchar_t *fallback = L"") {
    wchar_t b[24576];
    DWORD n = GetPrivateProfileStringW(L"API", name, fallback, b, 24576, config.c_str());
    if (n >= 24575)
        throw std::runtime_error("API 设置超出长度上限。");
    return std::wstring(b, n);
}
static bool keyLoadFailed = false;
static void loadApiPrefs() {
    if (config.empty())
        return;
    try {
        apiConfig.base = narrow(iniApi(L"BaseURL", wide(apiConfig.base).c_str()));
        apiConfig.model = narrow(iniApi(L"Model", wide(apiConfig.model).c_str()));
        apiConfig.protocol = GetPrivateProfileIntW(L"API", L"Protocol", 2, config.c_str());
        apiConfig.modernLimit =
            GetPrivateProfileIntW(L"API", L"ModernLimit", 0, config.c_str()) == 1;
        apiConfig.stream = GetPrivateProfileIntW(L"API", L"Stream", 1, config.c_str()) == 1;
        apiConfig.includeUsage =
            GetPrivateProfileIntW(L"API", L"IncludeUsage", 1, config.c_str()) == 1;
        apiConfig.keepTerms = GetPrivateProfileIntW(L"API", L"KeepTerms", 1, config.c_str()) == 1;
        apiConfig.smartMixed = GetPrivateProfileIntW(L"API", L"SmartMixed", 1, config.c_str()) == 1;
        apiConfig.maxTokens = GetPrivateProfileIntW(L"API", L"MaxTokens", 2048, config.c_str());
        apiConfig.key = unprotectKey(iniApi(L"ProtectedKey"));
        apiConfig.validate(false);
        apiEnabled = GetPrivateProfileIntW(L"API", L"Enabled", 0, config.c_str()) == 1;
    } catch (...) {
        keyLoadFailed = true;
        apiConfig = qt::ApiConfig{};
        apiEnabled = GetPrivateProfileIntW(L"API", L"Enabled", 0, config.c_str()) == 1;
    }
}
static bool saveApiPrefs(const qt::ApiConfig &c, bool enabled) {
    if (config.empty())
        throw std::runtime_error("无法写入本机设置。");
    c.validate(false);
    auto protectedKey = protectKey(c.key);
    // Disable API on disk before replacing its credential binding. Failure cannot leave the old
    // encrypted key bound to a newly written address. Never fall back to plaintext storage.
    auto put = [&](const wchar_t *name, const std::wstring &value) {
        return WritePrivateProfileStringW(L"API", name, value.c_str(), config.c_str()) != 0;
    };
    if (!WritePrivateProfileStringW(L"Settings", L"Online", L"0", config.c_str()))
        return false;
    if (!put(L"Enabled", L"0") || !put(L"ProtectedKey", L""))
        return false;
    if (!put(L"BaseURL", wide(c.base)) || !put(L"Model", wide(c.model)) ||
        !put(L"ModernLimit", c.modernLimit ? L"1" : L"0") ||
        !put(L"Protocol", std::to_wstring(c.protocol)) || !put(L"Stream", c.stream ? L"1" : L"0") ||
        !put(L"IncludeUsage", c.includeUsage ? L"1" : L"0") ||
        !put(L"KeepTerms", c.keepTerms ? L"1" : L"0") ||
        !put(L"SmartMixed", c.smartMixed ? L"1" : L"0") ||
        !put(L"MaxTokens", std::to_wstring(c.maxTokens)) || !put(L"ProtectedKey", protectedKey) ||
        !put(L"Enabled", enabled ? L"1" : L"0"))
        return false;
    return true;
}
class ModelApiClient {
    qt::ApiConfig c;
    qt::Endpoint e;
    Http session, conn;
    static void checkStatus(HINTERNET req) {
        DWORD code = 0, n = sizeof(code);
        if (!WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                                 WINHTTP_HEADER_NAME_BY_INDEX, &code, &n, WINHTTP_NO_HEADER_INDEX))
            throw std::runtime_error("无法读取 API 状态。");
        if (code == 200)
            return;
        if (code == 401 || code == 403)
            throw std::runtime_error("API HTTP " + std::to_string(code) +
                                     "：检查 Key、地域、模型开通与权限。");
        if (code == 404)
            throw std::runtime_error(
                "API HTTP 404：检查 Base URL、模型 ID，或服务是否支持该接口。");
        if (code == 429)
            throw std::runtime_error("API HTTP 429：请求限流或额度不足。未自动重试或切换服务。");
        throw std::runtime_error(
            "API HTTP " + std::to_string(code) +
            "：服务拒绝请求；检查模型、请求类型和参数。未显示服务原始响应，以免泄露 Key。");
    }
    HINTERNET open(const wchar_t *method, const std::string &suffix) {
        Http req(WinHttpOpenRequest(conn, method, wide(e.path + suffix).c_str(), nullptr,
                                    WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
                                    WINHTTP_FLAG_SECURE));
        DWORD redir = WINHTTP_OPTION_REDIRECT_POLICY_NEVER,
              disable = WINHTTP_DISABLE_COOKIES | WINHTTP_DISABLE_AUTHENTICATION;
        if (!WinHttpSetTimeouts(req, 4000, 4000, 6000, 12000) ||
            !WinHttpSetOption(req, WINHTTP_OPTION_REDIRECT_POLICY, &redir, sizeof(redir)) ||
            !WinHttpSetOption(req, WINHTTP_OPTION_DISABLE_FEATURE, &disable, sizeof(disable)))
            throw std::runtime_error("无法配置 API 安全选项。");
        auto auth =
            wide("Authorization: Bearer " + c.key + "\r\nContent-Type: application/json\r\n");
        if (!WinHttpAddRequestHeaders(req, auth.c_str(), (DWORD)auth.size(),
                                      WINHTTP_ADDREQ_FLAG_ADD | WINHTTP_ADDREQ_FLAG_REPLACE))
            throw std::runtime_error("无法配置 API 认证。");
        SecureZeroMemory(auth.data(), auth.size() * sizeof(wchar_t));
        auto handle = req.h;
        req.h = nullptr;
        return handle;
    }
    static void send(HINTERNET req, const std::string &body) {
        if (!WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                                body.empty() ? WINHTTP_NO_REQUEST_DATA : (LPVOID)body.data(),
                                (DWORD)body.size(), (DWORD)body.size(), 0) ||
            !WinHttpReceiveResponse(req, nullptr))
            throw std::runtime_error("API 连接失败或超时。请检查地址、网络及代理。");
        checkStatus(req);
    }
    static std::string readBody(HINTERNET req) {
        std::string body;
        char b[4096];
        DWORD n;
        for (;;) {
            if (!WinHttpReadData(req, b, sizeof(b), &n))
                throw std::runtime_error("API 响应中断。");
            if (!n)
                break;
            if (body.size() + n > 262144)
                throw std::runtime_error("API 响应超过安全上限。");
            body.append(b, n);
        }
        return body;
    }

  public:
    explicit ModelApiClient(const qt::ApiConfig &value)
        : c(value), e(qt::endpoint(c.base)),
          session(WinHttpOpen(L"QuietTranslate/2.1", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                              WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0)),
          conn(WinHttpConnect(session, wide(e.host).c_str(), (INTERNET_PORT)e.port, 0)) {
        c.validate();
    }
    ~ModelApiClient() {
        if (!c.key.empty())
            SecureZeroMemory(c.key.data(), c.key.size());
    }
    std::string translate(const std::string &source,
                          const std::function<void(const std::string &)> &progress) {
        if (c.keepTerms && qt::standaloneTechnicalName(source))
            return source;
        frame(9, "api-request");
        auto onUsage = [](const qt::ApiUsage &u) { frame(8, u.json()); };
        Http req(open(L"POST", "/chat/completions"));
        auto body = qt::translationBody(c, source);
        send(req, body);
        if (!c.stream) {
            auto translated = qt::completion(readBody(req), onUsage);
            wide(translated);
            return translated;
        }
        wchar_t contentType[256];
        DWORD bytes = sizeof(contentType);
        if (!WinHttpQueryHeaders(req, WINHTTP_QUERY_CONTENT_TYPE, WINHTTP_HEADER_NAME_BY_INDEX,
                                 contentType, &bytes, WINHTTP_NO_HEADER_INDEX))
            throw std::runtime_error("API 未返回流式 Content-Type。可关闭流式后测试。");
        std::wstring type(contentType);
        std::transform(type.begin(), type.end(), type.begin(),
                       [](wchar_t v) { return (wchar_t)towlower(v); });
        if (type.find(L"text/event-stream") == std::wstring::npos)
            throw std::runtime_error(
                "服务未返回 SSE 流。请关闭流式输出后重试；未自动重复收费请求。");
        qt::ApiStream stream(
            c.protocol == 2 && c.model.find("qwen-mt-plus") == 0,
            [&](const std::string &s) {
                wide(s);
                progress(s);
            },
            onUsage);
        char buffer[4096];
        DWORD n;
        for (;;) {
            if (!WinHttpReadData(req, buffer, sizeof(buffer), &n))
                throw std::runtime_error("API 流式响应中断，未缓存。");
            if (!n)
                break;
            stream.feed(buffer, n);
            if (stream.complete())
                break;
        }
        auto translated = stream.finish();
        wide(translated);
        return translated;
    }
    std::vector<std::string> models() {
        Http req(open(L"GET", "/models"));
        send(req, {});
        return qt::modelList(readBody(req));
    }
};
static int modelService(bool mock, bool useCache, bool tool = false, bool list = false) {
    try {
        auto c = readApiInput();
        std::unique_ptr<ModelApiClient> api;
        qt::MemoryCache cache;
        if (list) {
            std::string out;
            if (mock)
                out = "qwen-mt-flash\nqwen-mt-lite\ncustom/model";
            else {
                api = std::make_unique<ModelApiClient>(c);
                for (const auto &m : api->models()) {
                    if (!out.empty())
                        out += '\n';
                    out += m;
                }
            }
            frame(2, out);
            return 0;
        }
        for (;;) {
            uint32_t h[2];
            auto in = GetStdHandle(STD_INPUT_HANDLE);
            if (!readExact(in, h, 8, true))
                return 0;
            if (h[0] != 10 || !h[1] || h[1] > 4000)
                throw std::runtime_error("API 原文协议无效。");
            std::string source(h[1], 0);
            readExact(in, source.data(), h[1]);
            wide(source);
            try {
                std::string translated;
                if (c.keepTerms && qt::standaloneTechnicalName(source)) {
                    translated = source;
                    frame(5, "技术名称保留 · 未发送请求");
                } else if (useCache && cache.get(source, GetTickCount64(), translated))
                    frame(5, "API 内存缓存命中 · 未发送请求");
                else {
                    if (mock) {
                        frame(9, "api-request");
                        qt::translationBody(c, source);
                        if (source == "FAIL")
                            throw std::runtime_error("mock API error");
                        translated = "测试译文：" + source;
                        frame(4, translated);
                        qt::ApiUsage usage;
                        usage.inputKnown = usage.outputKnown = usage.totalKnown = true;
                        usage.input = 10;
                        usage.output = 5;
                        usage.total = 15;
                        frame(8, usage.json());
                    } else {
                        if (!api)
                            api = std::make_unique<ModelApiClient>(c);
                        ULONGLONG last = 0;
                        translated = api->translate(source, [&](const std::string &p) {
                            auto now = GetTickCount64();
                            if (!last || now - last >= 40) {
                                frame(4, p);
                                last = now;
                            }
                        });
                    }
                    if (useCache)
                        cache.put(source, translated, GetTickCount64());
                }
                frame(2, translated);
            } catch (const std::exception &ex) {
                api.reset();
                frame(3, ex.what());
            }
            if (tool)
                return 0;
        }
    } catch (const std::exception &ex) {
        frame(3, ex.what());
        return 1;
    }
}
