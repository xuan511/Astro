#pragma once
#include "api.hpp"
#include <map>
#include <set>
#include <sstream>
#include <iomanip>
namespace qt {
constexpr size_t bookLimit = 8 * 1024 * 1024, bookCount = 4096;
inline bool hexText(const std::string &s, size_t n) {
    if (s.size() != n)
        return false;
    for (char c : s)
        if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f')))
            return false;
    return true;
}
inline bool uuidText(const std::string &s) {
    if (s.size() != 36)
        return false;
    for (size_t i = 0; i < s.size(); ++i) {
        if (i == 8 || i == 13 || i == 18 || i == 23) {
            if (s[i] != '-')
                return false;
        } else if (!hexText(s.substr(i, 1), 1))
            return false;
    }
    return true;
}
inline void safeText(const std::string &s, size_t limit) {
    if (s.size() > limit)
        throw std::runtime_error("学习内容超过长度限制。");
    for (unsigned char c : s)
        if (c < 32 && c != '\n' && c != '\r' && c != '\t')
            throw std::runtime_error("学习内容含无效控制字符。");
}
inline uint64_t natural(const Json &j, uint64_t max = 9000000000000000ULL) {
    if (j.kind != Json::Number || j.text.empty() || j.text.size() > 16)
        throw std::runtime_error("学习数据数值无效。");
    uint64_t n = 0;
    for (char c : j.text) {
        if (c < '0' || c > '9')
            throw std::runtime_error("学习数据数值无效。");
        n = n * 10 + c - '0';
        if (n > max)
            throw std::runtime_error("学习数据数值越界。");
    }
    return n;
}
inline std::string fieldString(const Json &j, const char *k, size_t max) {
    const auto &v = j.at(k);
    if (v.kind != Json::String)
        throw std::runtime_error("学习数据字段无效。");
    safeText(v.text, max);
    return v.text;
}
inline bool fieldBool(const Json &j, const char *k) {
    const auto &v = j.at(k);
    if (v.kind != Json::Bool)
        throw std::runtime_error("学习数据布尔字段无效。");
    return v.text == "true";
}
inline std::string revision(uint64_t stamp, const std::string &device) {
    std::ostringstream s;
    s << std::setw(20) << std::setfill('0') << stamp << ":" << device;
    return s.str();
}
inline uint64_t revClock(const std::string &r) {
    if (r.size() != 57 || r[20] != ':' || !uuidText(r.substr(21)))
        throw std::runtime_error("学习记录版本无效。");
    uint64_t n = 0;
    for (size_t i = 0; i < 20; ++i) {
        if (r[i] < '0' || r[i] > '9')
            throw std::runtime_error("学习记录版本无效。");
        if (n > 900000000000000ULL)
            throw std::runtime_error("学习记录版本越界。");
        n = n * 10 + r[i] - '0';
    }
    if (n > 9000000000000000ULL)
        throw std::runtime_error("学习记录版本越界。");
    return n;
}
struct BookEntry {
    std::string key, source, translation, detail, note, engine, rev;
    uint64_t first = 0, last = 0, due = 0;
    unsigned level = 0;
    bool star = false, known = false, deleted = false;
    std::map<std::string, uint64_t> counts;
    uint64_t hits() const {
        uint64_t n = 0;
        for (const auto &v : counts)
            n += v.second;
        return n;
    }
    std::string json() const {
        std::string s =
            "{\"key\":" + jsonString(key) + ",\"source\":" + jsonString(source) +
            ",\"translation\":" + jsonString(translation) + ",\"detail\":" + jsonString(detail) +
            ",\"note\":" + jsonString(note) + ",\"engine\":" + jsonString(engine) +
            ",\"rev\":" + jsonString(rev) + ",\"first\":" + std::to_string(first) +
            ",\"last\":" + std::to_string(last) + ",\"due\":" + std::to_string(due) +
            ",\"level\":" + std::to_string(level) + ",\"star\":" + (star ? "true" : "false") +
            ",\"known\":" + (known ? "true" : "false") +
            ",\"deleted\":" + (deleted ? "true" : "false") + ",\"counts\":{";
        bool firstCount = true;
        for (const auto &v : counts) {
            if (!firstCount)
                s += ',';
            firstCount = false;
            s += jsonString(v.first) + ":" + std::to_string(v.second);
        }
        return s + "}}";
    }
    static BookEntry parse(const Json &j) {
        BookEntry e;
        e.key = fieldString(j, "key", 64);
        if (!hexText(e.key, 64))
            throw std::runtime_error("生词标识无效。");
        e.source = fieldString(j, "source", 4000);
        e.translation = fieldString(j, "translation", 16000);
        e.detail = fieldString(j, "detail", 8000);
        e.note = fieldString(j, "note", 2000);
        e.engine = fieldString(j, "engine", 256);
        e.rev = fieldString(j, "rev", 57);
        revClock(e.rev);
        e.first = natural(j.at("first"));
        e.last = natural(j.at("last"));
        e.due = natural(j.at("due"));
        e.level = (unsigned)natural(j.at("level"), 5);
        e.star = fieldBool(j, "star");
        e.known = fieldBool(j, "known");
        e.deleted = fieldBool(j, "deleted");
        const auto &c = j.at("counts");
        if (c.kind != Json::Object || c.object.size() > 32)
            throw std::runtime_error("学习设备计数无效。");
        for (const auto &v : c.object) {
            if (!uuidText(v.first))
                throw std::runtime_error("学习设备标识无效。");
            e.counts[v.first] = natural(v.second, 1000000000);
        }
        if (!e.deleted && (e.source.empty() || !english(e.source)))
            throw std::runtime_error("生词原文无效。");
        if (e.first > e.last && e.last)
            throw std::runtime_error("学习时间无效。");
        return e;
    }
};
inline BookEntry mergeEntry(const BookEntry &a, const BookEntry &b) {
    if (a.key != b.key)
        throw std::runtime_error("不能合并不同生词。");
    BookEntry out = a.rev >= b.rev ? a : b;
    out.first = (!a.first || !b.first) ? std::max(a.first, b.first) : std::min(a.first, b.first);
    out.last = std::max(a.last, b.last);
    for (const auto &v : a.counts)
        out.counts[v.first] = std::max(out.counts[v.first], v.second);
    for (const auto &v : b.counts)
        out.counts[v.first] = std::max(out.counts[v.first], v.second);
    if (out.counts.size() > 32)
        throw std::runtime_error("该词的设备数超过 32，未丢弃数据。");
    return out;
}
class Notebook {
    std::map<std::string, BookEntry> rows;
    size_t entryBytes = 0;
    static size_t bytes(size_t entries, size_t payload) {
        return std::string("{\"schema\":1,\"entries\":[],\"dirty\":[]}").size() + payload +
               (entries ? entries - 1 : 0);
    }
    bool apply(const BookEntry &e) {
        auto old = rows.find(e.key);
        bool exists = old != rows.end();
        if (!exists && rows.size() >= bookCount)
            throw std::runtime_error("生词本已满（4096 条）。");
        auto next = exists ? mergeEntry(old->second, e) : e;
        auto encoded = next.json();
        auto previous = exists ? old->second.json() : std::string{};
        size_t newBytes = entryBytes - previous.size() + encoded.size();
        if (bytes(rows.size() + (exists ? 0 : 1), newBytes) > bookLimit)
            throw std::runtime_error("生词本超过 8 MiB，本次修改未保存。请先导出并整理。");
        bool changed = !exists || encoded != previous;
        if (exists)
            std::swap(old->second, next);
        else
            rows.emplace(e.key, std::move(next));
        entryBytes = newBytes;
        return changed;
    }

  public:
    const std::map<std::string, BookEntry> &entries() const {
        return rows;
    }
    size_t serializedBytes() const {
        return bytes(rows.size(), entryBytes);
    }
    void importEntry(const BookEntry &e) {
        apply(e);
    }
    size_t importBatch(const Notebook &incoming) {
        auto candidate = *this;
        size_t changed = 0;
        for (const auto &v : incoming.entries())
            if (!v.second.deleted) {
                auto old = candidate.find(v.first);
                auto before = old ? old->json() : std::string{};
                candidate.importEntry(v.second);
                if (candidate.find(v.first)->json() != before)
                    ++changed;
            }
        *this = std::move(candidate);
        return changed;
    }
    void edit(const std::string &key, const std::string &note, bool star, bool known,
              const std::string &detail, const std::string &device, uint64_t now) {
        auto p = find(key);
        if (!p || p->deleted)
            throw std::runtime_error("请先选择有效词条。");
        safeText(note, 2000);
        safeText(detail, 8000);
        BookEntry e = *p;
        e.note = note;
        e.star = star;
        e.known = known;
        if (!detail.empty())
            e.detail = detail;
        touch(e, device, now);
        apply(e);
    }
    const BookEntry *find(const std::string &key) {
        auto i = rows.find(key);
        return i == rows.end() ? nullptr : &i->second;
    }
    const BookEntry *find(const std::string &key) const {
        auto i = rows.find(key);
        return i == rows.end() ? nullptr : &i->second;
    }
    bool merge(const BookEntry &e) {
        return apply(e);
    }
    void touch(BookEntry &e, const std::string &device, uint64_t now) {
        if (!uuidText(device))
            throw std::runtime_error("本机学习标识无效。");
        auto previous = e.rev.empty() ? 0 : revClock(e.rev);
        if (now > 9000000000000000ULL || previous >= 9000000000000000ULL)
            throw std::runtime_error("学习记录时间或版本越界，本次修改未生效。");
        e.rev = revision(std::max(now, previous + 1), device);
    }
    void record(const std::string &key, const std::string &source, const std::string &translation,
                const std::string &engine, const std::string &device, uint64_t now,
                bool count = true, const std::string &detail = "", bool favorite = false) {
        safeText(source, 4000);
        safeText(translation, 16000);
        safeText(engine, 256);
        safeText(detail, 8000);
        if (!hexText(key, 64) || source.empty() || !english(source))
            throw std::runtime_error("无法保存该学习词条。");
        BookEntry next;
        auto old = find(key);
        if (old)
            next = *old;
        else {
            next.key = key;
            next.first = now;
        }
        if (next.deleted) {
            next.level = 0;
            next.due = 0;
            next.known = false;
        }
        if (!next.counts.count(device) && next.counts.size() >= 32)
            throw std::runtime_error("设备数达到上限。");
        next.source = source;
        if (!translation.empty())
            next.translation = translation;
        next.engine = engine;
        if (!detail.empty())
            next.detail = detail;
        if (favorite)
            next.star = true;
        next.deleted = false;
        next.last = std::max(now, next.last);
        if (count) {
            auto &n = next.counts[device];
            if (n >= 1000000000)
                throw std::runtime_error("查询计数达到上限。");
            ++n;
        }
        touch(next, device, now);
        apply(next);
    }
    void erase(const std::string &key, const std::string &device, uint64_t now) {
        auto p = find(key);
        if (!p)
            return;
        BookEntry e = *p;
        e.deleted = true;
        e.source.clear();
        e.translation.clear();
        e.detail.clear();
        e.note.clear();
        e.engine.clear();
        e.star = false;
        e.known = false;
        e.level = 0;
        e.due = 0;
        touch(e, device, now);
        apply(e);
    }
    void review(const std::string &key, bool remembered, const std::string &device, uint64_t now) {
        auto p = find(key);
        if (!p || p->deleted)
            return;
        BookEntry e = *p;
        e.level = remembered ? std::min(5u, e.level + 1) : 0;
        e.known = e.level == 5;
        const uint64_t days[] = {1, 3, 7, 14, 30, 60};
        if (now > 9000000000000000ULL - days[e.level] * 86400000ULL)
            throw std::runtime_error("复习时间越界，本次修改未生效。");
        e.due = now + days[e.level] * 86400000ULL;
        touch(e, device, now);
        apply(e);
    }
    std::vector<std::string> sorted(const std::string &query = "", bool frequency = false,
                                    bool stars = false, bool reviewOnly = false,
                                    uint64_t now = 0) const {
        std::vector<std::string> out;
        auto q = normalize(query);
        for (const auto &v : rows) {
            const auto &e = v.second;
            if (e.deleted || (stars && !e.star) ||
                (reviewOnly && (e.known || (e.due && e.due > now))))
                continue;
            if (!q.empty() && normalize(e.source + " " + e.translation + " " + e.note).find(q) ==
                                  std::string::npos)
                continue;
            out.push_back(v.first);
        }
        std::sort(out.begin(), out.end(), [&](const auto &a, const auto &b) {
            const auto &x = rows.at(a);
            const auto &y = rows.at(b);
            if (reviewOnly && x.due != y.due)
                return x.due < y.due;
            if (frequency && x.hits() != y.hits())
                return x.hits() > y.hits();
            if (x.last != y.last)
                return x.last > y.last;
            return a < b;
        });
        return out;
    }
    std::string json() const {
        std::string s = "{\"schema\":1,\"entries\":[";
        bool first = true;
        for (const auto &v : rows) {
            if (!first)
                s += ',';
            first = false;
            s += v.second.json();
            if (s.size() > bookLimit)
                throw std::runtime_error("生词本超过 8 MiB，未截断记录。");
        }
        s += "],\"dirty\":[]}"; // Empty legacy field for backup compatibility.
        if (s.size() > bookLimit)
            throw std::runtime_error("生词本超过 8 MiB，未截断记录。");
        return s;
    }
    static Notebook parse(const std::string &s) {
        const auto j = Parser(s, bookLimit).parse();
        if (natural(j.at("schema"), 1) != 1)
            throw std::runtime_error("不支持的生词本格式。");
        const auto &a = j.at("entries");
        if (a.kind != Json::Array || a.array.size() > bookCount)
            throw std::runtime_error("生词本容量无效。");
        Notebook b;
        for (const auto &v : a.array) {
            auto e = BookEntry::parse(v);
            if (b.find(e.key))
                throw std::runtime_error("生词本包含重复标识，未合并或覆盖。");
            b.merge(e);
        }
        if (j.object.count("dirty")) {
            const auto &d = j.at("dirty");
            if (d.kind != Json::Array || d.array.size() > bookCount)
                throw std::runtime_error("旧版备份索引无效。");
            for (const auto &v : d.array) {
                if (v.kind != Json::String || !b.find(v.text))
                    throw std::runtime_error("旧版备份索引无效。");
            }
        }
        return b;
    }
};
inline bool shortLearningQuery(const std::string &s) {
    if (s.empty() || s.size() > 160 || s.find('\n') != std::string::npos ||
        s.find('\r') != std::string::npos)
        return false;
    unsigned words = 1;
    for (char c : s)
        if (c == ' ' && ++words > 8)
            return false;
    return english(s);
}
} // namespace qt
