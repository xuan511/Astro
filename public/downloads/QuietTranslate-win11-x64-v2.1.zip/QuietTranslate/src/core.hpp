#pragma once
#include <string>
#include <vector>
#include <map>
#include <stdexcept>
#include <cctype>
#include <cstdint>
namespace qt {
inline void utf8(std::string &out, unsigned c) {
    if (c <= 0x7f)
        out += char(c);
    else if (c <= 0x7ff) {
        out += char(0xc0 | (c >> 6));
        out += char(0x80 | (c & 63));
    } else if (c <= 0xffff) {
        out += char(0xe0 | (c >> 12));
        out += char(0x80 | ((c >> 6) & 63));
        out += char(0x80 | (c & 63));
    } else {
        out += char(0xf0 | (c >> 18));
        out += char(0x80 | ((c >> 12) & 63));
        out += char(0x80 | ((c >> 6) & 63));
        out += char(0x80 | (c & 63));
    }
}
struct Json {
    enum Kind { Null, String, Number, Bool, Object, Array } kind = Null;
    std::string text;
    std::map<std::string, Json> object;
    std::vector<Json> array;
    const Json &at(const std::string &k) const {
        auto i = object.find(k);
        if (kind != Object || i == object.end())
            throw std::runtime_error("missing JSON field");
        return i->second;
    }
};
class Parser {
    const std::string &s;
    size_t maxBytes;
    size_t p = 0;
    void ws() {
        while (p < s.size() && (s[p] == ' ' || s[p] == '\n' || s[p] == '\r' || s[p] == '\t'))
            ++p;
    }
    char take() {
        if (p >= s.size())
            throw std::runtime_error("truncated JSON");
        return s[p++];
    }
    unsigned hex() {
        unsigned n = 0;
        for (int i = 0; i < 4; ++i) {
            char c = take();
            n <<= 4;
            if (c >= '0' && c <= '9')
                n += c - '0';
            else if (c >= 'a' && c <= 'f')
                n += c - 'a' + 10;
            else if (c >= 'A' && c <= 'F')
                n += c - 'A' + 10;
            else
                throw std::runtime_error("bad unicode");
        }
        return n;
    }
    std::string str() {
        if (take() != '"')
            throw std::runtime_error("expected string");
        std::string o;
        for (;;) {
            unsigned char c = take();
            if (c == '"')
                break;
            if (c < 32)
                throw std::runtime_error("control in JSON");
            if (c != '\\') {
                o += char(c);
                continue;
            }
            char e = take();
            switch (e) {
            case '"':
            case '\\':
            case '/':
                o += e;
                break;
            case 'n':
                o += '\n';
                break;
            case 'r':
                o += '\r';
                break;
            case 't':
                o += '\t';
                break;
            case 'b':
                o += '\b';
                break;
            case 'f':
                o += '\f';
                break;
            case 'u': {
                unsigned u = hex();
                if (u >= 0xd800 && u <= 0xdbff) {
                    if (take() != '\\' || take() != 'u')
                        throw std::runtime_error("missing surrogate");
                    unsigned l = hex();
                    if (l < 0xdc00 || l > 0xdfff)
                        throw std::runtime_error("bad surrogate");
                    u = 0x10000 + ((u - 0xd800) << 10) + (l - 0xdc00);
                } else if (u >= 0xdc00 && u <= 0xdfff)
                    throw std::runtime_error("bad surrogate");
                utf8(o, u);
                break;
            }
            default:
                throw std::runtime_error("bad escape");
            }
        }
        return o;
    }
    Json value(int depth) {
        if (depth > 32)
            throw std::runtime_error("JSON too deep");
        ws();
        if (p >= s.size())
            throw std::runtime_error("empty JSON");
        Json j;
        char c = s[p];
        if (c == '"') {
            j.kind = Json::String;
            j.text = str();
        } else if (c == '{' || c == '[') {
            ++p;
            j.kind = c == '{' ? Json::Object : Json::Array;
            ws();
            char end = c == '{' ? '}' : ']';
            if (p < s.size() && s[p] == end) {
                ++p;
                return j;
            }
            for (;;) {
                ws();
                if (c == '{') {
                    std::string k = str();
                    ws();
                    if (take() != ':')
                        throw std::runtime_error("expected colon");
                    if (j.object.count(k))
                        throw std::runtime_error("duplicate key");
                    j.object.emplace(k, value(depth + 1));
                } else
                    j.array.push_back(value(depth + 1));
                ws();
                char sep = take();
                if (sep == end)
                    break;
                if (sep != ',')
                    throw std::runtime_error("expected comma");
            }
        } else if (c == 't' || c == 'f' || c == 'n') {
            std::string word = c == 't' ? "true" : c == 'f' ? "false" : "null";
            if (s.compare(p, word.size(), word) != 0)
                throw std::runtime_error("bad literal");
            p += word.size();
            j.kind = c == 'n' ? Json::Null : Json::Bool;
            j.text = word;
        } else {
            j.kind = Json::Number;
            size_t b = p;
            if (s[p] == '-')
                ++p;
            if (p >= s.size())
                throw std::runtime_error("bad number");
            if (s[p] == '0')
                ++p;
            else {
                if (s[p] < '1' || s[p] > '9')
                    throw std::runtime_error("bad number");
                while (p < s.size() && isdigit((unsigned char)s[p]))
                    ++p;
            }
            if (p < s.size() && s[p] == '.') {
                ++p;
                size_t a = p;
                while (p < s.size() && isdigit((unsigned char)s[p]))
                    ++p;
                if (p == a)
                    throw std::runtime_error("bad fraction");
            }
            if (p < s.size() && (s[p] == 'e' || s[p] == 'E')) {
                ++p;
                if (p < s.size() && (s[p] == '+' || s[p] == '-'))
                    ++p;
                size_t a = p;
                while (p < s.size() && isdigit((unsigned char)s[p]))
                    ++p;
                if (p == a)
                    throw std::runtime_error("bad exponent");
            }
            j.text = s.substr(b, p - b);
        }
        return j;
    }

  public:
    explicit Parser(const std::string &t, size_t limit = 262144) : s(t), maxBytes(limit) {}
    Json parse() {
        if (s.size() > maxBytes)
            throw std::runtime_error("response too large");
        Json j = value(0);
        ws();
        if (p != s.size())
            throw std::runtime_error("trailing JSON");
        return j;
    }
};
inline std::string translation(const std::string &response) {
    auto j = Parser(response).parse();
    const auto &status = j.at("responseStatus");
    if (status.kind != Json::Number || status.text != "200")
        throw std::runtime_error("服务限额已用尽或服务拒绝请求。请稍后重试，或切换离线词典。");
    auto &t = j.at("responseData").at("translatedText");
    if (t.kind != Json::String || t.text.empty())
        throw std::runtime_error("服务返回空译文。");
    return t.text;
}
inline std::string trim(std::string s) {
    size_t b = s.find_first_not_of(" \t\r\n");
    if (b == std::string::npos)
        return {};
    return s.substr(b, s.find_last_not_of(" \t\r\n") - b + 1);
}
inline std::string normalize(std::string s) {
    s = trim(s);
    for (char &c : s)
        if ((unsigned char)c < 128)
            c = char(tolower((unsigned char)c));
    while (!s.empty() && (s.back() == '.' || s.back() == ',' || s.back() == ';'))
        s.pop_back();
    return s;
}
inline std::string url(const std::string &s) {
    std::string o;
    const char *h = "0123456789ABCDEF";
    for (unsigned char c : s) {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
            c == '-' || c == '_' || c == '.' || c == '~')
            o += char(c);
        else {
            o += '%';
            o += h[c >> 4];
            o += h[c & 15];
        }
    }
    return o;
}
inline std::vector<std::string> chunks(const std::string &s, size_t limit = 450) {
    if (limit < 4)
        throw std::runtime_error("invalid chunk limit");
    std::vector<std::string> out;
    size_t pos = 0;
    while (pos < s.size()) {
        size_t end = std::min(pos + limit, s.size());
        while (end < s.size() && ((unsigned char)s[end] & 0xc0) == 0x80)
            --end;
        if (end == pos)
            throw std::runtime_error("bad UTF-8 boundary");
        if (end < s.size()) {
            size_t space = s.find_last_of(" \n\t", end - 1);
            if (space != std::string::npos && space > pos + limit / 2)
                end = space + 1;
        }
        out.push_back(s.substr(pos, end - pos));
        pos = end;
    }
    return out;
}
inline bool english(const std::string &s) {
    for (unsigned char c : s)
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
            return true;
    return false;
}
inline std::string html(std::string s) {
    const std::pair<const char *, const char *> es[] = {{"&lt;", "<"},    {"&gt;", ">"},
                                                        {"&quot;", "\""}, {"&#39;", "'"},
                                                        {"&apos;", "'"},  {"&amp;", "&"}};
    for (auto e : es) {
        size_t p = 0;
        while ((p = s.find(e.first, p)) != std::string::npos) {
            s.replace(p, std::char_traits<char>::length(e.first), e.second);
            p += std::char_traits<char>::length(e.second);
        }
    }
    return s;
}
} // namespace qt
