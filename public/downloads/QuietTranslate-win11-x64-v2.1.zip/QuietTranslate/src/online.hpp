#pragma once
#include "core.hpp"
#include <list>
#include <functional>
#include <utility>

namespace qt {
// Bounds count and payload bytes; expiration is based on insertion, not last access.
class MemoryCache {
    struct Entry {
        std::string key, value;
        uint64_t added;
    };
    std::list<Entry> items;
    size_t used = 0, maxCount, maxBytes;
    uint64_t ttl;
    void remove(std::list<Entry>::iterator i) {
        used -= i->key.size() + i->value.size();
        items.erase(i);
    }

  public:
    explicit MemoryCache(size_t count = 64, size_t bytes = 512 * 1024,
                         uint64_t lifetime = 10 * 60 * 1000)
        : maxCount(count), maxBytes(bytes), ttl(lifetime) {}
    void clear() {
        items.clear();
        used = 0;
    }
    size_t size() const {
        return items.size();
    }
    uint64_t nextExpiry() const {
        uint64_t earliest = 0;
        for (const auto &item : items) {
            auto at = item.added + ttl;
            if (!earliest || at < earliest)
                earliest = at;
        }
        return earliest;
    }
    size_t bytes() const {
        return used;
    }
    void expire(uint64_t now) {
        for (auto i = items.begin(); i != items.end();) {
            auto current = i++;
            if (now < current->added || now - current->added >= ttl)
                remove(current);
        }
    }
    bool get(const std::string &key, uint64_t now, std::string &value) {
        expire(now);
        for (auto i = items.begin(); i != items.end(); ++i)
            if (i->key == key) {
                value = i->value;
                items.splice(items.begin(), items, i);
                return true;
            }
        return false;
    }
    void put(const std::string &key, const std::string &value, uint64_t now) {
        expire(now);
        for (auto i = items.begin(); i != items.end(); ++i)
            if (i->key == key) {
                remove(i);
                break;
            }
        size_t weight = key.size() + value.size();
        if (maxCount == 0 || weight > maxBytes || value.empty())
            return;
        while (!items.empty() && (items.size() >= maxCount || used + weight > maxBytes))
            remove(std::prev(items.end()));
        items.push_front({key, value, now});
        used += weight;
    }
};
struct TranslationProgress {
    std::string text;
    size_t completed = 0, total = 0, requests = 0, hits = 0;
};
// Request boundary is at most 500 UTF-8 bytes, as specified by MyMemory.
// Kept sequential to respect service load; one session owns the transport.
class OnlineEngine {
    MemoryCache parts;

  public:
    using Request = std::function<std::string(const std::string &)>;
    using Clock = std::function<uint64_t()>;
    using Progress = std::function<void(const TranslationProgress &)>;
    void clear() {
        parts.clear();
    }
    TranslationProgress translate(const std::string &source, bool useCache, const Request &request,
                                  const Clock &clock, const Progress &progress) {
        if (source.empty() || source.size() > 4000 || !english(source))
            throw std::runtime_error("请提交不超过 4000 UTF-8 字节的英文。");
        if (!useCache)
            parts.clear();
        auto plan = chunks(source, 500);
        TranslationProgress state;
        state.total = plan.size();
        for (const auto &part : plan) {
            std::string translated;
            if (useCache && parts.get(part, clock(), translated))
                ++state.hits;
            else {
                translated = request(part);
                ++state.requests;
                if (translated.empty() || translated.size() > 16000)
                    throw std::runtime_error("译文为空或超过安全长度限制。");
                if (useCache)
                    parts.put(part, translated, clock());
            }
            if (!state.text.empty())
                state.text += ' ';
            if (state.text.size() + translated.size() > 30000)
                throw std::runtime_error("译文超过安全长度限制。");
            state.text += translated;
            ++state.completed;
            progress(state); // Publish each completed segment; never cache an error as a result.
        }
        return state;
    }
};
struct Frame {
    uint32_t type = 0;
    std::string text;
};
class FrameDecoder {
    std::vector<char> data;

  public:
    void feed(const char *p, size_t n) {
        if (data.size() + n > 131072)
            throw std::runtime_error("任务输出超出安全限制。");
        data.insert(data.end(), p, p + n);
    }
    bool pop(Frame &frame) {
        if (data.size() < 8)
            return false;
        auto get = [&](size_t offset) {
            uint32_t x = 0;
            for (int i = 0; i < 4; ++i)
                x |= uint32_t((unsigned char)data[offset + i]) << (8 * i);
            return x;
        };
        uint32_t type = get(0), n = get(4);
        if (n > 65536)
            throw std::runtime_error("任务帧长度无效。");
        if (data.size() < 8 + n)
            return false;
        frame = {type, std::string(data.data() + 8, n)};
        data.erase(data.begin(), data.begin() + 8 + n);
        return true;
    }
    bool empty() const {
        return data.empty();
    }
};
} // namespace qt
