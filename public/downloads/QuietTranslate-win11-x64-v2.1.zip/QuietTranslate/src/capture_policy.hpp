#pragma once
#include <array>
#include <cstdint>
#include <stdexcept>
#include <string>
namespace qt {
class NoSelection : public std::runtime_error {
  public:
    using std::runtime_error::runtime_error;
};
struct CopyKey {
    uint16_t vk;
    bool up, extended;
};
// Only a copy shortcut: never cut/paste, Insert alone, Shift+Insert, or Ctrl+C.
inline constexpr std::array<CopyKey, 4> copyKeys{
    {{0x11, false, false}, {0x2d, false, true}, {0x2d, true, true}, {0x11, true, false}}};
inline bool copyOwner(uint32_t before, uint32_t after, uint32_t top, uint32_t focus,
                      uint32_t owner) {
    return after != 0 && before != after && owner != 0 && (owner == top || owner == focus);
}
inline bool allowedCopyInput(uint32_t actual, uint32_t baseline, uint32_t injected) {
    return actual == baseline || actual == injected;
}
inline std::string executableBase(std::string s) {
    auto p = s.find_last_of("\\/");
    if (p != std::string::npos)
        s.erase(0, p + 1);
    for (char &c : s)
        if (c >= 'A' && c <= 'Z')
            c = char(c - 'A' + 'a');
    return s;
}
inline bool terminalProcess(const std::string &s) {
    auto e = executableBase(s);
    return e == "cmd.exe" || e == "powershell.exe" || e == "pwsh.exe" ||
           e == "windowsterminal.exe" || e == "wt.exe" || e == "conhost.exe" ||
           e == "openconsole.exe" || e == "mintty.exe" || e == "putty.exe";
}
inline bool releaseKeyAllowed(uint16_t key, uint16_t trigger) {
    return (trigger && key == trigger) || key == 0x10 || key == 0x11 || key == 0x12 ||
           (key >= 0xa0 && key <= 0xa5);
}
// Foreground/focus must remain the same. Release waiting is per task, never a background hook.
class ReleaseGate {
    uint64_t started, quietAt = 0;
    bool quiet = false;

  public:
    explicit ReleaseGate(uint64_t now) : started(now) {}
    bool ready(uint64_t now, bool held, bool stable) {
        if (!stable)
            throw std::runtime_error("等待释放快捷键时前台或焦点变化，已取消。");
        if (now < started || now - started > 1800)
            throw std::runtime_error("请松开快捷键后重试；本次未发送复制按键。");
        if (held) {
            quiet = false;
            return false;
        }
        if (!quiet) {
            quietAt = now;
            quiet = true;
            return false;
        }
        return now - quietAt >= 40;
    }
};
} // namespace qt
