#ifndef UNICODE
#define UNICODE
#endif
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>
#include <winhttp.h>
#include <wincrypt.h>
#include <cwctype>
#include <uiautomation.h>
#include <commctrl.h>
#include <commdlg.h>
#include <dwmapi.h>
#include <string>
#include <vector>
#include <memory>
#include <stdexcept>
#include <algorithm>
#include <cstdint>
#include "core.hpp"
#include "glossary.hpp"
#include "online.hpp"
#include "study.hpp"
#include "selection.hpp"
#include "api.hpp"
#include "native_selection.hpp"
#include "capture_policy.hpp"
#include "notebook.hpp"
#include "ocr_policy.hpp"

static const wchar_t *APP = L"轻译 2.1 · QuietTranslate";
static constexpr UINT TRAY = WM_APP + 1;
static constexpr int HOTKEY = 1, EDIT_SOURCE = 101, EDIT_RESULT = 102, BTN_TRANSLATE = 103,
                     BTN_SETTINGS = 104, BTN_HIDE = 105, CHECK_ONLINE = 201, COMBO_HOTKEY = 202,
                     BTN_SAVE = 203, CHECK_CACHE = 205, CHECK_DICT = 206, COMBO_CAPTURE = 207,
                     COMBO_ENGINE = 208, BTN_API = 209, API_PRESET = 601, API_BASE = 602,
                     API_KEY = 603, API_MODEL = 604, API_PROTOCOL = 605, API_STREAM = 606,
                     API_TOKENS = 607, API_MODELS = 608, API_TEST = 609, API_SAVE = 610,
                     API_CANCEL = 611, API_FORGET = 612, API_LIMIT = 613, BTN_STUDY = 106,
                     STUDY_TERM = 501, STUDY_LOCAL = 502, STUDY_ONLINE = 503, STUDY_CLOSE = 504;
static HINSTANCE instance;
static HWND host, popup, settings, sourceBox, resultBox, statusLabel, onlineCheck, keyCombo,
    cacheCheck, dictionaryCheck, captureCombo, studyWindow, studyCombo, studyOutput, studyStatus,
    keywordsLabel, engineCombo, apiWindow, apiPreset, apiBase, apiKey, apiModel, apiProtocol,
    apiStream, apiTokens, apiStatus, apiHint, apiLimit;
static HFONT font;
static HBRUSH bg;
static NOTIFYICONDATAW tray{};
static bool online = false, paused = false, registered = false, manual = false;
static bool cacheEnabled = true, dictionaryAllowed = false;
static int captureMode =
    0; // 0 smart, 1 universal copy, 2 manual, 3 pointer text, 4 strict UIA/native
static bool capturePreviewOnly = false, universalCopyAllowed = false;
static bool apiEnabled = false;
static qt::ApiConfig apiConfig;
static std::string engineLabel() {
    return apiEnabled ? apiConfig.label() : "MyMemory";
}
static qt::CopiedSequenceGuard copiedSequence;
static std::vector<qt::Keyword> studyKeywords;
static std::string studyPrefix, studyPartial;
static bool studyActive = false;
static ULONGLONG studyDeadline = 0;
static void stopStudy();
static void resetStudy();
static void setStudySource(const std::string &source);
static void showStudy();
static void pollStudy();
static void selectStudyWord();
static void queryStudyWord();
static std::string learningScopeKey();
static void rememberTranslation(const std::string &, const std::string &, const std::string &);
static void rememberStudy(const std::string &, const std::string &, const std::string &);
static void clearLearningTranslation();
static std::string studyLearningScope;
static int keyIndex = 0;
static std::wstring config;
static UINT taskbarCreated;
static constexpr int OCR_HOTKEY = 2, BTN_OCR = 108;
static constexpr int BTN_BILL = 109, API_INCLUDE_USAGE = 614, API_BILL = 615, API_KEEP_TERMS = 616,
                     API_SMART_MIXED = 617;
static HWND apiIncludeUsage, apiKeepTerms, apiSmartMixed;
static bool ocrRegistered = false;
static bool ocrShortcutEnabled = true;
static void beginOcrSelection();
static void cancelOcrSelection(bool restore = true);
static void restoreOcrWindows();
static void finishOcrText(const std::string &);
struct Shortcut {
    UINT mods, vk;
    const wchar_t *name;
};
static const Shortcut shortcuts[] = {{MOD_CONTROL | MOD_SHIFT, 'E', L"Ctrl + Shift + E"},
                                     {MOD_CONTROL | MOD_SHIFT, 'Q', L"Ctrl + Shift + Q"},
                                     {MOD_ALT | MOD_SHIFT, 'T', L"Alt + Shift + T"},
                                     {MOD_CONTROL | MOD_ALT, 'J', L"Ctrl + Alt + J"}};
static std::wstring wide(const std::string &s) {
    if (s.empty())
        return {};
    int n = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, s.data(), (int)s.size(), nullptr, 0);
    if (!n)
        throw std::runtime_error("invalid UTF-8");
    std::wstring w(n, 0);
    MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, s.data(), (int)s.size(), w.data(), n);
    return w;
}
static std::string narrow(const std::wstring &w) {
    if (w.empty())
        return {};
    int n = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, w.data(), (int)w.size(), nullptr, 0,
                                nullptr, nullptr);
    if (!n)
        throw std::runtime_error("invalid UTF-16");
    std::string s(n, 0);
    WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, w.data(), (int)w.size(), s.data(), n,
                        nullptr, nullptr);
    return s;
}
static std::wstring text(HWND h) {
    int n = GetWindowTextLengthW(h);
    std::wstring t(n + 1, 0);
    GetWindowTextW(h, t.data(), n + 1);
    t.resize(n);
    return t;
}
template <class T> struct Com {
    T *p = nullptr;
    ~Com() {
        if (p)
            p->Release();
    }
    T **put() {
        if (p) {
            p->Release();
            p = nullptr;
        }
        return &p;
    }
    T *operator->() const {
        return p;
    }
    operator bool() const {
        return p != nullptr;
    }
    Com() = default;
    Com(const Com &) = delete;
    Com &operator=(const Com &) = delete;
};
struct Handle {
    HANDLE h = nullptr;
    Handle() = default;
    explicit Handle(HANDLE p) : h(p) {}
    ~Handle() {
        if (h && h != INVALID_HANDLE_VALUE)
            CloseHandle(h);
    }
    Handle(const Handle &) = delete;
    Handle &operator=(const Handle &) = delete;
};
struct Http {
    HINTERNET h;
    explicit Http(HINTERNET p) : h(p) {
        if (!h)
            throw std::runtime_error("网络初始化失败。请检查系统网络设置。");
    }
    ~Http() {
        WinHttpCloseHandle(h);
    }
    operator HINTERNET() const {
        return h;
    }
};

// Native/UIA capture reads selected ranges only. Smart/universal copy is a separate, guarded
// Ctrl+Insert stage; strict mode never enters it. No full-document retrieval.
static bool withinTarget(HWND target, HWND candidate) {
    return target && candidate && (candidate == target || IsChild(target, candidate));
}
#include "native_capture.hpp"
struct CaptureStats {
    int paths = 0, nodes = 0, patterns = 0, ranges = 0, emptyRanges = 0, propertyFailures = 0;
    std::string nativeClass = "unknown";
    std::string summary() const {
        return "focus=" + nativeClass + "; paths=" + std::to_string(paths) +
               "; nodes=" + std::to_string(nodes) + "; patterns=" + std::to_string(patterns) +
               "; ranges=" + std::to_string(ranges) + "; empty=" + std::to_string(emptyRanges) +
               "; properties=" + std::to_string(propertyFailures);
    }
};
struct Elements {
    std::vector<IUIAutomationElement *> values;
    ~Elements() {
        for (auto element : values)
            element->Release();
    }
    void add(IUIAutomationElement *element) {
        element->AddRef();
        values.push_back(element);
    }
};
class SelectionReader {
    IUIAutomation *uia;
    HWND target;
    IUIAutomationElement *root;
    Com<IUIAutomationTreeWalker> walker;
    Com<IUIAutomationElement> scope;
    CaptureStats &stats;
    ULONGLONG deadline = GetTickCount64() + 1000;
    bool remaining() const {
        return stats.nodes < 256 && GetTickCount64() < deadline;
    }
    bool isRoot(IUIAutomationElement *element) {
        BOOL same = FALSE;
        return SUCCEEDED(uia->CompareElements(element, root, &same)) && same;
    }
    bool safe(IUIAutomationElement *element, bool focused) {
        BOOL password = FALSE;
        if (FAILED(element->get_CurrentIsPassword(&password))) {
            ++stats.propertyFailures;
            return false;
        }
        if (password) {
            if (focused)
                throw std::runtime_error("当前焦点属于密码控件，已拒绝取词。");
            return false;
        }
        return true;
    }
    std::wstring selected(IUIAutomationElement *element) {
        if (!remaining())
            return {};
        ++stats.nodes;
        Com<IUIAutomationTextPattern> pattern;
        if (FAILED(element->GetCurrentPatternAs(UIA_TextPatternId, IID_IUIAutomationTextPattern,
                                                (void **)pattern.put())) ||
            !pattern) {
            Com<IUIAutomationTextPattern2> newer;
            if (FAILED(element->GetCurrentPatternAs(
                    UIA_TextPattern2Id, IID_IUIAutomationTextPattern2, (void **)newer.put())) ||
                !newer)
                return {};
            if (FAILED(newer->QueryInterface(IID_IUIAutomationTextPattern, (void **)pattern.put())))
                return {};
        }
        ++stats.patterns;
        Com<IUIAutomationTextRangeArray> ranges;
        if (FAILED(pattern->GetSelection(ranges.put())) || !ranges)
            return {};
        int count = 0;
        if (FAILED(ranges->get_Length(&count)) || count < 0 || count > 8)
            return {};
        std::wstring out;
        for (int i = 0; i < count && remaining(); ++i) {
            Com<IUIAutomationTextRange> range;
            if (FAILED(ranges->GetElement(i, range.put())) || !range)
                continue;
            ++stats.ranges;
            int span = 0;
            if (FAILED(range->CompareEndpoints(TextPatternRangeEndpoint_Start, range.p,
                                               TextPatternRangeEndpoint_End, &span)))
                continue;
            if (span == 0) {
                ++stats.emptyRanges;
                continue;
            }
            BSTR raw = nullptr;
            if (SUCCEEDED(range->GetText(4001, &raw)) && raw) {
                std::wstring part(raw, SysStringLen(raw));
                SysFreeString(raw);
                if (part.size() > 4000 || out.size() + part.size() + (out.empty() ? 0 : 1) > 4000)
                    throw std::runtime_error("选区超过 4000 字符，请缩短后重试。");
                if (!part.empty()) {
                    if (!out.empty())
                        out += L"\n";
                    out += part;
                }
            }
        }
        return out;
    }

  public:
    SelectionReader(IUIAutomation *client, HWND window, IUIAutomationElement *boundary,
                    CaptureStats &state)
        : uia(client), target(window), root(boundary), stats(state) {
        if (FAILED(uia->get_RawViewWalker(walker.put())))
            throw std::runtime_error("无法初始化选区查找接口。");
    }
    std::wstring ancestors(IUIAutomationElement *first) {
        if (!first || !remaining())
            return {};
        ++stats.paths;
        Elements path;
        path.add(first);
        bool verified = false;
        for (int depth = 0; depth < 48 && remaining(); ++depth) {
            auto current = path.values.back();
            UIA_HWND native = nullptr;
            if (SUCCEEDED(current->get_CurrentNativeWindowHandle(&native)) && native) {
                if (!withinTarget(target, (HWND)native))
                    return {};
                if ((HWND)native == target) {
                    verified = true;
                    break;
                }
            }
            if (isRoot(current)) {
                verified = true;
                break;
            }
            Com<IUIAutomationElement> parent;
            if (FAILED(walker->GetParentElement(current, parent.put())) || !parent)
                break;
            path.add(parent.p);
        }
        // Never query selections from an unverified/other-window branch.
        if (!verified)
            return {};
        for (auto element : path.values) {
            if (!remaining() || !safe(element, true))
                return {};
        }
        for (auto element : path.values) {
            if (!remaining())
                break;
            CONTROLTYPEID type = 0;
            element->get_CurrentControlType(&type);
            if (!scope && !isRoot(element) &&
                (type == UIA_EditControlTypeId || type == UIA_DocumentControlTypeId)) {
                element->AddRef();
                scope.p = element;
            }
            auto value = selected(element);
            if (!qt::trim(narrow(value)).empty())
                return value;
        }
        return {};
    }
    std::wstring descendants() {
        auto walk = [&](IUIAutomationElement *start) -> std::wstring {
            Elements nodes;
            std::vector<int> depths;
            nodes.add(start);
            depths.push_back(0);
            for (size_t i = 0; i < nodes.values.size() && remaining(); ++i) {
                auto element = nodes.values[i];
                if (!safe(element, false))
                    continue;
                UIA_HWND native = nullptr;
                if (SUCCEEDED(element->get_CurrentNativeWindowHandle(&native)) && native &&
                    !withinTarget(target, (HWND)native))
                    continue;
                BOOL offscreen = FALSE;
                if (SUCCEEDED(element->get_CurrentIsOffscreen(&offscreen)) && offscreen)
                    continue;
                {
                    auto value = selected(element);
                    if (!qt::trim(narrow(value)).empty())
                        return value;
                }
                if (depths[i] >= 16 || nodes.values.size() >= 256)
                    continue;
                Com<IUIAutomationElement> child;
                if (FAILED(walker->GetFirstChildElement(element, child.put())))
                    continue;
                while (child && nodes.values.size() < 256 && remaining()) {
                    nodes.add(child.p);
                    depths.push_back(depths[i] + 1);
                    Com<IUIAutomationElement> sibling;
                    if (FAILED(walker->GetNextSiblingElement(child.p, sibling.put())))
                        break;
                    child.p->Release();
                    child.p = sibling.p;
                    sibling.p = nullptr;
                }
            }
            return {};
        };
        if (scope) {
            auto value = walk(scope.p);
            if (!value.empty())
                return value;
        }
        // Do not read stale selections from another split pane or document. An empty focused
        // scope falls back to the foreground application copy command in smart mode.
        return {};
    }
};
static std::string capture(HWND target, POINT pt, std::string *route = nullptr) {
    if (route)
        *route = "辅助功能选区";
    if (!target || GetForegroundWindow() != target)
        throw std::runtime_error("前台窗口已变化，请重新选择英文。");
    GUITHREADINFO gui{};
    gui.cbSize = sizeof(gui);
    DWORD thread = GetWindowThreadProcessId(target, nullptr);
    GetGUIThreadInfo(thread, &gui);
    CaptureStats stats;
    if (withinTarget(target, gui.hwndFocus)) {
        wchar_t cls[128]{};
        GetClassNameW(gui.hwndFocus, cls, 128);
        stats.nativeClass = narrow(cls);
        auto lower = qt::normalize(stats.nativeClass);
        if (lower == "scintilla" || lower.rfind("windowsforms10.scintilla.", 0) == 0) {
            FocusTarget focused(target);
            auto value = nativeScintilla(focused);
            if (route)
                *route = "Scintilla 原生选区 · 无剪贴板操作";
            return value;
        }
        if ((lower == "edit" || lower.rfind("richedit", 0) == 0) &&
            (GetWindowLongPtrW(gui.hwndFocus, GWL_STYLE) & ES_PASSWORD))
            throw std::runtime_error("当前焦点属于密码输入框，已拒绝取词。");
    }
    HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    if (FAILED(hr))
        throw std::runtime_error("无法初始化 Windows 取词接口。");
    struct CoExit {
        ~CoExit() {
            CoUninitialize();
        }
    } exit;
    Com<IUIAutomation> uia;
    if (FAILED(CoCreateInstance(CLSID_CUIAutomation8, nullptr, CLSCTX_INPROC_SERVER,
                                IID_IUIAutomation, (void **)uia.put())) &&
        FAILED(CoCreateInstance(CLSID_CUIAutomation, nullptr, CLSCTX_INPROC_SERVER,
                                IID_IUIAutomation, (void **)uia.put())))
        throw std::runtime_error("Windows 取词接口不可用。");
    Com<IUIAutomation2> control;
    if (SUCCEEDED(uia->QueryInterface(IID_IUIAutomation2, (void **)control.put()))) {
        control->put_ConnectionTimeout(400);
        control->put_TransactionTimeout(250);
    }
    Com<IUIAutomationElement> root;
    if (FAILED(uia->ElementFromHandle(target, root.put())) || !root)
        throw std::runtime_error("无法定位前台窗口的辅助功能根节点。");
    SelectionReader reader(uia.p, target, root.p, stats);
    Com<IUIAutomationElement> focus;
    std::wstring out;
    if (SUCCEEDED(uia->GetFocusedElement(focus.put())) && focus)
        out = reader.ancestors(focus.p);
    if (out.empty() && withinTarget(target, gui.hwndFocus)) {
        Com<IUIAutomationElement> native;
        if (SUCCEEDED(uia->ElementFromHandle(gui.hwndFocus, native.put())) && native)
            out = reader.ancestors(native.p);
    }
    if (out.empty() && withinTarget(target, WindowFromPoint(pt))) {
        Com<IUIAutomationElement> point;
        if (SUCCEEDED(uia->ElementFromPoint(pt, point.put())) && point)
            out = reader.ancestors(point.p);
    }
    if (out.empty())
        out = reader.descendants();
    GUITHREADINFO after{};
    after.cbSize = sizeof(after);
    GetGUIThreadInfo(thread, &after);
    if (GetForegroundWindow() != target ||
        (gui.hwndFocus && after.hwndFocus && gui.hwndFocus != after.hwndFocus))
        throw std::runtime_error("取词期间窗口或编辑焦点发生变化，已取消以避免读取错误内容。");
    auto value = qt::trim(narrow(out));
    if (value.empty())
        throw qt::NoSelection(
            "没有取得选区，尚未发送翻译请求。\r\n已检查原生选区与辅助功能接口。\r\n\r\n"
            "可选“智能取词”或“通用一键复制”处理 VS Code、Office、网页和 PDF 文字层；"
            "不可拖选的标签可选“指向文字”。扫描件/图片需要 "
            "OCR，本版未提供。\r\n\r\n诊断（不含原文/窗口标题）：" +
            stats.summary());
    if ((!qt::english(value) && !qt::hasHan(value)))
        throw std::runtime_error("选区没有英文内容，请重新选择。");
    if (value.size() > 12000)
        throw std::runtime_error("选区过长，请缩短后重试。");
    return value;
}
static std::string captureCopied(DWORD expected) {
    if (!OpenClipboard(nullptr))
        throw std::runtime_error("剪贴板正被占用。请重新复制后再按快捷键。");
    if (!expected || GetClipboardSequenceNumber() != expected) {
        CloseClipboard();
        throw std::runtime_error("剪贴板在触发后发生变化，请重新复制再翻译。");
    }
    struct Close {
        ~Close() {
            CloseClipboard();
        }
    } close;
    if (!IsClipboardFormatAvailable(CF_UNICODETEXT))
        throw std::runtime_error("当前剪贴板没有文本。请先手动 Ctrl+C 复制英文。");
    HANDLE data = GetClipboardData(CF_UNICODETEXT);
    if (!data)
        throw std::runtime_error("无法取得剪贴板文本，请重新复制。");
    SIZE_T bytes = GlobalSize(data);
    if (bytes < sizeof(char16_t) || bytes % sizeof(char16_t))
        throw std::runtime_error("剪贴板文本格式异常。");
    const auto *memory = (const char16_t *)GlobalLock(data);
    if (!memory)
        throw std::runtime_error("无法读取剪贴板文本。");
    struct Unlock {
        HANDLE h;
        ~Unlock() {
            GlobalUnlock(h);
        }
    } unlock{data};
    auto selected = qt::copiedText(memory, bytes / sizeof(char16_t));
    std::wstring value(selected.begin(), selected.end());
    auto result = qt::trim(narrow(value));
    if ((!qt::english(result) && !qt::hasHan(result)))
        throw std::runtime_error("剪贴板没有英文内容，请重新复制。");
    return result;
}
static std::string captureOneKeyCopy(HWND window, std::string &route) {
    FocusTarget focused(window);
    // Scintilla is handled without touching the clipboard, even in compatibility mode.
    if (focused.isScintilla()) {
        auto value = nativeScintilla(focused);
        route = "Scintilla 原生选区 · 无剪贴板操作";
        return value;
    }
    if (!focused.isTextEdit())
        throw std::runtime_error("一键复制仅支持已识别的 Edit/RichEdit "
                                 "控件。当前窗口未发送复制命令；请选原生取词或手动复制模式。");
    DWORD begin = 0, end = 0;
    focused.verify();
    focused.query(EM_GETSEL, (WPARAM)&begin, (LPARAM)&end);
    if (begin == end)
        throw std::runtime_error("当前编辑框没有选中文字；未发送复制命令。");
    if (end < begin || end - begin > 4000)
        throw std::runtime_error("选区过长，请缩短后重试。");
    DWORD before = GetClipboardSequenceNumber();
    focused.verify();
    // WM_COPY is a standard edit command, NOT keyboard input, cut, paste, or selection mutation.
    focused.query(WM_COPY, 0, 0, 750);
    focused.verify();
    DWORD after = GetClipboardSequenceNumber(), ownerPid = 0;
    HWND owner = GetClipboardOwner();
    if (owner)
        GetWindowThreadProcessId(owner, &ownerPid);
    if (!qt::freshCopy(before, after, focused.pid, ownerPid))
        throw std::runtime_error(
            "没有确认来自目标编辑器的新复制文本，已拒绝使用旧剪贴板内容。可改用手动复制模式。");
    DWORD nextBegin = 0, nextEnd = 0;
    focused.query(EM_GETSEL, (WPARAM)&nextBegin, (LPARAM)&nextEnd);
    if (nextBegin != begin || nextEnd != end)
        throw std::runtime_error("复制期间选区发生变化，已取消。");
    auto value = captureCopied(after);
    focused.verify();
    route = "一键复制兼容 · 当前剪贴板已更新";
    return value;
}
#include "universal_capture.hpp"
class ApiClient {
    Http session;
    Http conn;

  public:
    ApiClient()
        : session(WinHttpOpen(L"QuietTranslate/2.1", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                              WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0)),
          conn(WinHttpConnect(session, L"api.mymemory.translated.net", INTERNET_DEFAULT_HTTPS_PORT,
                              0)) {
        if (!WinHttpSetTimeouts(session, 4000, 4000, 6000, 6000))
            throw std::runtime_error("无法配置网络等待时限。");
    }
    std::string request(const std::string &source) {
        auto path = wide("/get?q=" + qt::url(source) + "&langpair=en%7Czh-CN");
        Http req(WinHttpOpenRequest(conn, L"GET", path.c_str(), nullptr, WINHTTP_NO_REFERER,
                                    WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE));
        if (!WinHttpSetTimeouts(req, 4000, 4000, 6000, 6000))
            throw std::runtime_error("无法配置请求等待时限。");
        DWORD redirect = WINHTTP_OPTION_REDIRECT_POLICY_NEVER;
        if (!WinHttpSetOption(req, WINHTTP_OPTION_REDIRECT_POLICY, &redirect, sizeof(redirect)))
            throw std::runtime_error("无法禁用网络重定向。");
        DWORD disable = WINHTTP_DISABLE_COOKIES | WINHTTP_DISABLE_AUTHENTICATION;
        if (!WinHttpSetOption(req, WINHTTP_OPTION_DISABLE_FEATURE, &disable, sizeof(disable)))
            throw std::runtime_error("无法应用网络安全选项。");
        if (!WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0,
                                0, 0) ||
            !WinHttpReceiveResponse(req, nullptr))
            throw std::runtime_error("联网翻译失败或超时。请检查网络后重试。");
        DWORD status = 0, size = sizeof(status);
        if (!WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                                 WINHTTP_HEADER_NAME_BY_INDEX, &status, &size,
                                 WINHTTP_NO_HEADER_INDEX) ||
            status != 200)
            throw std::runtime_error("翻译服务暂不可用或请求受限。请稍后重试。");
        std::string response;
        char buf[4096];
        DWORD n = 0;
        for (;;) {
            if (!WinHttpReadData(req, buf, sizeof(buf), &n))
                throw std::runtime_error("读取翻译响应失败。");
            if (!n)
                break;
            if (response.size() + n > 262144)
                throw std::runtime_error("翻译服务返回内容超出安全限制。");
            response.append(buf, n);
        }
        return qt::html(qt::translation(response));
    }
};
static bool writeAll(HANDLE h, const void *p, DWORD n) {
    auto b = (const char *)p;
    while (n) {
        DWORD w = 0;
        if (!WriteFile(h, b, n, &w, nullptr) || !w)
            return false;
        b += w;
        n -= w;
    }
    return true;
}
static void frame(uint32_t type, const std::string &s) {
    uint32_t head[2] = {type, (uint32_t)s.size()};
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    writeAll(h, head, 8);
    writeAll(h, s.data(), (DWORD)s.size());
}
static int worker(int argc, wchar_t **argv) {
    try {
        bool isManual = std::wstring(argv[1]) == L"--translate";
        bool net = false;
        std::string s;
        if (isManual) {
            if (argc != 3)
                return 2;
            net = wcstol(argv[2], nullptr, 10) == 1;
            char b[4096];
            DWORD n;
            while (ReadFile(GetStdHandle(STD_INPUT_HANDLE), b, sizeof(b), &n, nullptr) && n) {
                s.append(b, n);
                if (s.size() > 12000)
                    throw std::runtime_error("原文过长：请缩短后重试。");
            }
            s = qt::trim(s);
            wide(s);
            if (s.empty() || !qt::english(s))
                throw std::runtime_error("请粘贴需要翻译的英文单词或句子。");
        } else {
            if (argc != 6)
                return 2;
            HWND target = (HWND)(uintptr_t)_wcstoui64(argv[2], nullptr, 10);
            POINT pt{(LONG)wcstol(argv[3], nullptr, 10), (LONG)wcstol(argv[4], nullptr, 10)};
            net = wcstol(argv[5], nullptr, 10) == 1;
            s = capture(target, pt);
        }
        frame(1, s);
        if (!net) {
            auto local = qt::lookup(s);
            frame(2, local.empty() ? "离线词典未收录该词条。请在设置中开启联网翻译。"
                                   : "【离线技术词条】\r\n" + local);
            return 0;
        }
        ApiClient api;
        qt::OnlineEngine engine;
        auto translated = engine.translate(
            s, false, [&](const std::string &part) { return api.request(part); },
            [] { return GetTickCount64(); },
            [](const qt::TranslationProgress &progress) { frame(4, progress.text); });
        frame(2, translated.text);
        return 0;
    } catch (const std::exception &e) {
        frame(3, e.what());
        return 1;
    } catch (...) {
        frame(3, "任务未能完成。请缩短选区重试。");
        return 1;
    }
}

static bool readExact(HANDLE h, void *target, DWORD count, bool allowEof = false) {
    char *p = (char *)target;
    DWORD done = 0;
    while (done < count) {
        DWORD n = 0;
        if (!ReadFile(h, p + done, count - done, &n, nullptr) || !n) {
            if (allowEof && done == 0)
                return false;
            throw std::runtime_error("输入管道意外结束。");
        }
        done += n;
    }
    return true;
}
#include "api_runtime.hpp"
#include "learning_storage.hpp"
#include "billing_runtime.hpp"
static std::string dictionaryRequest(const std::string &word) {
    Http session(WinHttpOpen(L"QuietTranslate/2.1", WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                             WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0));
    Http conn(WinHttpConnect(session, L"api.dictionaryapi.dev", INTERNET_DEFAULT_HTTPS_PORT, 0));
    auto path = wide("/api/v2/entries/en/" + qt::url(word));
    Http req(WinHttpOpenRequest(conn, L"GET", path.c_str(), nullptr, WINHTTP_NO_REFERER,
                                WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE));
    DWORD redirect = WINHTTP_OPTION_REDIRECT_POLICY_NEVER,
          disable = WINHTTP_DISABLE_COOKIES | WINHTTP_DISABLE_AUTHENTICATION;
    if (!WinHttpSetTimeouts(req, 4000, 4000, 6000, 6000) ||
        !WinHttpSetOption(req, WINHTTP_OPTION_REDIRECT_POLICY, &redirect, sizeof(redirect)) ||
        !WinHttpSetOption(req, WINHTTP_OPTION_DISABLE_FEATURE, &disable, sizeof(disable)))
        throw std::runtime_error("无法配置词典网络安全选项。");
    if (!WinHttpSendRequest(req, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0,
                            0) ||
        !WinHttpReceiveResponse(req, nullptr))
        throw std::runtime_error("在线词典连接失败或超时。整句翻译不受影响，可稍后重试。");
    DWORD statusCode = 0, n = sizeof(statusCode);
    if (!WinHttpQueryHeaders(req, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                             WINHTTP_HEADER_NAME_BY_INDEX, &statusCode, &n,
                             WINHTTP_NO_HEADER_INDEX))
        throw std::runtime_error("无法读取词典响应状态。");
    if (statusCode == 404)
        throw std::runtime_error(
            "通用词典未收录此词。可尝试单词原形；芯片名、缩写和技术标识符不一定有词条。");
    if (statusCode != 200)
        throw std::runtime_error("词典服务暂不可用或请求受限。");
    std::string body;
    char buffer[4096];
    for (;;) {
        DWORD count = 0;
        if (!WinHttpReadData(req, buffer, sizeof(buffer), &count))
            throw std::runtime_error("词典响应读取失败。");
        if (!count)
            break;
        if (body.size() + count > 262144)
            throw std::runtime_error("词典响应超过安全上限。");
        body.append(buffer, count);
    }
    return body;
}
static int studyWorker(bool mock, bool useApi = false) {
    try {
        qt::ApiConfig selectedApi;
        if (useApi)
            selectedApi = readApiInput();
        uint32_t h[2];
        readExact(GetStdHandle(STD_INPUT_HANDLE), h, 8);
        if (h[0] != 10 || h[1] > 40)
            throw std::runtime_error("词语请求无效。");
        std::string word(h[1], 0);
        if (h[1])
            readExact(GetStdHandle(STD_INPUT_HANDLE), word.data(), h[1]);
        if (!qt::dictionaryWord(word))
            throw std::runtime_error(
                "在线词典只接受不超过 40 个字符的英文单词，可含内部连字符或撇号。");
        auto response =
            mock
                ? std::string(
                      R"([{"word":"require","phonetic":"rɪˈkwaɪə","meanings":[{"partOfSpeech":"verb","definitions":[{"definition":"To need something.","example":"The driver requires a stable clock."}]}],"sourceUrls":["https://example.invalid/word"],"license":{"name":"Test fixture"}}])")
                : dictionaryRequest(word);
        auto entry = qt::parseDictionary(response, word);
        auto report = entry.report();
        wide(report);
        frame(4, report);
        std::string chinese;
        if (mock)
            chinese = "需要某事物。驱动程序需要稳定的时钟。";
        else if (useApi) {
            ModelApiClient api(selectedApi);
            chinese = api.translate(entry.translationInput(), [](const std::string &) {});
        } else {
            ApiClient api;
            qt::OnlineEngine engine;
            auto done = engine.translate(
                entry.translationInput(), false,
                [&](const std::string &part) { return api.request(part); },
                [] { return GetTickCount64(); }, [](const qt::TranslationProgress &) {});
            chinese = done.text;
        }
        frame(2, report + "\r\n中文参考（" +
                     (useApi ? selectedApi.label() : std::string("MyMemory")) +
                     "，对应上面的释义/例句）\r\n" + chinese +
                     "\r\n\r\n通用词典不保证专业词义完整；词性和例句不一定匹配原句语境。");
        return 0;
    } catch (const std::exception &e) {
        frame(3, e.what());
        return 1;
    }
}
static int service(bool mock, bool useCache) {
    try {
        qt::OnlineEngine engine;
        std::unique_ptr<ApiClient> api;
        HANDLE in = GetStdHandle(STD_INPUT_HANDLE);
        for (;;) {
            uint32_t header[2];
            if (!readExact(in, header, 8, true))
                return 0;
            if (header[0] != 10 || header[1] > 4000)
                throw std::runtime_error("翻译请求协议无效。");
            std::string source(header[1], 0);
            if (header[1])
                readExact(in, source.data(), header[1]);
            try {
                wide(source);
                auto translated = engine.translate(
                    source, useCache,
                    [&](const std::string &part) {
                        if (mock) {
                            if (part.find("FAIL") != std::string::npos)
                                throw std::runtime_error("mock request failed");
                            return std::string("stub:") + part;
                        }
                        if (!api)
                            api = std::make_unique<ApiClient>();
                        return api->request(part);
                    },
                    [] { return GetTickCount64(); },
                    [](const qt::TranslationProgress &progress) {
                        frame(4, progress.text);
                        frame(5, "已完成 " + std::to_string(progress.completed) + "/" +
                                     std::to_string(progress.total) + " 段 · 网络 " +
                                     std::to_string(progress.requests) + " · 缓存 " +
                                     std::to_string(progress.hits));
                    });
                frame(2, translated.text);
            } catch (const std::exception &e) {
                api.reset();
                frame(3, e.what());
            }
        }
    } catch (const std::exception &e) {
        frame(3, e.what());
        return 1;
    }
}
static int captureOnly(int argc, wchar_t **argv) {
    try {
        if (argc != 5)
            return 2;
        HWND target = (HWND)(uintptr_t)_wcstoui64(argv[2], nullptr, 10);
        POINT pt{(LONG)wcstol(argv[3], nullptr, 10), (LONG)wcstol(argv[4], nullptr, 10)};
        std::string route;
        auto value = capture(target, pt, &route);
        frame(6, route);
        frame(1, value);
        return 0;
    } catch (const std::exception &e) {
        frame(3, e.what());
        return 1;
    }
}
struct Worker {
    HANDLE process = nullptr, read = nullptr, input = nullptr, group = nullptr;
    qt::FrameDecoder decoder;
    void close() {
        if (group)
            CloseHandle(group);
        else if (process)
            TerminateProcess(process, 1);
        if (process)
            CloseHandle(process);
        if (read)
            CloseHandle(read);
        if (input)
            CloseHandle(input);
        process = read = input = group = nullptr;
        decoder = qt::FrameDecoder{};
    }
    bool running() const {
        return process && WaitForSingleObject(process, 0) == WAIT_TIMEOUT;
    }
    bool send(uint32_t type, const std::string &value) {
        uint32_t head[2] = {type, (uint32_t)value.size()};
        return writeAll(input, head, 8) && writeAll(input, value.data(), (DWORD)value.size());
    }
};
static Worker captureTask, networkTask, studyTask, apiToolTask;
static void stopApiTool();
static qt::MemoryCache results;
static qt::MemoryCache studyCache(64, 256 * 1024);
static void armCacheExpiry() {
    KillTimer(host, 3);
    auto at = results.nextExpiry();
    auto studyAt = studyCache.nextExpiry();
    if (studyAt && (!at || studyAt < at))
        at = studyAt;
    if (at) {
        auto now = GetTickCount64();
        SetTimer(host, 3, (UINT)(at > now ? at - now : 1), nullptr);
    }
}
enum class Phase { Idle, Capture, Network };
struct Job {
    Phase phase = Phase::Idle;
    std::string source, partial, captureRoute, learningScope;
    qt::MixedPlan mixed;
    ULONGLONG started = 0, sourceAt = 0, firstAt = 0, deadline = 0;
    bool ocr = false;
    int ocrConfidence = -1;
};
static Job job;
static void finishJob(bool cancel) {
    billingEnd(0, cancel ? qt::BillState::Cancelled : qt::BillState::Success);
    KillTimer(host, 1);
    captureTask.close();
    restoreOcrWindows();
    if (cancel && job.phase == Phase::Network)
        networkTask.close();
    job = Job{};
    if (networkTask.process)
        SetTimer(host, 2, 60000, nullptr);
}
static void stopJob() {
    finishJob(true);
}
static void forgetCache() {
    cancelOcrSelection();
    stopApiTool();
    stopJob();
    KillTimer(host, 2);
    networkTask.close();
    results.clear();
    studyCache.clear();
    stopStudy();
    KillTimer(host, 3);
}
static void status(const wchar_t *s) {
    SetWindowTextW(statusLabel, s);
}
static int scale(int n) {
    UINT dpi = GetDpiForWindow(popup ? popup : host);
    return MulDiv(n, dpi ? dpi : 96, 96);
}
static HWND child(HWND parent, const wchar_t *cls, const wchar_t *label, DWORD style, int id) {
    HWND h = CreateWindowExW(wcscmp(cls, L"EDIT") == 0 ? WS_EX_CLIENTEDGE : 0, cls, label,
                             WS_CHILD | WS_VISIBLE | style, 0, 0, 0, 0, parent, (HMENU)(INT_PTR)id,
                             instance, nullptr);
    SendMessageW(h, WM_SETFONT, (WPARAM)font, TRUE);
    return h;
}
static bool ensureToolWindow(HWND &window, const wchar_t *name, const wchar_t *title, int width,
                             int height, bool resize = false) {
    if (window)
        return true;
    int dpi = GetDpiForWindow(host);
    window = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_TOPMOST, name, title,
                             WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | (resize ? WS_THICKFRAME : 0),
                             160, 80, MulDiv(width, dpi, 96), MulDiv(height, dpi, 96), host,
                             nullptr, instance, nullptr);
    if (!window)
        MessageBoxW(popup, L"无法创建窗口。", APP, MB_OK | MB_ICONERROR);
    return window != nullptr;
}
static void place(HWND h, int x, int y, int w, int height) {
    MoveWindow(h, scale(x), scale(y), scale(w), scale(height), TRUE);
}
static void showPopup(bool activate) {
    POINT p;
    GetCursorPos(&p);
    MONITORINFO m{};
    m.cbSize = sizeof(m);
    GetMonitorInfoW(MonitorFromPoint(p, MONITOR_DEFAULTTONEAREST), &m);
    RECT r;
    GetWindowRect(popup, &r);
    int width = r.right - r.left, height = r.bottom - r.top;
    int x = std::max((int)m.rcWork.left, std::min((int)p.x + 18, (int)m.rcWork.right - width));
    int y = std::max((int)m.rcWork.top, std::min((int)p.y + 20, (int)m.rcWork.bottom - height));
    SetWindowPos(popup, HWND_TOPMOST, x, y, 0, 0, SWP_NOSIZE | SWP_NOACTIVATE);
    ShowWindow(popup, activate ? SW_SHOW : SW_SHOWNOACTIVATE);
    if (activate) {
        SetForegroundWindow(popup);
        SetFocus(sourceBox);
    }
}
static void result(const wchar_t *s) {
    SetWindowTextW(resultBox, s);
}
// The UI owns only process handles and bounded in-memory text. Network waits occur in a worker.
static bool spawn(Worker &worker, const std::wstring &args, bool keepInput,
                  bool ocrSibling = false) {
    worker.close();
    wchar_t exe[32768];
    DWORD executableLength = GetModuleFileNameW(nullptr, exe, 32768);
    if (!executableLength || executableLength >= 32768)
        return false;
    std::wstring executable(exe, executableLength);
    if (ocrSibling) {
        auto slash = executable.find_last_of(L"\\/");
        if (slash == std::wstring::npos)
            return false;
        executable.resize(slash + 1);
        executable += L"QuietTranslate.OCR.exe";
    }
    std::wstring cmd = L"\"" + executable + L"\" " + args;
    SECURITY_ATTRIBUTES sa{sizeof(sa), nullptr, TRUE};
    HANDLE rd = nullptr, wr = nullptr, inrd = nullptr, inwr = nullptr;
    if (!CreatePipe(&rd, &wr, &sa, 65536))
        return false;
    Handle read(rd), write(wr);
    if (!CreatePipe(&inrd, &inwr, &sa, 65536))
        return false;
    Handle inread(inrd), inwrite(inwr);
    Handle errorSink(ocrSibling
                         ? CreateFileW(L"NUL", GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                       &sa, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr)
                         : nullptr);
    if (ocrSibling && errorSink.h == INVALID_HANDLE_VALUE)
        return false;
    if (!SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0) ||
        !SetHandleInformation(inwr, HANDLE_FLAG_INHERIT, 0))
        return false;
    SIZE_T bytes = 0;
    InitializeProcThreadAttributeList(nullptr, 1, 0, &bytes);
    std::vector<char> attr(bytes);
    auto attrs = (LPPROC_THREAD_ATTRIBUTE_LIST)attr.data();
    if (!InitializeProcThreadAttributeList(attrs, 1, 0, &bytes))
        return false;
    struct AttrExit {
        LPPROC_THREAD_ATTRIBUTE_LIST p;
        ~AttrExit() {
            DeleteProcThreadAttributeList(p);
        }
    } cleanup{attrs};
    HANDLE inherit[] = {wr, inrd, errorSink.h};
    if (!UpdateProcThreadAttribute(attrs, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST, inherit,
                                   sizeof(HANDLE) * (ocrSibling ? 3 : 2), nullptr, nullptr))
        return false;
    STARTUPINFOEXW si{};
    si.StartupInfo.cb = sizeof(si);
    si.StartupInfo.dwFlags = STARTF_USESTDHANDLES;
    si.StartupInfo.hStdOutput = wr;
    si.StartupInfo.hStdError = ocrSibling ? errorSink.h : wr;
    si.StartupInfo.hStdInput = inrd;
    si.lpAttributeList = attrs;
    Handle group(CreateJobObjectW(nullptr, nullptr));
    JOBOBJECT_EXTENDED_LIMIT_INFORMATION limits{};
    limits.BasicLimitInformation.LimitFlags =
        JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE | JOB_OBJECT_LIMIT_ACTIVE_PROCESS;
    limits.BasicLimitInformation.ActiveProcessLimit = 1;
    if (!group.h || !SetInformationJobObject(group.h, JobObjectExtendedLimitInformation, &limits,
                                             sizeof(limits)))
        return false;
    PROCESS_INFORMATION pi{};
    if (!CreateProcessW(executable.c_str(), cmd.data(), nullptr, nullptr, TRUE,
                        CREATE_NO_WINDOW | CREATE_SUSPENDED | EXTENDED_STARTUPINFO_PRESENT, nullptr,
                        nullptr, &si.StartupInfo, &pi))
        return false;
    Handle thread(pi.hThread);
    if (!AssignProcessToJobObject(group.h, pi.hProcess) || ResumeThread(thread.h) == (DWORD)-1) {
        TerminateProcess(pi.hProcess, 1);
        CloseHandle(pi.hProcess);
        return false;
    }
    worker.process = pi.hProcess;
    worker.read = read.h;
    read.h = nullptr;
    worker.group = group.h;
    group.h = nullptr;
    if (keepInput) {
        worker.input = inwrite.h;
        inwrite.h = nullptr;
    }
    return true;
}
static void stopStudy() {
    billingEnd(1, qt::BillState::Cancelled);
    KillTimer(host, 4);
    studyTask.close();
    studyActive = false;
    studyPartial.clear();
}
static std::string selectedStudyTerm() {
    int index = (int)SendMessageW(studyCombo, CB_GETCURSEL, 0, 0);
    if (index >= 0 && (size_t)index < studyKeywords.size()) {
        const auto &candidate = studyKeywords[index];
        auto label = candidate.surface == candidate.term
                         ? candidate.term
                         : candidate.surface + " → " + candidate.term;
        if (qt::trim(narrow(text(studyCombo))) == label)
            return candidate.term;
    }
    return qt::baseForm(qt::trim(narrow(text(studyCombo))));
}
static void selectStudyWord() {
    stopStudy();
    try {
        auto term = selectedStudyTerm();
        studyPrefix.clear();
        int index = (int)SendMessageW(studyCombo, CB_GETCURSEL, 0, 0);
        if (index >= 0 && (size_t)index < studyKeywords.size() && studyKeywords[index].term == term)
            studyPrefix = "原文形式：" + studyKeywords[index].surface + " → " + term + "\r\n\r\n";
        auto card = qt::findStudyCard(term);
        if (card) {
            studyPrefix += qt::studyText(*card);
            SetWindowTextW(studyOutput, wide(studyPrefix).c_str());
        } else {
            auto gloss = qt::lookup(term);
            if (!gloss.empty())
                studyPrefix += term + "\r\n技术含义参考：\r\n" + gloss;
            auto body = studyPrefix + (gloss.empty() ? term + "\r\n\r\n暂无本地用法。" : "");
            SetWindowTextW(studyOutput, wide(body).c_str());
        }
        SetWindowTextW(studyStatus, L"本地用法");
    } catch (...) {
        SetWindowTextW(studyOutput, L"请从列表选择词语，或输入单词后点击查看。");
    }
}
static void populateStudy() {
    SendMessageW(studyCombo, CB_RESETCONTENT, 0, 0);
    for (const auto &candidate : studyKeywords) {
        auto label = candidate.surface == candidate.term
                         ? candidate.term
                         : candidate.surface + " → " + candidate.term;
        SendMessageW(studyCombo, CB_ADDSTRING, 0, (LPARAM)wide(label).c_str());
    }
    if (!studyKeywords.empty())
        SendMessageW(studyCombo, CB_SETCURSEL, 0, 0);
    else
        SetWindowTextW(studyCombo, L"");
    selectStudyWord();
}
static void resetStudy() {
    stopStudy();
    studyKeywords.clear();
    studyPrefix.clear();
    if (studyWindow) {
        ShowWindow(studyWindow, SW_HIDE);
        SetWindowTextW(studyOutput, L"");
        SendMessageW(studyCombo, CB_RESETCONTENT, 0, 0);
    }
    if (keywordsLabel)
        SetWindowTextW(keywordsLabel, L"关键词");
}
static void setStudySource(const std::string &source) {
    stopStudy();
    studyKeywords = qt::keywords(source);
    std::string label = "关键词：";
    for (size_t i = 0; i < studyKeywords.size(); ++i) {
        if (i)
            label += " · ";
        label += studyKeywords[i].term;
    }
    if (studyKeywords.empty())
        label += "—";
    SetWindowTextW(keywordsLabel, wide(label).c_str());
    if (IsWindowVisible(studyWindow))
        populateStudy();
}
static void showStudy() {
    if (!ensureToolWindow(studyWindow, L"QuietTranslate.Study", L"词语学习", 680, 612, true))
        return;
    populateStudy();
    ShowWindow(studyWindow, SW_SHOW);
    SetForegroundWindow(studyWindow);
    SetFocus(studyCombo);
}
static void queryStudyWord() {
    selectStudyWord();
    try {
        auto term = selectedStudyTerm();
        if (!qt::dictionaryWord(term))
            throw std::runtime_error(
                "通用在线词典仅查询英文单词。短语请先查看内置学习卡，或分开查询其中的单词。");
        if (!online)
            throw std::runtime_error(
                "请先在设置中开启联网翻译。该操作会访问在线词典与当前翻译服务。");
        if (!dictionaryAllowed) {
            if (MessageBoxW(studyWindow,
                            L"允许查询在线词典，并用当前翻译服务翻译释义和例句？可能产生费用。",
                            APP, MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2) != IDYES)
                return;
            dictionaryAllowed = true;
            if (!config.empty())
                WritePrivateProfileStringW(L"Settings", L"DictionaryAllowed", L"1", config.c_str());
        }
        std::string cached;
        if (cacheEnabled && studyCache.get(term, GetTickCount64(), cached)) {
            SetWindowTextW(studyOutput,
                           wide(studyPrefix + "\r\n\r\n【在线词典补充】\r\n" + cached).c_str());
            SetWindowTextW(studyStatus, L"词典内存缓存命中 · 本次未发送网络请求");
            billingLastStudy = "本地缓存 · 本次新增 Token 0 / 费用 0";
            rememberStudy(term, cached, learningScopeKey());
            return;
        }
        if (!spawn(studyTask, apiEnabled ? L"--study-api" : L"--study", true))
            throw std::runtime_error("无法启动词语查询任务。");
        if (apiEnabled && !studyTask.send(20, apiConfig.serialize()))
            throw std::runtime_error("无法提交 API 配置。");
        if (apiEnabled)
            billingBegin(1, apiConfig);
        if (!studyTask.send(10, term)) {
            billingEnd(1, qt::BillState::NotSent);
            throw std::runtime_error("无法提交词语查询。");
        }
        studyActive = true;
        studyLearningScope = learningScopeKey();
        studyDeadline = GetTickCount64() + 35000;
        SetTimer(host, 4, 30, nullptr);
        SetWindowTextW(studyStatus, L"正在单独加载词典 · 整句翻译继续运行");
    } catch (const std::exception &e) {
        stopStudy();
        SetWindowTextW(studyOutput, wide(studyPrefix + "\r\n\r\n【提示】\r\n" + e.what()).c_str());
        SetWindowTextW(studyStatus, L"词典查询未开始或未能提交 · 提示见上方");
    }
}
static void pollStudy() {
    try {
        DWORD available = 0;
        while (PeekNamedPipe(studyTask.read, nullptr, 0, nullptr, &available, nullptr) &&
               available) {
            char buffer[4096];
            DWORD n = 0;
            if (!ReadFile(studyTask.read, buffer, std::min<DWORD>(available, sizeof(buffer)), &n,
                          nullptr) ||
                !n)
                break;
            studyTask.decoder.feed(buffer, n);
            qt::Frame f;
            while (studyTask.decoder.pop(f)) {
                if (billingFrame(1, f))
                    continue;
                wide(f.text);
                if (f.type == 4) {
                    studyPartial = f.text;
                    SetWindowTextW(
                        studyOutput,
                        wide(studyPrefix + "\r\n\r\n【在线词典补充】\r\n" + f.text).c_str());
                    SetWindowTextW(studyStatus, L"词典已返回 · 正在翻译释义与例句");
                } else if (f.type == 2) {
                    billingEnd(1, qt::BillState::Success);
                    if (cacheEnabled)
                        studyCache.put(selectedStudyTerm(), f.text, GetTickCount64());
                    armCacheExpiry();
                    SetWindowTextW(
                        studyOutput,
                        wide(studyPrefix + "\r\n\r\n【在线词典补充】\r\n" + f.text).c_str());
                    SetWindowTextW(studyStatus,
                                   wide(apiEnabled
                                            ? billingLastStudy
                                            : "完成 · 英文来自词典；中文参考由所选翻译服务提供")
                                       .c_str());
                    rememberStudy(selectedStudyTerm(), f.text, studyLearningScope);
                    stopStudy();
                    return;
                } else if (f.type == 3) {
                    billingEnd(1, qt::BillState::Failed);
                    throw std::runtime_error(f.text);
                } else
                    throw std::runtime_error("词典响应协议无效。");
            }
        }
        if (!studyTask.running()) {
            DWORD n = 0;
            if (PeekNamedPipe(studyTask.read, nullptr, 0, nullptr, &n, nullptr) && n)
                return;
            throw std::runtime_error("词语查询已结束，但未得到完整结果。");
        }
        if (GetTickCount64() > studyDeadline)
            throw std::runtime_error("词语查询超时，已取消。整句译文不受影响。");
    } catch (const std::exception &e) {
        auto body =
            studyPrefix +
            (studyPartial.empty() ? "" : "\r\n\r\n【词典返回，中文尚未完成】\r\n" + studyPartial) +
            "\r\n\r\n" + e.what();
        stopStudy();
        SetWindowTextW(studyOutput, wide(body).c_str());
        SetWindowTextW(studyStatus, L"词典查询未完成");
    }
}
static std::wstring timing(bool cached = false) {
    ULONGLONG now = GetTickCount64();
    auto total = std::to_wstring(now - job.started);
    if (cached)
        return L"内存缓存命中 · 总计 " + total + L" ms · 未发送请求";
    auto captureMs = std::to_wstring(job.sourceAt - job.started);
    auto netMs = std::to_wstring(now - job.sourceAt);
    auto summary = L"取词 " + captureMs + L" ms · 翻译 " + netMs + L" ms · 总计 " + total + L" ms";
    if (!job.captureRoute.empty())
        summary = wide(job.captureRoute) + L" · " + summary;
    return summary;
}
static void dispatchSource(const std::string &source) {
    job.source = qt::trim(source);
    job.sourceAt = GetTickCount64();
    job.mixed = qt::planMixed(job.source, apiEnabled && apiConfig.smartMixed, apiConfig.keepTerms);
    if (job.source.empty() || (!qt::english(job.source) && job.mixed.mode != qt::MixedMode::Local))
        throw std::runtime_error("请选中或粘贴需要翻译的英文。");
    SetWindowTextW(sourceBox, wide(job.source).c_str());
    setStudySource(job.source);
    captureTask.close();
    if (capturePreviewOnly) {
        result(wide("取词成功\r\n路径：" + job.captureRoute + "\r\n\r\n").c_str());
        status(L"取词测试");
        finishJob(false);
        return;
    }
    if (job.source.size() > 4000)
        throw std::runtime_error("联网翻译最多 4000 UTF-8 字节，请缩短选区。");
    if (job.mixed.mode == qt::MixedMode::Local ||
        (apiEnabled && apiConfig.keepTerms && qt::standaloneTechnicalName(job.source))) {
        setBillingMain("本地保留 · Token 0 · 费用 0");
        result(wide(job.source).c_str());
        status(L"已保留原文");
        if (qt::english(job.source))
            rememberTranslation(job.source, job.source, job.learningScope);
        finishJob(false);
        return;
    }
    if (!online) {
        setBillingMain("");
        auto local = qt::lookup(job.source);
        result(wide(local.empty() ? "尚未开启联网翻译。请在设置中开启联网翻译或配置自己的 API。"
                                  : "【离线技术词条】\r\n" + local)
                   .c_str());
        status(L"离线模式 · 未发送请求");
        finishJob(false);
        return;
    }
    if (apiEnabled)
        apiConfig.validate();
    std::string cached;
    if (cacheEnabled && results.get(job.source, GetTickCount64(), cached)) {
        setBillingMain("缓存 · Token 0 · 费用 0");
        result(wide(cached).c_str());
        status(timing(true).c_str());
        rememberTranslation(job.source, cached, job.learningScope);
        finishJob(false);
        return;
    }
    if (!networkTask.running()) {
        std::wstring args = apiEnabled ? L"--api-service " : L"--service ";
        args += cacheEnabled ? L"1" : L"0";
        if (!spawn(networkTask, args, true))
            throw std::runtime_error("无法启动联网翻译任务。");
        if (apiEnabled && !networkTask.send(20, apiConfig.serialize()))
            throw std::runtime_error("无法提交 API 配置。");
    }
    KillTimer(host, 2);
    job.phase = Phase::Network;
    job.deadline = GetTickCount64() + 35000;
    if (apiEnabled)
        billingBegin(0, apiConfig);
    else
        setBillingMain("本次使用 MyMemory · 不计入自带 Key 的 Token 账本");
    if (!networkTask.send(10, job.mixed.request)) {
        billingEnd(0, qt::BillState::NotSent);
        throw std::runtime_error("无法提交翻译请求，请重试。");
    }
    status(wide("正在翻译 · " + engineLabel() + (apiEnabled ? " · 只使用当前服务" : " · 分段显示"))
               .c_str());
}
static void startJob(bool isManual) {
    cancelOcrSelection();
    clearLearningTranslation();
    resetStudy();
    stopJob();
    setBillingMain("");
    KillTimer(host, 2);
    if (paused && !isManual)
        return;
    job.started = GetTickCount64();
    job.learningScope = learningScopeKey();
    try {
        if (isManual) {
            job.captureRoute = "手动输入";
            auto input = narrow(text(sourceBox));
            result(L"正在处理…");
            showPopup(true);
            dispatchSource(input);
        } else {
            std::wstring args;
            if (captureMode == 1 && !universalCopyAllowed)
                throw std::runtime_error("通用复制尚未启用。请在设置中选择“通用一键复制”，保存并确"
                                         "认新行为；此后只需一次翻译快捷键。");
            if (captureMode == 2) {
                DWORD sequence = GetClipboardSequenceNumber();
                if (!copiedSequence.accept(sequence))
                    throw std::runtime_error(
                        "兼容模式需要先重新 Ctrl+C "
                        "复制英文，再按翻译快捷键。程序不会自动复制或使用上一次已读的剪贴板内容。");
                args = L"--copied-only " + std::to_wstring(sequence);
            }
            if (captureMode != 2) {
                HWND target = GetForegroundWindow();
                DWORD pid = 0;
                GetWindowThreadProcessId(target, &pid);
                if (pid == GetCurrentProcessId())
                    throw std::runtime_error("请先在其他窗口中选中英文。");
                POINT pt;
                GetCursorPos(&pt);
                if (captureMode == 1)
                    args = L"--capture-universal " + std::to_wstring((uintptr_t)target) + L" " +
                           std::to_wstring(shortcuts[keyIndex].vk);
                else
                    args = (captureMode == 3   ? L"--point-only "
                            : captureMode == 4 ? L"--capture-only "
                                               : L"--capture-smart ") +
                           std::to_wstring((uintptr_t)target) + L" " + std::to_wstring(pt.x) +
                           L" " + std::to_wstring(pt.y) +
                           (captureMode == 0 ? L" " + std::to_wstring(shortcuts[keyIndex].vk) +
                                                   L" " + (universalCopyAllowed ? L"1" : L"0")
                                             : L"");
            }
            ShowWindow(popup, SW_HIDE);
            if (!spawn(captureTask, args, false))
                throw std::runtime_error("无法启动取词任务。");
            job.phase = Phase::Capture;
            job.deadline = GetTickCount64() + (captureMode == 2                       ? 3000
                                               : captureMode == 0 || captureMode == 1 ? 8000
                                                                                      : 5000);
            manual = false;
            SendMessageW(sourceBox, EM_SETREADONLY, TRUE, 0);
            SetWindowTextW(sourceBox, L"");
            result(captureMode == 2 ? L"正在读取你已复制的文本…" : L"正在读取选区…");
            status(captureMode == 2   ? L"手动复制模式"
                   : captureMode == 3 ? L"指向文字模式"
                                      : L"正在取词，请松开快捷键…");
            ShowWindow(popup, SW_HIDE);
        }
        if (job.phase != Phase::Idle)
            SetTimer(host, 1, 20, nullptr);
    } catch (const std::exception &e) {
        stopJob();
        result(wide(e.what()).c_str());
        status(L"任务未完成");
        showPopup(isManual);
    }
}
static bool handleFrame(const qt::Frame &f) {
    if (job.phase == Phase::Capture) {
        if (f.type == 6) {
            if (f.text.size() > 200)
                throw std::runtime_error("取词路径信息无效。");
            wide(f.text);
            job.captureRoute = f.text;
            if (job.ocr) {
                restoreOcrWindows();
                showPopup(false);
                status(L"本地 OCR 识别中 · 图片不会上传");
            }
            return false;
        }
        if (job.ocr && f.type == 5) {
            auto value = qt::ocrCoordinate(f.text);
            if (value < 0 || value > 100)
                throw std::runtime_error("OCR 置信度格式无效。");
            job.ocrConfidence = value;
            return false;
        }
        if (f.type == 1) {
            wide(f.text);
            if (job.ocr) {
                finishOcrText(f.text);
                return true;
            }
            dispatchSource(f.text);
            showPopup(false);
            return true;
        }
        if (f.type == 3)
            throw std::runtime_error(f.text);
        throw std::runtime_error("取词任务协议无效。");
    }
    if (job.phase != Phase::Network)
        return true;
    if (billingFrame(0, f))
        return false;
    if (f.type == 4) {
        wide(f.text);
        job.partial = job.mixed.render(job.source, f.text);
        if (!job.firstAt)
            job.firstAt = GetTickCount64();
        result(wide(job.partial).c_str());
    } else if (f.type == 5) {
        if (apiEnabled && f.text == "API 内存缓存命中 · 未发送请求")
            billingEnd(0, qt::BillState::Cache);
        status(wide(f.text + " · 正在翻译").c_str());
    } else if (f.type == 2) {
        wide(f.text);
        if (f.text.empty() || f.text.size() > 30000)
            throw std::runtime_error("译文长度无效。");
        auto translated = job.mixed.render(job.source, f.text);
        if (cacheEnabled)
            results.put(job.source, translated, GetTickCount64());
        armCacheExpiry();
        result(wide(translated).c_str());
        auto summary = timing();
        if (job.mixed.mode == qt::MixedMode::Extract)
            summary += L" · 中文本地保留";
        if (job.firstAt)
            summary += L" · 首段 " + std::to_wstring(job.firstAt - job.sourceAt) + L" ms";
        status(summary.c_str());
        rememberTranslation(job.source, translated, job.learningScope);
        finishJob(false);
        return true;
    } else if (f.type == 3) {
        billingEnd(0, qt::BillState::Failed);
        wide(f.text);
        auto error = job.partial.empty() ? f.text
                                         : "【已完成部分】\r\n" + job.partial +
                                               "\r\n\r\n【未全部完成】\r\n" + f.text;
        result(wide(error).c_str());
        status(apiEnabled ? L"API 未完成 · 重试可能计费"
                          : L"请求未完成 · 缓存开启时重试可复用已完成片段");
        finishJob(false);
        return true;
    } else
        throw std::runtime_error("翻译任务协议无效。");
    return false;
}
static void poll() {
    try {
        Worker &worker = job.phase == Phase::Capture ? captureTask : networkTask;
        DWORD avail = 0;
        while (PeekNamedPipe(worker.read, nullptr, 0, nullptr, &avail, nullptr) && avail) {
            char b[4096];
            DWORD n = 0;
            if (!ReadFile(worker.read, b, std::min<DWORD>(avail, sizeof(b)), &n, nullptr) || !n)
                break;
            worker.decoder.feed(b, n);
            qt::Frame f;
            while (worker.decoder.pop(f))
                if (handleFrame(f))
                    return;
        }
        if (!worker.running()) {
            DWORD pending = 0;
            if (PeekNamedPipe(worker.read, nullptr, 0, nullptr, &pending, nullptr) && pending)
                return;
            throw std::runtime_error("取词或翻译任务意外结束，请重试。");
        }
        if (GetTickCount64() > job.deadline)
            throw std::runtime_error("任务超过等待时限，已取消。请缩短选区或稍后重试。");
    } catch (const std::exception &e) {
        std::string output = job.partial.empty() ? e.what()
                                                 : "【已完成部分】\r\n" + job.partial +
                                                       "\r\n\r\n【未全部完成】\r\n" + e.what();
        bool wasCapture = job.phase == Phase::Capture;
        bool hadPartial = !job.partial.empty();
        stopJob();
        result(wide(output).c_str());
        showPopup(false);
        status(wasCapture   ? L"取词未完成 · 尚未发送翻译请求"
               : hadPartial ? L"翻译未完成 · 已保留部分结果"
                            : L"翻译未完成 · 原文已保留，可重试");
    }
}
static void trayUpdate() {
    std::wstring tip = L"轻译 · ";
    tip += paused ? L"已暂停" : shortcuts[keyIndex].name;
    if (!registered && !paused)
        tip += L" · 快捷键冲突";
    wcsncpy_s(tray.szTip, tip.c_str(), _TRUNCATE);
    if (captureMode != 0) {
        tip += captureMode == 2   ? L" · 先Ctrl+C"
               : captureMode == 3 ? L" · 指向文字"
               : captureMode == 4 ? L" · 严格UIA"
                                  : L" · 通用复制";
        wcsncpy_s(tray.szTip, tip.c_str(), _TRUNCATE);
    }
    Shell_NotifyIconW(NIM_MODIFY, &tray);
}
static bool bindKey(int index) {
    return RegisterHotKey(host, HOTKEY, shortcuts[index].mods | MOD_NOREPEAT,
                          shortcuts[index].vk) != 0;
}
static void loadConfig() {
    PWSTR folder = nullptr;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &folder))) {
        std::wstring dir = std::wstring(folder) + L"\\QuietTranslate";
        CoTaskMemFree(folder);
        CreateDirectoryW(dir.c_str(), nullptr);
        config = dir + L"\\settings.ini";
        online = GetPrivateProfileIntW(L"Settings", L"Online", 0, config.c_str()) == 1;
        ocrShortcutEnabled =
            GetPrivateProfileIntW(L"Settings", L"OcrHotkey", 1, config.c_str()) == 1;
        int k = GetPrivateProfileIntW(L"Settings", L"Hotkey", 0, config.c_str());
        keyIndex = (k >= 0 && k < 4) ? k : 0;
        cacheEnabled = GetPrivateProfileIntW(L"Settings", L"MemoryCache", 1, config.c_str()) == 1;
        dictionaryAllowed =
            GetPrivateProfileIntW(L"Settings", L"DictionaryAllowed", 0, config.c_str()) == 1;
        universalCopyAllowed =
            GetPrivateProfileIntW(L"Settings", L"UniversalCopyAllowed", 0, config.c_str()) == 1;
        int mode = GetPrivateProfileIntW(L"Settings", L"CaptureMode", -1, config.c_str());
        captureMode =
            mode >= 0 && mode <= 4
                ? mode
                : (GetPrivateProfileIntW(L"Settings", L"CopiedMode", 0, config.c_str()) == 1 ? 2
                                                                                             : 0);
        if (captureMode == 2)
            copiedSequence.reset(GetClipboardSequenceNumber());
    }
}
static bool saveConfig() {
    if (config.empty())
        return false;
    return WritePrivateProfileStringW(L"Settings", L"OcrHotkey", ocrShortcutEnabled ? L"1" : L"0",
                                      config.c_str()) &&
           WritePrivateProfileStringW(L"Settings", L"UniversalCopyAllowed",
                                      universalCopyAllowed ? L"1" : L"0", config.c_str()) &&
           WritePrivateProfileStringW(L"Settings", L"CaptureMode",
                                      std::to_wstring(captureMode).c_str(), config.c_str()) &&
           WritePrivateProfileStringW(L"Settings", L"CopiedMode", captureMode == 2 ? L"1" : L"0",
                                      config.c_str()) &&
           WritePrivateProfileStringW(L"Settings", L"DictionaryAllowed",
                                      dictionaryAllowed ? L"1" : L"0", config.c_str()) &&
           WritePrivateProfileStringW(L"Settings", L"MemoryCache", cacheEnabled ? L"1" : L"0",
                                      config.c_str()) &&
           WritePrivateProfileStringW(L"Settings", L"Online", online ? L"1" : L"0",
                                      config.c_str()) &&
           WritePrivateProfileStringW(L"Settings", L"Hotkey", std::to_wstring(keyIndex).c_str(),
                                      config.c_str());
}
static void clearPopup() {
    clearLearningTranslation();
    resetStudy();
    stopJob();
    setBillingMain("");
    SetWindowTextW(sourceBox, L"");
    SetWindowTextW(resultBox, L"");
    status(L"已清除本次内容");
    ShowWindow(popup, SW_HIDE);
}
static void manualPanel() {
    clearPopup();
    manual = true;
    SendMessageW(sourceBox, EM_SETREADONLY, FALSE, 0);
    result(L"");
    status(online ? L"就绪" : L"未开启联网");
    showPopup(true);
}
static void showSettings() {
    if (!ensureToolWindow(settings, L"QuietTranslate.Settings", L"设置", 600, 405))
        return;
    SendMessageW(onlineCheck, BM_SETCHECK, online ? BST_CHECKED : BST_UNCHECKED, 0);
    SendMessageW(cacheCheck, BM_SETCHECK, cacheEnabled ? BST_CHECKED : BST_UNCHECKED, 0);
    SendMessageW(dictionaryCheck, BM_SETCHECK, dictionaryAllowed ? BST_CHECKED : BST_UNCHECKED, 0);
    SendMessageW(captureCombo, CB_SETCURSEL, captureMode, 0);
    SendMessageW(keyCombo, CB_SETCURSEL, keyIndex, 0);
    SendMessageW(engineCombo, CB_SETCURSEL, apiEnabled ? 1 : 0, 0);
    ShowWindow(settings, SW_SHOW);
    SetForegroundWindow(settings);
}
#include "api_ui.hpp"
#include "learning_ui.hpp"
#include "billing_ui.hpp"
#include "ocr_ui.hpp"
static LRESULT CALLBACK PopupProc(HWND h, UINT msg, WPARAM w, LPARAM l) {
    switch (msg) {
    case WM_CREATE: {
        child(h, L"STATIC", L"原文", SS_LEFT, 302);
        child(h, L"BUTTON", L"OCR 框选", BS_PUSHBUTTON | WS_TABSTOP, BTN_OCR);
        child(h, L"BUTTON", L"用量 / 费用", BS_PUSHBUTTON | WS_TABSTOP, BTN_BILL);
        sourceBox = child(h, L"EDIT", L"",
                          ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL | WS_TABSTOP,
                          EDIT_SOURCE);
        SendMessageW(sourceBox, EM_SETLIMITTEXT, 4000, 0);
        keywordsLabel = child(h, L"STATIC", L"关键词", SS_LEFT | SS_ENDELLIPSIS, 305);
        child(h, L"STATIC", L"译文", SS_LEFT, 303);
        resultBox = child(h, L"EDIT", L"",
                          ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL | WS_TABSTOP,
                          EDIT_RESULT);
        statusLabel = child(h, L"STATIC", L"", SS_LEFT, 304);
        billingLabel = child(h, L"STATIC", L"", SS_LEFT, 306);
        child(h, L"BUTTON", L"翻译 / 重试", WS_TABSTOP | BS_PUSHBUTTON, BTN_TRANSLATE);
        child(h, L"BUTTON", L"词语学习", WS_TABSTOP | BS_PUSHBUTTON, BTN_STUDY);
        child(h, L"BUTTON", L"设置", WS_TABSTOP | BS_PUSHBUTTON, BTN_SETTINGS);
        child(h, L"BUTTON", L"生词本", WS_TABSTOP | BS_PUSHBUTTON, NB_OPEN);
        child(h, L"BUTTON", L"关闭", WS_TABSTOP | BS_PUSHBUTTON, BTN_HIDE);
        return 0;
    }
    case WM_SIZE: {
        RECT r;
        GetClientRect(h, &r);
        int width = MulDiv(r.right, 96, GetDpiForWindow(h)),
            height = MulDiv(r.bottom, 96, GetDpiForWindow(h));
        int margin = 20, inner = width - 40;
        place(GetDlgItem(h, 302), margin, 20, inner - 240, 22);
        place(GetDlgItem(h, BTN_BILL), width - 248, 16, 108, 28);
        place(GetDlgItem(h, BTN_OCR), width - 128, 16, 108, 28);
        place(sourceBox, margin, 46, inner, 112);
        place(keywordsLabel, margin, 164, inner, 24);
        place(GetDlgItem(h, 303), margin, 196, inner, 22);
        place(resultBox, margin, 224, inner, std::max(80, height - 372));
        place(billingLabel, margin, height - 139, inner, 53);
        place(statusLabel, margin, height - 78, inner, 26);
        place(GetDlgItem(h, BTN_TRANSLATE), margin, height - 44, 116, 30);
        place(GetDlgItem(h, BTN_STUDY), 148, height - 44, 116, 30);
        place(GetDlgItem(h, BTN_SETTINGS), 276, height - 44, 76, 30);
        place(GetDlgItem(h, NB_OPEN), 364, height - 44, 80, 30);
        place(GetDlgItem(h, BTN_HIDE), width - 116, height - 44, 96, 30);
        return 0;
    }
    case WM_GETMINMAXINFO: {
        auto p = (MINMAXINFO *)l;
        p->ptMinTrackSize = {scale(590), scale(500)};
        return 0;
    }
    case WM_MOUSEACTIVATE:
        if (!manual)
            return MA_NOACTIVATE;
        break;
    case WM_COMMAND:
        switch (LOWORD(w)) {
        case BTN_BILL:
            showBilling();
            return 0;
        case BTN_OCR:
            beginOcrSelection();
            return 0;
        case BTN_TRANSLATE:
            startJob(true);
            return 0;
        case BTN_STUDY:
            showStudy();
            return 0;
        case BTN_SETTINGS:
            showSettings();
            return 0;
        case NB_OPEN:
            showNotebook();
            return 0;
        case BTN_HIDE:
            clearPopup();
            return 0;
        }
        break;
    case WM_CLOSE:
        clearPopup();
        return 0;
    case WM_DPICHANGED: {
        auto r = (RECT *)l;
        SetWindowPos(h, nullptr, r->left, r->top, r->right - r->left, r->bottom - r->top,
                     SWP_NOZORDER | SWP_NOACTIVATE);
        return 0;
    }
    case WM_CTLCOLORSTATIC:
        SetBkMode((HDC)w, TRANSPARENT);
        SetTextColor((HDC)w, RGB(36, 49, 68));
        return (LRESULT)bg;
    }
    return DefWindowProcW(h, msg, w, l);
}
static LRESULT CALLBACK StudyProc(HWND h, UINT msg, WPARAM w, LPARAM l) {
    switch (msg) {
    case WM_CREATE:
        child(h, L"STATIC", L"词语学习", SS_LEFT, 510);
        studyCombo = child(h, L"COMBOBOX", L"",
                           CBS_DROPDOWN | CBS_AUTOHSCROLL | WS_TABSTOP | WS_VSCROLL, STUDY_TERM);
        SendMessageW(studyCombo, CB_LIMITTEXT, 40, 0);
        child(h, L"BUTTON", L"查看用法", BS_PUSHBUTTON | WS_TABSTOP, STUDY_LOCAL);
        child(h, L"BUTTON", L"联网补充", BS_PUSHBUTTON | WS_TABSTOP, STUDY_ONLINE);
        studyOutput =
            child(h, L"EDIT", L"",
                  ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL | WS_TABSTOP, 511);
        studyStatus = child(h, L"STATIC", L"", SS_LEFT, 512);
        child(h, L"BUTTON", L"关闭", BS_PUSHBUTTON | WS_TABSTOP, STUDY_CLOSE);
        child(h, L"BUTTON", L"收藏用法", BS_PUSHBUTTON | WS_TABSTOP, ST_SAVE);
        child(h, L"BUTTON", L"网页用法", BS_PUSHBUTTON | WS_TABSTOP, ST_SEARCH);
        child(h, L"BUTTON", L"生词本", BS_PUSHBUTTON | WS_TABSTOP, ST_BOOK);
        return 0;
    case WM_SIZE: {
        RECT r;
        GetClientRect(h, &r);
        int width = MulDiv(r.right, 96, GetDpiForWindow(h)),
            height = MulDiv(r.bottom, 96, GetDpiForWindow(h));
        place(GetDlgItem(h, 510), 20, 16, width - 40, 28);
        place(studyCombo, 20, 58, width - 264, 220);
        place(GetDlgItem(h, STUDY_LOCAL), width - 228, 56, 98, 30);
        place(GetDlgItem(h, STUDY_ONLINE), width - 120, 56, 100, 30);
        place(studyOutput, 20, 102, width - 40, std::max(150, height - 186));
        place(studyStatus, 20, height - 72, width - 40, 28);
        place(GetDlgItem(h, STUDY_CLOSE), width - 120, height - 38, 100, 28);
        place(GetDlgItem(h, ST_SAVE), 20, height - 38, 110, 28);
        place(GetDlgItem(h, ST_SEARCH), 140, height - 38, 110, 28);
        place(GetDlgItem(h, ST_BOOK), 260, height - 38, 100, 28);
        return 0;
    }
    case WM_GETMINMAXINFO: {
        auto p = (MINMAXINFO *)l;
        p->ptMinTrackSize = {scale(570), scale(440)};
        return 0;
    }
    case WM_COMMAND:
        if (LOWORD(w) == ST_SAVE || LOWORD(w) == ST_SEARCH || LOWORD(w) == ST_BOOK) {
            try {
                if (LOWORD(w) == ST_SAVE)
                    saveStudyWord();
                else if (LOWORD(w) == ST_SEARCH)
                    searchUsage(selectedStudyTerm());
                else
                    showNotebook();
            } catch (const std::exception &e) {
                MessageBoxW(h, wide(e.what()).c_str(), APP, MB_OK | MB_ICONWARNING);
            }
            return 0;
        }
        if (LOWORD(w) == STUDY_LOCAL) {
            selectStudyWord();
            return 0;
        }
        if (LOWORD(w) == STUDY_ONLINE) {
            queryStudyWord();
            return 0;
        }
        if (LOWORD(w) == STUDY_TERM &&
            (HIWORD(w) == CBN_SELCHANGE || HIWORD(w) == CBN_EDITCHANGE)) {
            selectStudyWord();
            return 0;
        }
        if (LOWORD(w) == STUDY_CLOSE) {
            stopStudy();
            SetWindowTextW(studyOutput, L"");
            ShowWindow(h, SW_HIDE);
            return 0;
        }
        break;
    case WM_CLOSE:
        stopStudy();
        SetWindowTextW(studyOutput, L"");
        ShowWindow(h, SW_HIDE);
        return 0;
    case WM_DPICHANGED: {
        auto r = (RECT *)l;
        SetWindowPos(h, nullptr, r->left, r->top, r->right - r->left, r->bottom - r->top,
                     SWP_NOZORDER);
        return 0;
    }
    case WM_CTLCOLORSTATIC:
        SetBkMode((HDC)w, TRANSPARENT);
        SetTextColor((HDC)w, RGB(36, 49, 68));
        return (LRESULT)bg;
    }
    return DefWindowProcW(h, msg, w, l);
}
static LRESULT CALLBACK SettingsProc(HWND h, UINT msg, WPARAM w, LPARAM l) {
    switch (msg) {
    case WM_CREATE: {
        child(h, L"STATIC", L"轻译设置", SS_LEFT, 401);
        child(h, L"STATIC", L"翻译快捷键", SS_LEFT, 402);
        keyCombo =
            child(h, L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP | WS_VSCROLL, COMBO_HOTKEY);
        for (auto &k : shortcuts)
            SendMessageW(keyCombo, CB_ADDSTRING, 0, (LPARAM)k.name);
        onlineCheck = child(h, L"BUTTON", L"联网翻译", BS_AUTOCHECKBOX | WS_TABSTOP, CHECK_ONLINE);
        cacheCheck = child(h, L"BUTTON", L"内存缓存", BS_AUTOCHECKBOX | WS_TABSTOP, CHECK_CACHE);
        dictionaryCheck =
            child(h, L"BUTTON", L"联网词典", BS_AUTOCHECKBOX | WS_TABSTOP, CHECK_DICT);
        child(h, L"STATIC", L"取词方式", SS_LEFT, 404);
        captureCombo = child(h, L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP, COMBO_CAPTURE);
        for (auto name :
             {L"智能取词", L"通用复制", L"手动复制（Ctrl+C 后触发）", L"指向文字", L"原生 / UIA"})
            SendMessageW(captureCombo, CB_ADDSTRING, 0, (LPARAM)name);
        engineCombo = child(h, L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP, COMBO_ENGINE);
        SendMessageW(engineCombo, CB_ADDSTRING, 0, (LPARAM)L"MyMemory");
        SendMessageW(engineCombo, CB_ADDSTRING, 0, (LPARAM)L"自定义 API");
        child(h, L"BUTTON", L"API 配置…", BS_PUSHBUTTON | WS_TABSTOP, BTN_API);
        child(h, L"BUTTON", L"保存设置", BS_DEFPUSHBUTTON | WS_TABSTOP, BTN_SAVE);
        child(h, L"BUTTON", L"取消", BS_PUSHBUTTON | WS_TABSTOP, 204);
        return 0;
    }
    case WM_SIZE: {
        place(GetDlgItem(h, 401), 20, 16, 540, 28);
        place(GetDlgItem(h, 402), 20, 56, 540, 24);
        place(keyCombo, 20, 86, 330, 180);
        place(onlineCheck, 20, 134, 540, 30);
        place(cacheCheck, 20, 172, 550, 28);
        place(dictionaryCheck, 20, 208, 550, 28);
        place(GetDlgItem(h, 404), 20, 245, 85, 26);
        place(captureCombo, 108, 242, 455, 145);
        place(engineCombo, 20, 280, 394, 150);
        place(GetDlgItem(h, BTN_API), 428, 280, 135, 30);
        place(GetDlgItem(h, BTN_SAVE), 20, 320, 130, 32);
        place(GetDlgItem(h, 204), 164, 320, 90, 32);
        return 0;
    }
    case WM_COMMAND:
        if (LOWORD(w) == BTN_API) {
            showApi();
            return 0;
        }
        if (LOWORD(w) == BTN_SAVE) {
            bool nextApi = SendMessageW(engineCombo, CB_GETCURSEL, 0, 0) == 1;
            if (nextApi) {
                try {
                    apiConfig.validate();
                } catch (const std::exception &e) {
                    MessageBoxW(h, wide(e.what()).c_str(), APP, MB_OK | MB_ICONWARNING);
                    showApi();
                    return 0;
                }
            }
            bool nextOnline = SendMessageW(onlineCheck, BM_GETCHECK, 0, 0) == BST_CHECKED;
            bool nextCache = SendMessageW(cacheCheck, BM_GETCHECK, 0, 0) == BST_CHECKED;
            bool nextDict = SendMessageW(dictionaryCheck, BM_GETCHECK, 0, 0) == BST_CHECKED;
            int nextCapture = (int)SendMessageW(captureCombo, CB_GETCURSEL, 0, 0);
            if (nextCapture < 0 || nextCapture > 4)
                return 0;
            int next = (int)SendMessageW(keyCombo, CB_GETCURSEL, 0, 0);
            if (next < 0 || next >= 4)
                return 0;
            if (nextOnline && (!online || nextApi != apiEnabled) &&
                MessageBoxW(h, L"将选中文本发送至所选翻译服务，可能产生费用。开启联网？", APP,
                            MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2) != IDYES)
                return 0;
            if ((nextCapture == 0 || nextCapture == 1) &&
                (nextCapture != captureMode || !universalCopyAllowed) &&
                MessageBoxW(h, L"允许发送 Ctrl+Insert 复制选区？此操作会替换当前剪贴板。", APP,
                            MB_YESNO | MB_ICONINFORMATION | MB_DEFBUTTON2) != IDYES)
                return 0;
            if (!paused && (next != keyIndex || !registered)) {
                if (registered)
                    UnregisterHotKey(host, HOTKEY);
                registered = bindKey(next);
                if (!registered) {
                    registered = bindKey(keyIndex);
                    MessageBoxW(h, L"这组快捷键已被占用，未保存。请选择另一组。", APP,
                                MB_OK | MB_ICONWARNING);
                    trayUpdate();
                    return 0;
                }
            }
            try {
                if (!saveApiPrefs(apiConfig, nextApi))
                    throw std::runtime_error("API 设置写入失败，未切换引擎。");
            } catch (const std::exception &e) {
                if (!paused && registered && next != keyIndex) {
                    UnregisterHotKey(host, HOTKEY);
                    registered = bindKey(keyIndex);
                    trayUpdate();
                }
                MessageBoxW(h, wide(e.what()).c_str(), APP, MB_OK | MB_ICONERROR);
                return 0;
            }
            forgetCache();
            apiEnabled = nextApi;
            cacheEnabled = nextCache;
            dictionaryAllowed = nextDict;
            captureMode = nextCapture;
            if (nextCapture == 0 || nextCapture == 1)
                universalCopyAllowed = true;
            if (captureMode == 2)
                copiedSequence.reset(GetClipboardSequenceNumber());
            online = nextOnline;
            keyIndex = next;
            trayUpdate();
            if (!saveConfig())
                MessageBoxW(h, L"设置已在本次运行生效，但无法写入设置文件。下次启动将恢复原设置。",
                            APP, MB_OK | MB_ICONWARNING);
            if (IsWindowVisible(popup)) {
                result(L"设置已更改。点击“翻译 / 重试”以使用新设置。");
                status(online ? L"联网模式 · 使用所选翻译服务" : L"离线模式 · 不发送网络请求");
            }
            ShowWindow(h, SW_HIDE);
            return 0;
        }
        if (LOWORD(w) == 204) {
            ShowWindow(h, SW_HIDE);
            return 0;
        }
        break;
    case WM_CLOSE:
        ShowWindow(h, SW_HIDE);
        return 0;
    case WM_CTLCOLORSTATIC:
        SetBkMode((HDC)w, TRANSPARENT);
        SetTextColor((HDC)w, RGB(36, 49, 68));
        return (LRESULT)bg;
    }
    return DefWindowProcW(h, msg, w, l);
}
static void trayMenu() {
    HMENU m = CreatePopupMenu();
    AppendMenuW(m, MF_STRING, 1, L"手动翻译面板");
    AppendMenuW(m, MF_STRING, 2, L"设置 / 快捷键");
    AppendMenuW(m, MF_STRING, 9,
                ocrRegistered ? L"OCR 框选（Ctrl+Alt+Shift+O）" : L"OCR 框选（点击使用）");
    AppendMenuW(m, MF_STRING | (ocrShortcutEnabled ? MF_CHECKED : 0), 10,
                L"启用 OCR 快捷键 Ctrl+Alt+Shift+O");
    AppendMenuW(m, MF_STRING, 7, L"生词本");
    AppendMenuW(m, MF_STRING, 12, L"用量 / 费用");
    AppendMenuW(m, MF_STRING, 5, L"清除翻译缓存");
    AppendMenuW(m, MF_STRING | (capturePreviewOnly ? MF_CHECKED : 0), 6, L"取词测试");
    AppendMenuW(m, MF_STRING | (paused ? MF_CHECKED : 0), 3, L"暂停快捷键");
    AppendMenuW(m, MF_SEPARATOR, 0, nullptr);
    AppendMenuW(m, MF_STRING, 4, L"退出轻译");
    POINT p;
    GetCursorPos(&p);
    SetForegroundWindow(host);
    int id = TrackPopupMenu(m, TPM_RETURNCMD | TPM_NONOTIFY | TPM_RIGHTBUTTON, p.x, p.y, 0, host,
                            nullptr);
    DestroyMenu(m);
    PostMessageW(host, WM_NULL, 0, 0);
    if (id == 1)
        manualPanel();
    else if (id == 2)
        showSettings();
    else if (id == 9)
        beginOcrSelection();
    else if (id == 10) {
        ocrShortcutEnabled = !ocrShortcutEnabled;
        UnregisterHotKey(host, OCR_HOTKEY);
        ocrRegistered = false;
        if (ocrShortcutEnabled && !paused)
            ocrRegistered =
                RegisterHotKey(host, OCR_HOTKEY, MOD_CONTROL | MOD_ALT | MOD_SHIFT | MOD_NOREPEAT,
                               'O') != 0;
        if (!config.empty())
            WritePrivateProfileStringW(L"Settings", L"OcrHotkey", ocrShortcutEnabled ? L"1" : L"0",
                                       config.c_str());
    } else if (id == 7)
        showNotebook();
    else if (id == 12)
        showBilling();
    else if (id == 6) {
        clearPopup();
        forgetCache();
        capturePreviewOnly = !capturePreviewOnly;
    } else if (id == 5) {
        clearPopup();
        forgetCache();
    } else if (id == 3) {
        paused = !paused;
        if (paused) {
            UnregisterHotKey(host, HOTKEY);
            UnregisterHotKey(host, OCR_HOTKEY);
            ocrRegistered = false;
            registered = false;
            clearPopup();
            forgetCache();
        } else {
            registered = bindKey(keyIndex);
            ocrRegistered =
                ocrShortcutEnabled &&
                RegisterHotKey(host, OCR_HOTKEY, MOD_CONTROL | MOD_ALT | MOD_SHIFT | MOD_NOREPEAT,
                               'O') != 0;
            if (!registered) {
                MessageBoxW(nullptr, L"快捷键已被其他程序占用，请在设置中更换。", APP,
                            MB_OK | MB_ICONWARNING);
                showSettings();
            }
        }
        trayUpdate();
    } else if (id == 4) {
        bool notesSaved = flushNotebook(), billsSaved = flushBilling();
        if (notesSaved && billsSaved)
            DestroyWindow(host);
        else if (!billsSaved) {
            showBilling();
            MessageBoxW(billingWindow,
                        L"用量记录尚未成功保存，程序继续运行。可先导出 CSV，再解决存储问题后退出。",
                        APP, MB_OK | MB_ICONWARNING);
        } else {
            showNotebook();
            MessageBoxW(notebookWindow,
                        L"生词本尚未成功保存，程序继续运行。请先导出记录或解决存储问题，再退出。",
                        APP, MB_OK | MB_ICONWARNING);
        }
    }
}
static LRESULT CALLBACK HostProc(HWND h, UINT msg, WPARAM w, LPARAM l) {
    if (msg == taskbarCreated && taskbarCreated) {
        Shell_NotifyIconW(NIM_ADD, &tray);
        return 0;
    }
    switch (msg) {
    case WM_HOTKEY:
        if (!paused) {
            if (w == OCR_HOTKEY)
                beginOcrSelection();
            else
                startJob(false);
        }
        return 0;
    case WM_TIMER:
        if (w == 11) {
            KillTimer(h, 11);
            flushBilling();
            return 0;
        }
        if (w == 10) {
            KillTimer(h, 10);
            saveBookDraft();
            return 0;
        }
        if (w == 6) {
            KillTimer(h, 6);
            flushNotebook();
            return 0;
        }
        if (w == 5) {
            pollApiTool();
            return 0;
        }
        if (w == 4) {
            if (studyActive)
                pollStudy();
            return 0;
        }
        if (w == 3) {
            results.expire(GetTickCount64());
            studyCache.expire(GetTickCount64());
            armCacheExpiry();
            return 0;
        }
        if (w == 2) {
            KillTimer(h, 2);
            if (job.phase != Phase::Network)
                networkTask.close();
            return 0;
        }
        if (w == 1 && job.phase != Phase::Idle)
            poll();
        return 0;
    case TRAY:
        if (l == WM_RBUTTONUP || l == WM_CONTEXTMENU)
            trayMenu();
        else if (l == WM_LBUTTONDBLCLK)
            manualPanel();
        return 0;
    case WM_QUERYENDSESSION:
        return flushNotebook() && flushBilling() ? TRUE : FALSE;
    case WM_ENDSESSION:
        if (w)
            DestroyWindow(h);
        return 0;
    case WM_DESTROY:
        flushNotebook();
        forgetCache();
        flushBilling();
        UnregisterHotKey(h, HOTKEY);
        UnregisterHotKey(h, OCR_HOTKEY);
        if (ocrOverlay)
            DestroyWindow(ocrOverlay);
        Shell_NotifyIconW(NIM_DELETE, &tray);
        DestroyWindow(popup);
        DestroyWindow(settings);
        DestroyWindow(apiWindow);
        DestroyWindow(studyWindow);
        DestroyWindow(notebookWindow);
        DestroyWindow(billingWindow);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(h, msg, w, l);
}
int WINAPI wWinMain(HINSTANCE hi, HINSTANCE, LPWSTR, int) {
    instance = hi;
    SetDefaultDllDirectories(LOAD_LIBRARY_SEARCH_SYSTEM32);
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    int argc = 0;
    LPWSTR *argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (argc == 2 && wcscmp(argv[1], L"--billing-test") == 0) {
        LocalFree(argv);
        try {
            auto path = learningDirectory() + L"\\test-billing-" + wide(newDevice()) + L".bin";
            struct Cleanup {
                const std::wstring &p;
                ~Cleanup() {
                    DeleteFileW(p.c_str());
                }
            } cleanup{path};
            qt::BillingBook book;
            qt::BillingRate rate;
            rate.enabled = true;
            rate.input = qt::priceMicros("0.7");
            rate.output = qt::priceMicros("1.95");
            auto scope = std::string(64, 'a');
            book.setPrice({scope, "example.invalid", "fixture", rate});
            qt::BillEntry e;
            e.id = newDevice();
            e.scope = scope;
            e.host = "example.invalid";
            e.model = "fixture";
            e.at = 100;
            book.begin(e);
            book.started(e.id);
            qt::ApiUsage u;
            u.inputKnown = u.outputKnown = u.totalKnown = true;
            u.input = 100;
            u.output = 20;
            u.total = 120;
            book.observe(e.id, u);
            book.finish(e.id, qt::BillState::Success);
            protectFile(path, book.json());
            auto copy = qt::BillingBook::parse(protectedFile(path));
            if (copy.stats().total != 120 || copy.stats().cny != 109000000ULL)
                throw std::runtime_error("Billing DPAPI round trip mismatch");
            frame(2, "PASS billing fixed fixture + current-user DPAPI storage; unique test file "
                     "only, no real usage/settings/credentials/network.");
            return 0;
        } catch (const std::exception &e) {
            frame(3, e.what());
            return 1;
        }
    }
    if (argc == 2 && wcscmp(argv[1], L"--learning-test") == 0) {
        LocalFree(argv);
        try {
            auto path = learningDirectory() + L"\\test-learning-" + wide(newDevice()) + L".bin";
            struct Cleanup {
                const std::wstring &path;
                ~Cleanup() {
                    DeleteFileW(path.c_str());
                }
            } cleanup{path};
            auto key = hashText("interrupt");
            if (key != "a2090fd63782e9c30ddc46f71b0c9434bb84390cac145ba03671ec01c52854f8")
                throw std::runtime_error("SHA-256 fixture failed");
            qt::Notebook fixture;
            fixture.record(key, "interrupt", "fixture translation", "fixture", newDevice(), 100);
            protectFile(path, fixture.json());
            auto bytes = fileBytes(path, qt::bookLimit + 65536);
            if (bytes.find("fixture translation") != std::string::npos ||
                qt::Notebook::parse(protectedFile(path)).json() != fixture.json())
                throw std::runtime_error("Encrypted storage fixture failed");
            protectFile(path, fixture.json());
            if (qt::Notebook::parse(protectedFile(path)).find(key)->hits() != 1)
                throw std::runtime_error("Atomic replacement fixture failed");
            atomicBytes(path, "invalid fixture");
            bool rejected = false;
            try {
                protectedFile(path);
            } catch (const std::exception &) {
                rejected = true;
            }
            if (!rejected || fileBytes(path, 100) != "invalid fixture")
                throw std::runtime_error("Corruption guard fixture failed");
            frame(2, "PASS learning SHA256, current-user DPAPI storage, atomic replacement and "
                     "corruption guard. Only a uniquely named app-owned fixture file was written "
                     "and removed; no real history/settings/account/network used.");
            return 0;
        } catch (const std::exception &e) {
            frame(3, e.what());
            return 1;
        }
    }
    if (argc == 2 && wcscmp(argv[1], L"--api-key-test") == 0) {
        LocalFree(argv);
        try {
            const std::string fixture = "QuietTranslate-DPAPI-fixture-not-a-key";
            auto encrypted = protectKey(fixture);
            if (encrypted.empty() || unprotectKey(encrypted) != fixture)
                throw std::runtime_error("DPAPI round trip failed");
            frame(2, "PASS DPAPI current-user round trip; no real key, settings or network used.");
            return 0;
        } catch (const std::exception &e) {
            frame(3, e.what());
            return 1;
        }
    }
    if ((argc == 3 || argc == 4) && wcscmp(argv[1], L"--capture-universal") == 0) {
        HWND target = (HWND)(uintptr_t)_wcstoui64(argv[2], nullptr, 10);
        uint16_t trigger = argc == 4 ? (uint16_t)wcstoul(argv[3], nullptr, 10) : 0;
        LocalFree(argv);
        try {
            std::string route;
            std::string value;
            value = compatibleCopy(target, route, trigger);
            frame(6, route);
            frame(1, value);
            return 0;
        } catch (const std::exception &e) {
            frame(3, e.what());
            return 1;
        }
    }
    if ((argc == 5 || argc == 6 || argc == 7) &&
        (wcscmp(argv[1], L"--capture-smart") == 0 || wcscmp(argv[1], L"--point-only") == 0)) {
        bool point = wcscmp(argv[1], L"--point-only") == 0;
        HWND target = (HWND)(uintptr_t)_wcstoui64(argv[2], nullptr, 10);
        POINT pt{(LONG)wcstol(argv[3], nullptr, 10), (LONG)wcstol(argv[4], nullptr, 10)};
        uint16_t trigger = argc >= 6 ? (uint16_t)wcstoul(argv[5], nullptr, 10) : 0;
        bool allowCopy = argc == 7 && wcstoul(argv[6], nullptr, 10) == 1;
        LocalFree(argv);
        try {
            std::string route;
            std::string value;
            if (point)
                value = pointText(target, pt, route);
            else
                try {
                    value = capture(target, pt, &route);
                } catch (const qt::NoSelection &) {
                    if (!allowCopy)
                        throw std::runtime_error(
                            "原生/UIA "
                            "未取得选区，且尚未允许通用复制。请在设置选择“智能取词”或“通用一键复制”"
                            "，点击保存并确认；未发送复制按键或翻译请求。");
                    value = compatibleCopy(target, route, trigger);
                }
            frame(6, route);
            frame(1, value);
            return 0;
        } catch (const std::exception &e) {
            frame(3, e.what());
            return 1;
        }
    }
    if (argc == 3 && wcscmp(argv[1], L"--capture-copy") == 0) {
        HWND target = (HWND)(uintptr_t)_wcstoui64(argv[2], nullptr, 10);
        LocalFree(argv);
        try {
            std::string route;
            auto value = captureOneKeyCopy(target, route);
            frame(6, route);
            frame(1, value);
            return 0;
        } catch (const std::exception &e) {
            frame(3, e.what());
            return 1;
        }
    }
    if (argc == 3 && wcscmp(argv[1], L"--copied-only") == 0) {
        DWORD expected = wcstoul(argv[2], nullptr, 10);
        LocalFree(argv);
        try {
            frame(6, "手动复制 · 当前文本");
            frame(1, captureCopied(expected));
            return 0;
        } catch (const std::exception &e) {
            frame(3, e.what());
            return 1;
        }
    }
    if (argc == 3 &&
        (wcscmp(argv[1], L"--api-service") == 0 || wcscmp(argv[1], L"--api-test-service") == 0 ||
         wcscmp(argv[1], L"--api-tool") == 0)) {
        bool mock = wcscmp(argv[1], L"--api-test-service") == 0;
        bool tool = wcscmp(argv[1], L"--api-tool") == 0;
        bool list = tool && wcscmp(argv[2], L"models") == 0;
        bool cache = !tool && wcstol(argv[2], nullptr, 10) == 1;
        LocalFree(argv);
        return modelService(mock, cache, tool, list);
    }
    if (argc == 2 && wcscmp(argv[1], L"--study-api") == 0) {
        LocalFree(argv);
        return studyWorker(false, true);
    }
    if (argc == 2 && (wcscmp(argv[1], L"--study") == 0 || wcscmp(argv[1], L"--study-test") == 0)) {
        bool mock = wcscmp(argv[1], L"--study-test") == 0;
        LocalFree(argv);
        return studyWorker(mock);
    }
    if (argc > 1 && wcscmp(argv[1], L"--capture-only") == 0) {
        int code = captureOnly(argc, argv);
        LocalFree(argv);
        return code;
    }
    if (argc == 3 &&
        (wcscmp(argv[1], L"--service") == 0 || wcscmp(argv[1], L"--service-test") == 0)) {
        bool mock = wcscmp(argv[1], L"--service-test") == 0;
        bool cache = wcstol(argv[2], nullptr, 10) == 1;
        LocalFree(argv);
        return service(mock, cache);
    }
    if (argc > 1 && (wcscmp(argv[1], L"--capture") == 0 || wcscmp(argv[1], L"--translate") == 0)) {
        int code = worker(argc, argv);
        LocalFree(argv);
        return code;
    }
    LocalFree(argv);
    Handle mutex(CreateMutexW(nullptr, FALSE,
                              L"Local\\QuietTranslate-65736EC6-C67B-4A02-845E-1BB051CDCF48"));
    if (!mutex.h || GetLastError() == ERROR_ALREADY_EXISTS) {
        MessageBoxW(nullptr,
                    L"已有轻译在后台运行。\r\n\r\n若正在升级到 "
                    L"2.1，请先右键旧版托盘图标选择退出，再运行新版 EXE。",
                    APP, MB_OK | MB_ICONINFORMATION);
        return 0;
    }
    INITCOMMONCONTROLSEX cc{sizeof(cc), ICC_STANDARD_CLASSES};
    InitCommonControlsEx(&cc);
    loadConfig();
    loadApiPrefs();
    loadLearning();
    bg = CreateSolidBrush(RGB(247, 249, 252));
    int dpi = GetDpiForSystem();
    font = CreateFontW(-MulDiv(10, dpi, 72), 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                       DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Microsoft YaHei UI");
    HICON icon = LoadIconW(instance, MAKEINTRESOURCEW(1));
    if (!icon)
        icon = LoadIconW(nullptr, IDI_APPLICATION);
    WNDCLASSW wc{};
    wc.hInstance = instance;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = bg;
    wc.hIcon = icon;
    wc.lpszClassName = L"QuietTranslate.Host";
    wc.lpfnWndProc = HostProc;
    RegisterClassW(&wc);
    wc.lpszClassName = L"QuietTranslate.Popup";
    wc.lpfnWndProc = PopupProc;
    RegisterClassW(&wc);
    wc.lpszClassName = L"QuietTranslate.Settings";
    wc.lpfnWndProc = SettingsProc;
    RegisterClassW(&wc);
    wc.lpszClassName = L"QuietTranslate.API";
    wc.lpfnWndProc = ApiProc;
    RegisterClassW(&wc);
    wc.lpszClassName = L"QuietTranslate.Study";
    wc.lpfnWndProc = StudyProc;
    RegisterClassW(&wc);
    wc.lpszClassName = L"QuietTranslate.Notebook";
    wc.lpfnWndProc = NotebookProc;
    RegisterClassW(&wc);
    wc.lpszClassName = L"QuietTranslate.Billing";
    wc.lpfnWndProc = BillingProc;
    RegisterClassW(&wc);
    wc.lpszClassName = L"QuietTranslate.OCR.Overlay";
    wc.lpfnWndProc = OcrOverlayProc;
    wc.hCursor = LoadCursorW(nullptr, IDC_CROSS);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    RegisterClassW(&wc);
    taskbarCreated = RegisterWindowMessageW(L"TaskbarCreated");
    host = CreateWindowExW(WS_EX_TOOLWINDOW, L"QuietTranslate.Host", APP, WS_OVERLAPPED, 0, 0, 0, 0,
                           nullptr, nullptr, instance, nullptr);
    popup = CreateWindowExW(WS_EX_TOOLWINDOW | WS_EX_TOPMOST, L"QuietTranslate.Popup", APP,
                            WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_THICKFRAME, 100, 100,
                            MulDiv(600, dpi, 96), MulDiv(570, dpi, 96), host, nullptr, instance,
                            nullptr);
    if (!host || !popup) {
        MessageBoxW(nullptr, L"无法创建程序窗口。", APP, MB_OK | MB_ICONERROR);
        return 1;
    }
    tray.cbSize = sizeof(tray);
    tray.hWnd = host;
    tray.uID = 1;
    tray.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    tray.uCallbackMessage = TRAY;
    tray.hIcon = icon;
    wcscpy_s(tray.szTip, L"轻译 · Ctrl + Shift + E");
    if (!Shell_NotifyIconW(NIM_ADD, &tray)) {
        MessageBoxW(nullptr, L"无法创建托盘图标，程序已退出。", APP, MB_OK | MB_ICONERROR);
        return 1;
    }
    if (keyLoadFailed)
        MessageBoxW(host, L"API 配置读取失败，请重新配置。", APP, MB_OK | MB_ICONWARNING);
    registered = bindKey(keyIndex);
    ocrRegistered = ocrShortcutEnabled &&
                    RegisterHotKey(host, OCR_HOTKEY,
                                   MOD_CONTROL | MOD_ALT | MOD_SHIFT | MOD_NOREPEAT, 'O') != 0;
    if (!learningError.empty())
        bookMessage("学习数据提示：" + learningError);
    trayUpdate();
    if (!registered) {
        MessageBoxW(nullptr, L"快捷键被其他程序占用，请选择另一组。", APP, MB_OK | MB_ICONWARNING);
        showSettings();
    }
    MSG m;
    while (GetMessageW(&m, nullptr, 0, 0) > 0) {
        if (m.message == WM_KEYDOWN && m.wParam == VK_RETURN &&
            (GetKeyState(VK_CONTROL) & 0x8000) && GetAncestor(m.hwnd, GA_ROOT) == popup && manual) {
            startJob(true);
            continue;
        }
        if (m.message == WM_KEYDOWN && m.wParam == VK_ESCAPE) {
            if (GetAncestor(m.hwnd, GA_ROOT) == billingWindow) {
                SendMessageW(billingWindow, WM_CLOSE, 0, 0);
                continue;
            }
            if (GetAncestor(m.hwnd, GA_ROOT) == notebookWindow) {
                SendMessageW(GetAncestor(m.hwnd, GA_ROOT), WM_CLOSE, 0, 0);
                continue;
            }
            if (GetAncestor(m.hwnd, GA_ROOT) == popup) {
                clearPopup();
                continue;
            }
            if (GetAncestor(m.hwnd, GA_ROOT) == studyWindow) {
                SendMessageW(studyWindow, WM_CLOSE, 0, 0);
                continue;
            }
            if (GetAncestor(m.hwnd, GA_ROOT) == apiWindow) {
                stopApiTool();
                SetWindowTextW(apiKey, L"");
                ShowWindow(apiWindow, SW_HIDE);
                continue;
            }
            if (GetAncestor(m.hwnd, GA_ROOT) == settings) {
                ShowWindow(settings, SW_HIDE);
                continue;
            }
        }
        if (IsWindowVisible(billingWindow) && IsDialogMessageW(billingWindow, &m))
            continue;
        if (IsWindowVisible(notebookWindow) && IsDialogMessageW(notebookWindow, &m))
            continue;
        if (IsWindowVisible(studyWindow) && IsDialogMessageW(studyWindow, &m))
            continue;
        if (IsWindowVisible(apiWindow) && IsDialogMessageW(apiWindow, &m))
            continue;
        if (IsWindowVisible(settings) && IsDialogMessageW(settings, &m))
            continue;
        if (manual && IsWindowVisible(popup) && IsDialogMessageW(popup, &m))
            continue;
        TranslateMessage(&m);
        DispatchMessageW(&m);
    }
    DeleteObject(font);
    DeleteObject(bg);
    return 0;
}
