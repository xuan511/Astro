#pragma once
// The overlay paints a live dimmer. No screenshot exists until a region is explicitly chosen.
static HWND ocrOverlay = nullptr, ocrPreviousForeground = nullptr;
static bool ocrSelecting = false, ocrDragging = false, ocrWindowsHidden = false;
static POINT ocrStart{}, ocrEnd{};
static qt::OcrBounds ocrScreen{};
static std::vector<std::pair<HWND, bool>> ocrVisibility;
static void restoreOcrWindows() {
    if (!ocrWindowsHidden)
        return;
    ocrWindowsHidden = false;
    for (const auto &w : ocrVisibility)
        if (w.second && IsWindow(w.first))
            ShowWindow(w.first, SW_SHOWNOACTIVATE);
    ocrVisibility.clear();
}
static void cancelOcrSelection(bool restore) {
    if (!ocrSelecting)
        return;
    ocrSelecting = false;
    ocrDragging = false;
    if (GetCapture() == ocrOverlay)
        ReleaseCapture();
    if (ocrOverlay)
        ShowWindow(ocrOverlay, SW_HIDE);
    if (restore) {
        restoreOcrWindows();
        if (ocrPreviousForeground && IsWindow(ocrPreviousForeground) &&
            IsWindowVisible(ocrPreviousForeground))
            SetForegroundWindow(ocrPreviousForeground);
    }
}
static void startOcrWorker(const qt::OcrRegion &region) {
    try {
        qt::validateOcrRegion(region, ocrScreen);
        cancelOcrSelection(false);
        stopStudy();
        job = Job{};
        job.ocr = true;
        job.phase = Phase::Capture;
        job.started = GetTickCount64();
        job.deadline = job.started + 25000;
        job.learningScope = learningScopeKey();
        job.captureRoute = "本地 OCR";
        std::wstring args = L"--capture " + std::to_wstring(region.x) + L" " +
                            std::to_wstring(region.y) + L" " + std::to_wstring(region.width) +
                            L" " + std::to_wstring(region.height);
        // Worker flushes compositor and captures while our windows remain hidden.
        // A stalled display driver must not block this UI thread.
        if (!spawn(captureTask, args, false, true))
            throw std::runtime_error(
                "无法启动 OCR。请完整解压同目录的 QuietTranslate.OCR.exe 和 ocr-data 文件夹。");
        SetTimer(host, 1, 20, nullptr);
        if (ocrPreviousForeground && IsWindow(ocrPreviousForeground) &&
            IsWindowVisible(ocrPreviousForeground))
            SetForegroundWindow(ocrPreviousForeground);
    } catch (const std::exception &e) {
        cancelOcrSelection(false);
        stopJob();
        restoreOcrWindows();
        result(wide(e.what()).c_str());
        status(L"OCR 未完成 · 未发送翻译请求");
        showPopup(true);
    }
}
static void finishOcrText(const std::string &source) {
    auto value = qt::ocrText(source);
    int confidence = job.ocrConfidence;
    finishJob(false);
    setBillingMain("OCR 预览 · Token 0 · 费用 0");
    clearLearningTranslation();
    manual = true;
    SendMessageW(sourceBox, EM_SETREADONLY, FALSE, 0);
    SetWindowTextW(sourceBox, wide(value).c_str());
    setStudySource(value);
    result(L"核对原文后，按 Ctrl+Enter 翻译。");
    std::wstring message = L"OCR 完成";
    if (confidence >= 0)
        message += L" · 引擎置信度 " + std::to_wstring(confidence) + L"%";
    status(message.c_str());
    showPopup(true);
}
static void beginOcrSelection() {
    cancelOcrSelection();
    stopJob();
    KillTimer(host, 2);
    try {
        int x = GetSystemMetrics(SM_XVIRTUALSCREEN), y = GetSystemMetrics(SM_YVIRTUALSCREEN);
        int64_t w = GetSystemMetrics(SM_CXVIRTUALSCREEN), h = GetSystemMetrics(SM_CYVIRTUALSCREEN);
        if (w <= 0 || h <= 0 || (int64_t)x + w > INT32_MAX || (int64_t)y + h > INT32_MAX)
            throw std::runtime_error("无法读取屏幕布局。");
        ocrScreen = {x, y, (int32_t)(x + w), (int32_t)(y + h)};
        ocrPreviousForeground = GetForegroundWindow();
        ocrVisibility.clear();
        for (HWND window : {popup, settings, apiWindow, studyWindow, notebookWindow, billingWindow})
            ocrVisibility.push_back({window, IsWindowVisible(window) != 0});
        ocrWindowsHidden = true;
        for (const auto &window : ocrVisibility)
            if (window.second)
                ShowWindow(window.first, SW_HIDE);
        if (!ocrOverlay)
            ocrOverlay = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_LAYERED,
                                         L"QuietTranslate.OCR.Overlay", L"轻译 OCR 框选", WS_POPUP,
                                         x, y, (int)w, (int)h, host, nullptr, instance, nullptr);
        if (!ocrOverlay || !SetLayeredWindowAttributes(ocrOverlay, 0, 100, LWA_ALPHA))
            throw std::runtime_error("无法创建 OCR 框选层。");
        ocrSelecting = true;
        ocrDragging = false;
        SetWindowPos(ocrOverlay, HWND_TOPMOST, x, y, (int)w, (int)h, SWP_SHOWWINDOW);
        SetForegroundWindow(ocrOverlay);
        SetFocus(ocrOverlay);
        InvalidateRect(ocrOverlay, nullptr, TRUE);
    } catch (const std::exception &e) {
        cancelOcrSelection(false);
        restoreOcrWindows();
        result(wide(e.what()).c_str());
        status(L"OCR 未开始 · 未截图或发送翻译");
        showPopup(true);
    }
}
static LRESULT CALLBACK OcrOverlayProc(HWND h, UINT msg, WPARAM w, LPARAM l) {
    switch (msg) {
    case WM_KEYDOWN:
        if (w == VK_ESCAPE) {
            cancelOcrSelection();
            return 0;
        }
        return 0;
    case WM_RBUTTONDOWN:
    case WM_CLOSE:
        cancelOcrSelection();
        return 0;
    case WM_ACTIVATE:
        if (LOWORD(w) == WA_INACTIVE && ocrSelecting)
            cancelOcrSelection();
        return 0;
    case WM_DISPLAYCHANGE:
        cancelOcrSelection();
        return 0;
    case WM_CAPTURECHANGED:
        if (ocrSelecting && ocrDragging)
            cancelOcrSelection();
        return 0;
    case WM_LBUTTONDOWN:
        if (ocrSelecting) {
            GetCursorPos(&ocrStart);
            ocrEnd = ocrStart;
            ocrDragging = true;
            SetCapture(h);
            InvalidateRect(h, nullptr, TRUE);
        }
        return 0;
    case WM_MOUSEMOVE:
        if (ocrSelecting && ocrDragging) {
            GetCursorPos(&ocrEnd);
            InvalidateRect(h, nullptr, TRUE);
        }
        return 0;
    case WM_LBUTTONUP:
        if (ocrSelecting && ocrDragging) {
            GetCursorPos(&ocrEnd);
            try {
                startOcrWorker(qt::ocrDrag(ocrStart.x, ocrStart.y, ocrEnd.x, ocrEnd.y, ocrScreen));
            } catch (const std::exception &e) {
                cancelOcrSelection();
                result(wide(e.what()).c_str());
                status(L"OCR 选区无效 · 未截图");
                showPopup(true);
            }
        }
        return 0;
    case WM_SETCURSOR:
        SetCursor(LoadCursorW(nullptr, IDC_CROSS));
        return TRUE;
    case WM_PAINT: {
        PAINTSTRUCT paint;
        HDC dc = BeginPaint(h, &paint);
        RECT client;
        GetClientRect(h, &client);
        FillRect(dc, &client, (HBRUSH)GetStockObject(BLACK_BRUSH));
        SetBkMode(dc, TRANSPARENT);
        SetTextColor(dc, RGB(255, 255, 255));
        SelectObject(dc, font);
        POINT cursor;
        GetCursorPos(&cursor);
        MONITORINFO monitor{};
        monitor.cbSize = sizeof(monitor);
        GetMonitorInfoW(MonitorFromPoint(cursor, MONITOR_DEFAULTTONEAREST), &monitor);
        RECT hint{
            monitor.rcWork.left - ocrScreen.left + 24, monitor.rcWork.top - ocrScreen.top + 20,
            monitor.rcWork.right - ocrScreen.left - 20, monitor.rcWork.top - ocrScreen.top + 88};
        DrawTextW(dc,
                  L"拖动鼠标框选英文区域 · Esc / 右键取消\n本机英文 OCR · 识别后可编辑，确认才翻译",
                  -1, &hint, DT_LEFT | DT_NOPREFIX);
        if (ocrDragging) {
            RECT box{std::min(ocrStart.x, ocrEnd.x) - ocrScreen.left,
                     std::min(ocrStart.y, ocrEnd.y) - ocrScreen.top,
                     std::max(ocrStart.x, ocrEnd.x) - ocrScreen.left,
                     std::max(ocrStart.y, ocrEnd.y) - ocrScreen.top};
            HBRUSH brush = CreateSolidBrush(RGB(0, 220, 255));
            FrameRect(dc, &box, brush);
            InflateRect(&box, -1, -1);
            FrameRect(dc, &box, brush);
            DeleteObject(brush);
        }
        EndPaint(h, &paint);
        return 0;
    }
    }
    return DefWindowProcW(h, msg, w, l);
}
