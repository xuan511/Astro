#pragma once
#include "core.hpp"
#include <functional>
namespace qt {
struct ApiUsage {
    bool inputKnown = false, outputKnown = false, totalKnown = false, cachedKnown = false,
         invalid = false;
    uint64_t input = 0, output = 0, total = 0, cached = 0;
    bool any() const {
        return inputKnown || outputKnown || totalKnown || invalid;
    }
    bool full() const {
        return !invalid && inputKnown && outputKnown;
    }
    static uint64_t number(const Json &v) {
        if (v.kind != Json::Number || v.text.empty() || v.text.size() > 9)
            throw std::runtime_error("invalid usage");
        uint64_t n = 0;
        for (char c : v.text) {
            if (c < '0' || c > '9')
                throw std::runtime_error("invalid usage");
            n = n * 10 + c - '0';
            if (n > 200000000)
                throw std::runtime_error("invalid usage");
        }
        return n;
    }
    static ApiUsage fromResponse(const Json &response) {
        ApiUsage u;
        if (response.kind != Json::Object || !response.object.count("usage") ||
            response.at("usage").kind == Json::Null)
            return u;
        try {
            const auto &j = response.at("usage");
            if (j.kind != Json::Object)
                throw std::runtime_error("invalid usage");
            auto read = [&](const char *a, const char *b, bool &known, uint64_t &value) {
                if (j.object.count(a)) {
                    known = true;
                    value = number(j.at(a));
                } else if (b && j.object.count(b)) {
                    known = true;
                    value = number(j.at(b));
                }
            };
            read("prompt_tokens", "input_tokens", u.inputKnown, u.input);
            read("completion_tokens", "output_tokens", u.outputKnown, u.output);
            read("total_tokens", nullptr, u.totalKnown, u.total);
            if (u.input > 100000000 || u.output > 100000000)
                throw std::runtime_error("invalid usage");
            for (const auto *key : {"prompt_tokens_details", "input_tokens_details"})
                if (j.object.count(key) && j.at(key).kind == Json::Object &&
                    j.at(key).object.count("cached_tokens")) {
                    u.cachedKnown = true;
                    u.cached = number(j.at(key).at("cached_tokens"));
                    break;
                }
            if (!u.cachedKnown)
                read("cached_tokens", "prompt_cache_hit_tokens", u.cachedKnown, u.cached);
            if (u.cachedKnown && u.inputKnown && u.cached > u.input)
                throw std::runtime_error("invalid usage");
            if (u.inputKnown && u.outputKnown) {
                if (u.totalKnown && u.total != u.input + u.output)
                    throw std::runtime_error("invalid usage");
                u.total = u.input + u.output;
                u.totalKnown = true;
            }
        } catch (const std::exception &) {
            u = ApiUsage{};
            u.invalid = true;
        }
        return u;
    }
    std::string json() const {
        std::string s = "{";
        auto put = [&](const char *k, uint64_t v) {
            if (s.size() > 1)
                s += ',';
            s += '"';
            s += k;
            s += "\":" + std::to_string(v);
        };
        if (inputKnown)
            put("input_tokens", input);
        if (outputKnown)
            put("output_tokens", output);
        if (totalKnown)
            put("total_tokens", total);
        if (cachedKnown)
            put("cached_tokens", cached);
        if (invalid)
            put("invalid", 1);
        return s + '}';
    }
    static ApiUsage parse(const Json &j) {
        if (j.kind != Json::Object)
            throw std::runtime_error("用量字段格式无效。");
        Json envelope;
        envelope.kind = Json::Object;
        envelope.object["usage"] = j;
        auto u = fromResponse(envelope);
        if (j.object.count("invalid"))
            u.invalid = true;
        return u;
    }
};
using UsageSink = std::function<void(const ApiUsage &)>;
} // namespace qt
