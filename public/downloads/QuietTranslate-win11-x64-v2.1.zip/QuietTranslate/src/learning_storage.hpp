#pragma once
// Windows storage helpers; only app-owned files unless a user explicitly chooses an export path.
static std::wstring learningDirectory() {
    PWSTR p = nullptr;
    if (FAILED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &p)))
        throw std::runtime_error("无法定位学习数据目录。");
    std::wstring dir = std::wstring(p) + L"\\QuietTranslate";
    CoTaskMemFree(p);
    if (!CreateDirectoryW(dir.c_str(), nullptr) && GetLastError() != ERROR_ALREADY_EXISTS)
        throw std::runtime_error("无法创建自身学习数据目录。");
    return dir;
}
static std::string hashText(const std::string &s) {
    BYTE digest[32];
    DWORD size = 32;
    if (!CryptHashCertificate2(L"SHA256", 0, nullptr, (const BYTE *)s.data(), (DWORD)s.size(),
                               digest, &size) ||
        size != 32)
        throw std::runtime_error("无法计算学习记录标识。");
    const char *hex = "0123456789abcdef";
    std::string out;
    for (BYTE b : digest) {
        out += hex[b >> 4];
        out += hex[b & 15];
    }
    return out;
}
static std::string newDevice() {
    GUID g;
    if (FAILED(CoCreateGuid(&g)))
        throw std::runtime_error("无法创建学习设备标识。");
    wchar_t s[40];
    StringFromGUID2(g, s, 40);
    auto id = narrow(s);
    id = id.substr(1, 36);
    std::transform(id.begin(), id.end(), id.begin(),
                   [](unsigned char c) { return (char)tolower(c); });
    return id;
}
static uint64_t unixMillis() {
    FILETIME f;
    GetSystemTimeAsFileTime(&f);
    ULARGE_INTEGER n{};
    n.LowPart = f.dwLowDateTime;
    n.HighPart = f.dwHighDateTime;
    return (n.QuadPart - 116444736000000000ULL) / 10000;
}
static std::string fileBytes(const std::wstring &path, size_t limit) {
    Handle f(CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_DELETE, nullptr,
                         OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr));
    if (f.h == INVALID_HANDLE_VALUE) {
        if (GetLastError() == ERROR_FILE_NOT_FOUND)
            return {};
        throw std::runtime_error("无法读取自身学习文件。");
    }
    LARGE_INTEGER size;
    if (!GetFileSizeEx(f.h, &size) || size.QuadPart < 0 || (uint64_t)size.QuadPart > limit)
        throw std::runtime_error("学习文件超出安全上限。");
    std::string bytes((size_t)size.QuadPart, 0);
    size_t at = 0;
    while (at < bytes.size()) {
        DWORD n = 0;
        if (!ReadFile(f.h, bytes.data() + at, (DWORD)std::min<size_t>(65536, bytes.size() - at), &n,
                      nullptr) ||
            !n)
            throw std::runtime_error("学习文件读取中断。");
        at += n;
    }
    return bytes;
}
static void atomicBytes(const std::wstring &path, const std::string &bytes) {
    auto temp = path + L".qt-" + wide(newDevice()) + L".tmp";
    struct TempCleanup {
        const std::wstring &path;
        bool owned = false;
        ~TempCleanup() {
            if (owned)
                DeleteFileW(path.c_str());
        }
    } cleanup{temp};
    {
        Handle f(CreateFileW(temp.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW,
                             FILE_ATTRIBUTE_NORMAL, nullptr));
        if (f.h == INVALID_HANDLE_VALUE)
            throw std::runtime_error("无法写入学习文件。");
        cleanup.owned = true;
        if (!writeAll(f.h, bytes.data(), (DWORD)bytes.size()) || !FlushFileBuffers(f.h))
            throw std::runtime_error("学习文件未能完整写入，旧文件未替换。");
    }
    if (!MoveFileExW(temp.c_str(), path.c_str(),
                     MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
        throw std::runtime_error("无法原子替换学习文件，旧文件已保留。");
}
static std::string protectedFile(const std::wstring &path) {
    auto bytes = fileBytes(path, qt::bookLimit + 65536);
    if (bytes.empty()) {
        if (GetFileAttributesW(path.c_str()) == INVALID_FILE_ATTRIBUTES &&
            GetLastError() == ERROR_FILE_NOT_FOUND)
            return {};
        throw std::runtime_error("学习文件为空或状态异常；未覆盖原文件。");
    }
    if (bytes.size() < 9 || bytes.compare(0, 8, "QTDATA17") != 0)
        throw std::runtime_error("不支持的学习文件格式；未覆盖原文件。");
    DATA_BLOB input{(DWORD)(bytes.size() - 8), (BYTE *)bytes.data() + 8}, out{};
    if (!CryptUnprotectData(&input, nullptr, nullptr, nullptr, nullptr, CRYPTPROTECT_UI_FORBIDDEN,
                            &out))
        throw std::runtime_error("无法解密学习文件，请使用原 Windows 用户；未覆盖原文件。");
    if (out.cbData > qt::bookLimit) {
        SecureZeroMemory(out.pbData, out.cbData);
        LocalFree(out.pbData);
        throw std::runtime_error("学习数据超限。");
    }
    std::string plain((char *)out.pbData, out.cbData);
    SecureZeroMemory(out.pbData, out.cbData);
    LocalFree(out.pbData);
    return plain;
}
static void protectFile(const std::wstring &path, const std::string &plain) {
    if (plain.size() > qt::bookLimit)
        throw std::runtime_error("学习数据超过 8 MiB，旧文件未覆盖。");
    DATA_BLOB input{(DWORD)plain.size(), (BYTE *)plain.data()}, out{};
    if (!CryptProtectData(&input, L"QuietTranslate learning", nullptr, nullptr, nullptr,
                          CRYPTPROTECT_UI_FORBIDDEN, &out))
        throw std::runtime_error("Windows 无法加密学习数据。");
    std::string bytes = "QTDATA17";
    bytes.append((char *)out.pbData, out.cbData);
    SecureZeroMemory(out.pbData, out.cbData);
    LocalFree(out.pbData);
    atomicBytes(path, bytes);
}
static std::wstring localBookPath() {
    return learningDirectory() + L"\\learning-local.bin";
}
