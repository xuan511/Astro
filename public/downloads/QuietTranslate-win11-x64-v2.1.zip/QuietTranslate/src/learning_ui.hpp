#pragma once
#include "learning_draft.hpp"
// Local notebook UI. No account/session service or background monitoring.
enum {
    NB_OPEN = 107,
    ST_SAVE = 505,
    ST_SEARCH = 506,
    ST_BOOK = 507,
    NB_LIST = 701,
    NB_FILTER,
    NB_SORT,
    NB_DETAIL,
    NB_NOTE,
    NB_STAR,
    NB_KNOWN,
    NB_APPLY,
    NB_RECALL,
    NB_FORGET,
    NB_DELETE,
    NB_STUDY,
    NB_SEARCH,
    NB_EXPORT,
    NB_HISTORY,
    NB_SENTENCES,
    NB_CURRENT,
    NB_STATUS,
    NB_BACKUP_IMPORT,
    NB_UNDO,

};
static HWND notebookWindow, bookList, bookFilter, bookSort, bookDetail, bookNote, bookStar,
    bookKnown, bookHistory, bookSentences, bookStatus;
static qt::Notebook notebook;
static bool bookLoaded = false, bookReady = false, bookDiskDirty = false, historyEnabled = false,
            sentenceHistory = false;
static std::string learningDevice, learningError, lastSource, lastTranslation, lastEngine,
    lastScope;
static std::vector<std::string> bookKeys;
static qt::LearningDraft bookDraft;
static bool loadingBookForm = false;
static void refreshBook();
static bool saveBookDraft();
static void fitLearningWindow(HWND h) {
    MONITORINFO info{};
    info.cbSize = sizeof(info);
    RECT r{};
    if (!GetWindowRect(h, &r) ||
        !GetMonitorInfoW(MonitorFromWindow(h, MONITOR_DEFAULTTONEAREST), &info))
        return;
    int width = std::min((int)(r.right - r.left), (int)(info.rcWork.right - info.rcWork.left));
    int height = std::min((int)(r.bottom - r.top), (int)(info.rcWork.bottom - info.rcWork.top));
    int x = std::max((int)info.rcWork.left, std::min((int)r.left, (int)info.rcWork.right - width));
    int y = std::max((int)info.rcWork.top, std::min((int)r.top, (int)info.rcWork.bottom - height));
    SetWindowPos(h, HWND_TOPMOST, x, y, width, height, SWP_NOACTIVATE);
}
static void bookMessage(const std::string &s) {
    if (bookStatus)
        SetWindowTextW(bookStatus, wide(s).c_str());
}
static std::string learningScopeKey() {
    return "local";
}
static void clearLearningTranslation() {
    lastSource.clear();
    lastTranslation.clear();
    lastEngine.clear();
    lastScope.clear();
}
static std::wstring learningPref(const wchar_t *name) {
    wchar_t value[5000]{};
    if (!config.empty())
        GetPrivateProfileStringW(L"Learning", name, L"", value, 5000, config.c_str());
    return value;
}
static void learningPref(const wchar_t *name, const std::wstring &value) {
    if (config.empty() ||
        !WritePrivateProfileStringW(L"Learning", name, value.c_str(), config.c_str()))
        throw std::runtime_error("无法保存学习设置。");
}
static bool flushNotebook() {
    if (!saveBookDraft())
        return false;
    if (!bookDiskDirty)
        return true;
    try {
        if (!bookReady)
            throw std::runtime_error("生词本未安全加载，拒绝覆盖文件。");
        protectFile(localBookPath(), notebook.json());
        bookDiskDirty = false;
        KillTimer(host, 6);
        return true;
    } catch (const std::exception &e) {
        learningError = e.what();
        bookMessage("保存失败：" + learningError + " 记录仍在内存，请导出或重试后退出。");
        return false;
    }
}
static void changedBook() {
    bookDiskDirty = true;
    SetTimer(host, 6, 900, nullptr);
}
static bool saveBookDraft() {
    if (!bookDraft.dirty())
        return true;
    try {
        if (!bookReady)
            throw std::runtime_error("生词本未安全加载，笔记草稿未提交。");
        if (bookDraft.commit(notebook, learningScopeKey(), learningDevice, unixMillis()))
            changedBook();
        auto e = notebook.find(bookDraft.key());
        if (e && !e->deleted) {
            loadingBookForm = true;
            if (narrow(text(bookNote)) != e->note)
                SetWindowTextW(bookNote, wide(e->note).c_str());
            SendMessageW(bookStar, BM_SETCHECK, e->star ? BST_CHECKED : BST_UNCHECKED, 0);
            SendMessageW(bookKnown, BM_SETCHECK, e->known ? BST_CHECKED : BST_UNCHECKED, 0);
            loadingBookForm = false;
        }
        KillTimer(host, 10);
        bookMessage("已保存");
        return true;
    } catch (const std::exception &e) {
        loadingBookForm = false;
        bookMessage(std::string("草稿仍保留：") + e.what());
        return false;
    }
}
static bool ensureNotebookLoaded() {
    if (bookLoaded)
        return bookReady;
    bookLoaded = true;
    try {
        auto plain = protectedFile(localBookPath());
        if (!plain.empty())
            notebook = qt::Notebook::parse(plain);
        bookReady = true;
    } catch (const std::exception &e) {
        learningError = e.what();
        bookReady = false;
    }
    return bookReady;
}
static void loadLearning() {
    try {
        learningDevice = narrow(learningPref(L"DeviceId"));
        if (!qt::uuidText(learningDevice)) {
            learningDevice = newDevice();
            learningPref(L"DeviceId", wide(learningDevice));
        }
        historyEnabled = learningPref(L"History") == L"1";
        sentenceHistory = learningPref(L"Sentences") == L"1";
        if (historyEnabled)
            ensureNotebookLoaded();
    } catch (const std::exception &e) {
        learningError = e.what();
        bookReady = false;
    }
}
static void rememberTranslation(const std::string &source, const std::string &translation,
                                const std::string &scope) {
    lastSource = source;
    lastTranslation = translation;
    lastEngine = engineLabel();
    lastScope = scope;
    if (!historyEnabled || !bookReady || scope != learningScopeKey() ||
        (!sentenceHistory && !qt::shortLearningQuery(source)))
        return;
    try {
        notebook.record(hashText(source), source, translation, lastEngine, learningDevice,
                        unixMillis());
        changedBook();
        if (IsWindowVisible(notebookWindow))
            refreshBook();
    } catch (const std::exception &e) {
        bookMessage(std::string("本次查询未入本：") + e.what());
        status(wide(std::string("译文已完成 · 学习记录未保存：") + e.what()).c_str());
    }
}
static void rememberStudy(const std::string &term, const std::string &detail,
                          const std::string &scope) {
    if (!historyEnabled || !bookReady || scope != learningScopeKey())
        return;
    try {
        auto key = hashText(term);
        qt::safeText(detail, 8000);
        notebook.record(key, term, "", engineLabel(), learningDevice, unixMillis(), true, detail);
        changedBook();
        if (IsWindowVisible(notebookWindow))
            refreshBook();
    } catch (const std::exception &e) {
        bookMessage(std::string("用法未入本：") + e.what());
        SetWindowTextW(studyStatus,
                       wide(std::string("词典已完成 · 学习记录未保存：") + e.what()).c_str());
    }
}
static void saveCurrentTranslation() {
    if (!ensureNotebookLoaded())
        throw std::runtime_error("生词本无法加载：" + learningError);
    if (job.phase != Phase::Idle || lastSource.empty() || lastTranslation.empty() ||
        lastScope != learningScopeKey() || qt::trim(narrow(text(sourceBox))) != lastSource)
        throw std::runtime_error("请先完成当前文本的翻译。");
    auto key = hashText(lastSource);
    notebook.record(key, lastSource, lastTranslation, lastEngine, learningDevice, unixMillis(),
                    false, "", true);
    changedBook();
    refreshBook();
    bookMessage("已收藏当前译文。");
}
static void saveStudyWord() {
    if (!ensureNotebookLoaded())
        throw std::runtime_error("生词本无法加载：" + learningError);
    auto term = selectedStudyTerm();
    if (!qt::dictionaryWord(term) && !qt::shortLearningQuery(term))
        throw std::runtime_error("请输入英文单词或短语。");
    auto detail = narrow(text(studyOutput));
    qt::safeText(detail, 8000);
    auto key = hashText(term);
    notebook.record(key, term, qt::lookup(term), engineLabel(), learningDevice, unixMillis(), false,
                    detail, true);
    changedBook();
    refreshBook();
    SetWindowTextW(studyStatus, L"已收藏");
}
static void searchUsage(const std::string &term) {
    auto q = qt::trim(term);
    if (!qt::shortLearningQuery(q))
        throw std::runtime_error("网页用法搜索仅接受最多 8 个词、160 字节的英文单词或短语。");
    std::string encoded;
    const char *hex = "0123456789ABCDEF";
    for (unsigned char c : q + " English usage examples") {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
            c == '-' || c == '_' || c == '.')
            encoded += char(c);
        else {
            encoded += '%';
            encoded += hex[c >> 4];
            encoded += hex[c & 15];
        }
    }
    // Only this fixed HTTPS origin can be opened, only from an explicit Search button.
    auto url = wide("https://www.bing.com/search?q=" + encoded);
    if ((INT_PTR)ShellExecuteW(nullptr, L"open", url.c_str(), nullptr, nullptr, SW_SHOWNORMAL) <=
        32)
        throw std::runtime_error("无法打开默认浏览器。");
}
static std::string chosenBookKey() {
    auto n = (int)SendMessageW(bookList, LB_GETCURSEL, 0, 0);
    return n >= 0 && (size_t)n < bookKeys.size() ? bookKeys[n] : "";
}
static std::string dateText(uint64_t ms) {
    if (!ms)
        return "未安排";
    if (ms > (UINT64_MAX - 116444736000000000ULL) / 10000)
        return "时间超出显示范围";
    ULARGE_INTEGER n{};
    n.QuadPart = ms * 10000 + 116444736000000000ULL;
    FILETIME utc{n.LowPart, n.HighPart}, local{};
    SYSTEMTIME t{};
    if (!FileTimeToLocalFileTime(&utc, &local) || !FileTimeToSystemTime(&local, &t))
        return "时间无效";
    char s[32];
    snprintf(s, sizeof(s), "%04u-%02u-%02u %02u:%02u", t.wYear, t.wMonth, t.wDay, t.wHour,
             t.wMinute);
    return s;
}
static void showBookEntry() {
    auto selected = chosenBookKey();
    if (!saveBookDraft()) {
        auto old = std::find(bookKeys.begin(), bookKeys.end(), bookDraft.key());
        if (old != bookKeys.end())
            SendMessageW(bookList, LB_SETCURSEL, old - bookKeys.begin(), 0);
        return;
    }
    auto e = notebook.find(selected);
    bool same = bookDraft.key() == selected && bookDraft.scope() == learningScopeKey();
    loadingBookForm = true;
    struct FormGuard {
        ~FormGuard() {
            loadingBookForm = false;
        }
    } guard;
    if (!e || e->deleted) {
        SetWindowTextW(bookDetail, L"");
        SetWindowTextW(bookNote, L"");
        SendMessageW(bookStar, BM_SETCHECK, BST_UNCHECKED, 0);
        SendMessageW(bookKnown, BM_SETCHECK, BST_UNCHECKED, 0);
        bookDraft.load(nullptr, learningScopeKey());
        return;
    }
    auto body = e->source + "\r\n\r\n译文：\r\n" + e->translation + "\r\n\r\n查询次数：" +
                std::to_string(e->hits()) + "  最近：" + dateText(e->last) + "\r\n复习：" +
                dateText(e->due) + "  阶段：" + std::to_string(e->level) + "\r\n来源：" +
                e->engine + "\r\n\r\n保存的用法：\r\n" + e->detail;
    SetWindowTextW(bookDetail, wide(body).c_str());
    if (!same || narrow(text(bookNote)) != e->note)
        SetWindowTextW(bookNote, wide(e->note).c_str());
    SendMessageW(bookStar, BM_SETCHECK, e->star ? BST_CHECKED : BST_UNCHECKED, 0);
    SendMessageW(bookKnown, BM_SETCHECK, e->known ? BST_CHECKED : BST_UNCHECKED, 0);
    bookDraft.load(e, learningScopeKey());
}
static void refreshBook() {
    if (!bookList)
        return;
    if (!saveBookDraft())
        return;
    auto selected = chosenBookKey();
    int mode = (int)SendMessageW(bookSort, CB_GETCURSEL, 0, 0);
    bookKeys =
        notebook.sorted(narrow(text(bookFilter)), mode == 1, mode == 2, mode == 3, unixMillis());
    SendMessageW(bookList, WM_SETREDRAW, FALSE, 0);
    SendMessageW(bookList, LB_RESETCONTENT, 0, 0);
    int selection = -1;
    for (size_t i = 0; i < bookKeys.size(); ++i) {
        auto e = notebook.find(bookKeys[i]);
        auto source = e->source;
        std::replace(source.begin(), source.end(), '\n', ' ');
        std::replace(source.begin(), source.end(), '\r', ' ');
        auto label = (e->star ? L"★ " : L"") + wide(source);
        if (label.size() > 65)
            label = label.substr(0, 65) + L"…";
        label += L"  [" + std::to_wstring(e->hits()) + L"]";
        SendMessageW(bookList, LB_ADDSTRING, 0, (LPARAM)label.c_str());
        if (bookKeys[i] == selected)
            selection = (int)i;
    }
    if (selection < 0 && !bookKeys.empty())
        selection = 0;
    SendMessageW(bookList, LB_SETCURSEL, selection, 0);
    SendMessageW(bookList, WM_SETREDRAW, TRUE, 0);
    InvalidateRect(bookList, nullptr, TRUE);
    showBookEntry();
    bookMessage(bookReady ? std::to_string(bookKeys.size()) + " 条" : "读取失败：" + learningError);
}
static void showNotebook() {
    ensureNotebookLoaded();
    if (!ensureToolWindow(notebookWindow, L"QuietTranslate.Notebook", L"生词本", 850, 720, true))
        return;
    fitLearningWindow(notebookWindow);
    SendMessageW(bookHistory, BM_SETCHECK, historyEnabled ? BST_CHECKED : BST_UNCHECKED, 0);
    SendMessageW(bookSentences, BM_SETCHECK, sentenceHistory ? BST_CHECKED : BST_UNCHECKED, 0);
    refreshBook();
    ShowWindow(notebookWindow, SW_SHOW);
    SetForegroundWindow(notebookWindow);
    SetFocus(bookFilter);
}
static void exportBook() {
    if (!saveBookDraft())
        throw std::runtime_error("笔记草稿未保存，请复制保留或撤销编辑，再导出。");
    if (!bookReady)
        throw std::runtime_error("生词本未加载，拒绝导出空文件。");
    wchar_t path[32768] = L"QuietTranslate-learning.json";
    OPENFILENAMEW of{};
    of.lStructSize = sizeof(of);
    of.hwndOwner = notebookWindow;
    of.lpstrFilter = L"JSON 文件\0*.json\0\0";
    of.lpstrFile = path;
    of.nMaxFile = 32768;
    of.lpstrDefExt = L"json";
    of.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    of.lpstrTitle = L"导出生词本（明文，包含查询原文、译文、笔记）";
    if (!GetSaveFileNameW(&of))
        return;
    qt::Notebook output;
    for (const auto &v : notebook.entries())
        if (!v.second.deleted)
            output.merge(v.second);
    atomicBytes(path, output.json());
    bookMessage("已导出");
}
static void importBackup() {
    if (!bookReady || !saveBookDraft())
        throw std::runtime_error("请先加载生词本并处理未保存的草稿。");
    wchar_t path[32768]{};
    OPENFILENAMEW of{};
    of.lStructSize = sizeof(of);
    of.hwndOwner = notebookWindow;
    of.lpstrFilter = L"生词本备份\0*.json;*.bin\0JSON\0*.json\0加密生词本\0*.bin\0\0";
    of.lpstrFile = path;
    of.nMaxFile = 32768;
    of.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    of.lpstrTitle = L"导入生词本";
    if (!GetOpenFileNameW(&of))
        return;
    auto plain = fileBytes(path, qt::bookLimit + 65536);
    if (plain.compare(0, 8, "QTDATA17") == 0)
        plain = protectedFile(path);
    if (plain.compare(0, 3, "\xef\xbb\xbf") == 0)
        plain.erase(0, 3);
    wide(plain);
    auto incoming = qt::Notebook::parse(plain);
    size_t count = 0;
    for (const auto &v : incoming.entries())
        if (!v.second.deleted) {
            if (hashText(v.second.source) != v.first)
                throw std::runtime_error("备份原文与标识不一致，整批未导入。");
            ++count;
        }
    if (!count)
        throw std::runtime_error("备份没有可导入的有效词条。");
    auto message = "合并 " + std::to_string(count) + " 条记录到本机生词本？";
    if (MessageBoxW(notebookWindow, wide(message).c_str(), APP,
                    MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2) != IDYES)
        return;
    auto changed = notebook.importBatch(incoming);
    changedBook();
    refreshBook();
    bookMessage("已导入 " + std::to_string(count) + " 条，正文或计数变化 " +
                std::to_string(changed) + " 条。");
}
static LRESULT CALLBACK NotebookProc(HWND h, UINT msg, WPARAM w, LPARAM l) {
    switch (msg) {
    case WM_CREATE:
        child(h, L"STATIC", L"生词本", SS_LEFT, 730);
        bookHistory =
            child(h, L"BUTTON", L"自动记录单词 / 短语", BS_AUTOCHECKBOX | WS_TABSTOP, NB_HISTORY);
        bookSentences =
            child(h, L"BUTTON", L"包含整句", BS_AUTOCHECKBOX | WS_TABSTOP, NB_SENTENCES);
        bookFilter = child(h, L"EDIT", L"", ES_AUTOHSCROLL | WS_TABSTOP, NB_FILTER);
        SendMessageW(bookFilter, EM_SETLIMITTEXT, 160, 0);
        SendMessageW(bookFilter, EM_SETCUEBANNER, 0, (LPARAM)L"搜索原文、译文、笔记");
        bookSort = child(h, L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_VSCROLL | WS_TABSTOP, NB_SORT);
        for (auto s : {L"最近查询", L"高频查询", L"我的收藏", L"待复习"})
            SendMessageW(bookSort, CB_ADDSTRING, 0, (LPARAM)s);
        SendMessageW(bookSort, CB_SETCURSEL, 0, 0);
        bookList =
            child(h, L"LISTBOX", L"", LBS_NOTIFY | WS_BORDER | WS_VSCROLL | WS_TABSTOP, NB_LIST);
        bookDetail =
            child(h, L"EDIT", L"",
                  ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL | WS_TABSTOP, NB_DETAIL);
        SendMessageW(bookDetail, EM_SETLIMITTEXT, 60000, 0);
        child(h, L"STATIC", L"笔记", SS_LEFT, 731);
        bookNote = child(h, L"EDIT", L"", ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL | WS_TABSTOP,
                         NB_NOTE);
        SendMessageW(bookNote, EM_SETLIMITTEXT, 2000, 0);
        bookStar = child(h, L"BUTTON", L"收藏", BS_AUTOCHECKBOX | WS_TABSTOP, NB_STAR);
        bookKnown = child(h, L"BUTTON", L"已掌握", BS_AUTOCHECKBOX | WS_TABSTOP, NB_KNOWN);
        for (auto p : {std::pair<int, const wchar_t *>{NB_APPLY, L"保存笔记"},
                       {NB_RECALL, L"记住了"},
                       {NB_FORGET, L"需再复习"},
                       {NB_DELETE, L"删除词条"},
                       {NB_STUDY, L"词典用法"},
                       {NB_SEARCH, L"网页用法"},
                       {NB_EXPORT, L"导出 JSON"},
                       {NB_BACKUP_IMPORT, L"导入备份"},
                       {NB_UNDO, L"撤销编辑"},
                       {NB_CURRENT, L"收藏当前译文"}})
            child(h, L"BUTTON", p.second, BS_PUSHBUTTON | WS_TABSTOP, p.first);
        bookStatus = child(h, L"STATIC", L"", SS_LEFT | SS_ENDELLIPSIS, NB_STATUS);
        return 0;
    case WM_SIZE: {
        RECT r;
        GetClientRect(h, &r);
        int width = MulDiv(r.right, 96, GetDpiForWindow(h)),
            height = MulDiv(r.bottom, 96, GetDpiForWindow(h));
        int left = 260, right = width - left - 38;
        place(GetDlgItem(h, 730), 20, 14, width - 40, 26);
        place(bookHistory, 20, 45, 340, 26);
        place(bookSentences, 380, 45, width - 400, 26);
        place(bookFilter, 20, 82, left - 10, 28);
        place(bookSort, left + 20, 82, right, 160);
        place(bookList, 20, 120, left - 10, height - 276);
        place(bookDetail, left + 20, 120, right, std::max(100, height - 440));
        place(GetDlgItem(h, 731), left + 20, height - 310, right, 24);
        place(bookNote, left + 20, height - 282, right, 78);
        place(bookStar, left + 20, height - 194, 90, 26);
        place(bookKnown, left + 120, height - 194, 100, 26);
        place(GetDlgItem(h, NB_UNDO), left + 240, height - 194, 110, 28);
        const int row1[] = {NB_STUDY, NB_SEARCH, NB_APPLY, NB_DELETE};
        for (int i = 0; i < 4; ++i)
            place(GetDlgItem(h, row1[i]), 20 + i * ((width - 30) / 4), height - 148,
                  (width - 60) / 4, 30);
        const int row2[] = {NB_RECALL, NB_FORGET, NB_EXPORT, NB_CURRENT};
        for (int i = 0; i < 4; ++i)
            place(GetDlgItem(h, row2[i]), 20 + i * ((width - 30) / 4), height - 108,
                  (width - 60) / 4, 30);
        place(GetDlgItem(h, NB_BACKUP_IMPORT), 20, height - 68, 140, 30);
        place(bookStatus, 20, height - 30, width - 40, 25);
        return 0;
    }
    case WM_GETMINMAXINFO:
        ((MINMAXINFO *)l)->ptMinTrackSize = {scale(760), scale(680)};
        return 0;
    case WM_COMMAND:
        try {
            auto id = LOWORD(w);
            auto key = chosenBookKey();
            if ((id == NB_NOTE && HIWORD(w) == EN_CHANGE) || id == NB_STAR || id == NB_KNOWN) {
                if (!loadingBookForm && !bookDraft.key().empty()) {
                    bookDraft.update(narrow(text(bookNote)),
                                     SendMessageW(bookStar, BM_GETCHECK, 0, 0) == BST_CHECKED,
                                     SendMessageW(bookKnown, BM_GETCHECK, 0, 0) == BST_CHECKED);
                    if (bookDraft.dirty()) {
                        SetTimer(host, 10, 900, nullptr);
                        bookMessage("待保存");
                    } else
                        KillTimer(host, 10);
                }
                return 0;
            }
            if (id == NB_UNDO) {
                bookDraft.load(nullptr, learningScopeKey());
                KillTimer(host, 10);
                showBookEntry();
                bookMessage("已撤销未保存编辑");
                return 0;
            }
            if ((id == NB_FILTER && HIWORD(w) == EN_CHANGE) ||
                (id == NB_SORT && HIWORD(w) == CBN_SELCHANGE)) {
                refreshBook();
                return 0;
            }
            if (id == NB_LIST && HIWORD(w) == LBN_SELCHANGE) {
                showBookEntry();
                return 0;
            }

            if (id == NB_CURRENT) {
                saveCurrentTranslation();
                return 0;
            }
            if (id == NB_EXPORT) {
                exportBook();
                return 0;
            }

            if (id == NB_BACKUP_IMPORT) {
                importBackup();
                return 0;
            }
            if (id == NB_HISTORY || id == NB_SENTENCES) {
                bool enabled = SendMessageW(id == NB_HISTORY ? bookHistory : bookSentences,
                                            BM_GETCHECK, 0, 0) == BST_CHECKED;
                if (enabled &&
                    MessageBoxW(h,
                                id == NB_HISTORY ? L"自动保存后续单词/短语查询到本机？"
                                                 : L"同时保存整句原文和译文到本机？",
                                APP, MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2) != IDYES) {
                    SendMessageW(id == NB_HISTORY ? bookHistory : bookSentences, BM_SETCHECK,
                                 BST_UNCHECKED, 0);
                    return 0;
                }
                learningPref(id == NB_HISTORY ? L"History" : L"Sentences", enabled ? L"1" : L"0");
                if (id == NB_HISTORY)
                    historyEnabled = enabled;
                else
                    sentenceHistory = enabled;
                bookMessage("已保存");
                return 0;
            }
            if (id == NB_APPLY || id == NB_RECALL || id == NB_FORGET || id == NB_DELETE ||
                id == NB_STUDY || id == NB_SEARCH) {
                if (!bookReady)
                    throw std::runtime_error("生词本未加载。");
                if (!saveBookDraft())
                    throw std::runtime_error("请先缩短过长笔记，或复制保留后撤销编辑。");
                auto e = notebook.find(key);
                if (!e || e->deleted)
                    throw std::runtime_error("请先选择词条。");
                if (id == NB_STUDY) {
                    showStudy();
                    SetWindowTextW(studyCombo, wide(e->source).c_str());
                    selectStudyWord();
                    return 0;
                }
                if (id == NB_SEARCH) {
                    searchUsage(e->source);
                    return 0;
                }
                if (id == NB_APPLY) {
                    if (flushNotebook()) {
                        refreshBook();
                        bookMessage("已保存");
                    }
                    return 0;
                }
                if (id == NB_RECALL || id == NB_FORGET)
                    notebook.review(key, id == NB_RECALL, learningDevice, unixMillis());
                if (id == NB_DELETE) {
                    if (MessageBoxW(h, L"删除当前词条？", APP,
                                    MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2) != IDYES)
                        return 0;
                    notebook.erase(key, learningDevice, unixMillis());
                }
                changedBook();
                refreshBook();
                return 0;
            }
        } catch (const std::exception &e) {
            MessageBoxW(h, wide(e.what()).c_str(), APP, MB_OK | MB_ICONWARNING);
        }
        break;
    case WM_CLOSE:
        if (!flushNotebook())
            return 0;
        ShowWindow(h, SW_HIDE);
        return 0;
    case WM_DPICHANGED: {
        auto r = (RECT *)l;
        SetWindowPos(h, nullptr, r->left, r->top, r->right - r->left, r->bottom - r->top,
                     SWP_NOZORDER);
        return 0;
    }
    case WM_CTLCOLORSTATIC:
        SetBkMode((HDC)w, TRANSPARENT);
        SetTextColor((HDC)w, RGB(36, 49, 68));
        return (LRESULT)bg;
    }
    return DefWindowProcW(h, msg, w, l);
}
