#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#ifndef UNICODE
#define UNICODE
#endif
#define _UNICODE
#include <windows.h>
#include <shellapi.h>
#include <wincrypt.h>
#include <dwmapi.h>
#include "ocr_engine.hpp"
namespace {
struct OwnedHandle {
    HANDLE h = nullptr;
    ~OwnedHandle() {
        if (h && h != INVALID_HANDLE_VALUE)
            CloseHandle(h);
    }
};
struct Image {
    HDC dc = nullptr;
    HBITMAP bitmap = nullptr;
    HGDIOBJ old = nullptr;
    uint8_t *pixels = nullptr;
    int width, height;
    Image(int w, int h) : width(w), height(h) {
        dc = CreateCompatibleDC(nullptr);
        BITMAPINFO bi{};
        bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bi.bmiHeader.biWidth = w;
        bi.bmiHeader.biHeight = -h;
        bi.bmiHeader.biPlanes = 1;
        bi.bmiHeader.biBitCount = 32;
        bi.bmiHeader.biCompression = BI_RGB;
        if (dc)
            bitmap = CreateDIBSection(dc, &bi, DIB_RGB_COLORS, (void **)&pixels, nullptr, 0);
        if (!dc || !bitmap) {
            if (bitmap)
                DeleteObject(bitmap);
            if (dc)
                DeleteDC(dc);
            dc = nullptr;
            bitmap = nullptr;
            throw std::runtime_error("无法分配 OCR 选区图像。");
        }
        old = SelectObject(dc, bitmap);
        if (!old || old == HGDI_ERROR) {
            DeleteObject(bitmap);
            DeleteDC(dc);
            bitmap = nullptr;
            dc = nullptr;
            throw std::runtime_error("无法选择 OCR 位图。");
        }
    }
    ~Image() {
        if (dc && old && old != HGDI_ERROR)
            SelectObject(dc, old);
        if (bitmap)
            DeleteObject(bitmap);
        if (dc)
            DeleteDC(dc);
    }
};
bool writeAll(HANDLE h, const void *p, DWORD n) {
    auto b = (const char *)p;
    while (n) {
        DWORD written = 0;
        if (!WriteFile(h, b, n, &written, nullptr) || !written)
            return false;
        b += written;
        n -= written;
    }
    return true;
}
void frame(uint32_t type, const std::string &s) {
    uint32_t head[] = {type, (uint32_t)s.size()};
    auto out = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!writeAll(out, head, 8) || !writeAll(out, s.data(), (DWORD)s.size()))
        throw std::runtime_error("OCR 输出通道已关闭。");
}
std::string model() {
    wchar_t exe[32768];
    DWORD len = GetModuleFileNameW(nullptr, exe, 32768);
    if (!len || len >= 32768)
        throw std::runtime_error("无法定位 OCR 程序目录。");
    std::wstring path(exe, len);
    auto slash = path.find_last_of(L"\\/");
    if (slash == std::wstring::npos)
        throw std::runtime_error("无法定位 OCR 英文模型。");
    path.resize(slash + 1);
    path += L"ocr-data\\eng.traineddata";
    OwnedHandle f{CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING,
                              FILE_ATTRIBUTE_NORMAL, nullptr)};
    LARGE_INTEGER size{};
    if (f.h == INVALID_HANDLE_VALUE || !GetFileSizeEx(f.h, &size) || size.QuadPart != 4113088)
        throw std::runtime_error("OCR 英文模型缺失或大小错误。请完整解压 EXE 与 ocr-data 文件夹。");
    std::string data((size_t)size.QuadPart, 0);
    size_t at = 0;
    while (at < data.size()) {
        DWORD n = 0;
        if (!ReadFile(f.h, data.data() + at, (DWORD)std::min<size_t>(65536, data.size() - at), &n,
                      nullptr) ||
            !n)
            throw std::runtime_error("无法完整读取随包 OCR 英文模型。");
        at += n;
    }
    BYTE digest[32];
    DWORD bytes = 32;
    if (!CryptHashCertificate2(L"SHA256", 0, nullptr, (const BYTE *)data.data(), (DWORD)data.size(),
                               digest, &bytes) ||
        bytes != 32)
        throw std::runtime_error("无法验证 OCR 模型完整性。");
    std::string hash;
    const char *hex = "0123456789abcdef";
    for (auto v : digest) {
        hash += hex[v >> 4];
        hash += hex[v & 15];
    }
    if (hash != "7d4322bd2a7749724879683fc3912cb542f19906c83bcc1a52132556427170b2")
        throw std::runtime_error(
            "OCR 模型校验失败，请使用完整原版应用包。不会尝试加载其他模型或下载替代文件。");
    return data;
}
int32_t number(const wchar_t *s) {
    std::string n;
    for (; *s; ++s) {
        if (*s > 127)
            throw std::runtime_error("OCR 坐标含非法字符。");
        n += (char)*s;
    }
    return qt::ocrCoordinate(n);
}
void capture(Image &image, const qt::OcrRegion &r) {
    HDESK input = OpenInputDesktop(0, FALSE, DESKTOP_READOBJECTS);
    if (!input)
        throw std::runtime_error("当前桌面不允许截图，未尝试绕过限制。");
    wchar_t name[128]{};
    DWORD needed = 0;
    bool normal = GetUserObjectInformationW(input, UOI_NAME, name, sizeof(name), &needed) &&
                  _wcsicmp(name, L"Default") == 0;
    CloseDesktop(input);
    if (!normal)
        throw std::runtime_error("OCR 仅用于普通桌面，不处理登录或安全桌面。");
    DwmFlush();
    HDC screen = GetDC(nullptr);
    if (!screen)
        throw std::runtime_error("无法读取当前屏幕。");
    BOOL ok = BitBlt(image.dc, 0, 0, r.width, r.height, screen, r.x, r.y, SRCCOPY | CAPTUREBLT);
    ReleaseDC(nullptr, screen);
    if (!ok)
        throw std::runtime_error("屏幕截图失败；目标程序可能限制捕获。未尝试绕过。");
    GdiFlush();
}
} // namespace
int WINAPI wWinMain(HINSTANCE, HINSTANCE, LPWSTR, int) {
    SetDefaultDllDirectories(LOAD_LIBRARY_SEARCH_SYSTEM32);
    SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    int argc = 0;
    auto argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    bool self = argc == 2 && wcscmp(argv[1], L"--self-test") == 0;
    try {
        qt::OcrRegion region{};
        if (!self) {
            if (argc != 6 || wcscmp(argv[1], L"--capture") != 0)
                throw std::runtime_error("OCR 只能由应用明确框选区域后启动。");
            region = {number(argv[2]), number(argv[3]), number(argv[4]), number(argv[5])};
            int x = GetSystemMetrics(SM_XVIRTUALSCREEN), y = GetSystemMetrics(SM_YVIRTUALSCREEN);
            int64_t right = (int64_t)x + GetSystemMetrics(SM_CXVIRTUALSCREEN),
                    bottom = (int64_t)y + GetSystemMetrics(SM_CYVIRTUALSCREEN);
            if (right > INT32_MAX || bottom > INT32_MAX)
                throw std::runtime_error("屏幕坐标范围无效。");
            qt::validateOcrRegion(region, {x, y, (int32_t)right, (int32_t)bottom});
        } else
            region = {0, 0, 1200, 180};
        LocalFree(argv);
        argv = nullptr;
        qt::OcrGray gray;
        {
            Image image(region.width, region.height);
            if (self) {
                RECT r{0, 0, region.width, region.height};
                FillRect(image.dc, &r, (HBRUSH)GetStockObject(WHITE_BRUSH));
                HFONT font =
                    CreateFontW(-36, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, 0, 0,
                                ANTIALIASED_QUALITY, 0, L"Segoe UI");
                auto old = SelectObject(image.dc, font);
                SetTextColor(image.dc, RGB(0, 0, 0));
                SetBkColor(image.dc, RGB(255, 255, 255));
                const wchar_t *sample = L"The driver waits until the transfer completes.";
                TextOutW(image.dc, 24, 40, sample, (int)wcslen(sample));
                SelectObject(image.dc, old);
                DeleteObject(font);
                GdiFlush();
            } else
                capture(image, region);
            gray = qt::ocrGray(image.pixels, (size_t)region.width * region.height * 4, region.width,
                               region.height);
        } // Free GDI/BGRA storage before loading the OCR model.
        frame(6, "本地 OCR · 已截取框选区域");
        auto result = qt::recognizeEnglish(gray, model());
        frame(5, std::to_string(result.confidence));
        if (self) {
            if (result.text.find("driver waits until the transfer completes") == std::string::npos)
                throw std::runtime_error("Windows OCR 固定字样验证失败。");
            frame(2, "PASS Windows OCR Tesseract/model + GDI-rendered public fixture; no screen, "
                     "clipboard, user files or network used.");
        } else
            frame(1, result.text);
        return 0;
    } catch (const std::exception &e) {
        if (argv)
            LocalFree(argv);
        try {
            frame(3, e.what());
        } catch (...) {
        }
        return 1;
    }
}
