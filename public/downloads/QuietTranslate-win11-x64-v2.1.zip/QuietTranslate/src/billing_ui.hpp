#pragma once
enum {
    BILL_LIST = 1101,
    BILL_DETAIL,
    BILL_SUMMARY,
    BILL_INPUT,
    BILL_OUTPUT,
    BILL_CACHED,
    BILL_CURRENCY,
    BILL_ENABLE,
    BILL_SAVE,
    BILL_REPRICE,
    BILL_EXPORT,
    BILL_CLOSE,
    BILL_CONTEXT
};
static HWND billList, billDetail, billSummary, billInput, billOutput, billCached, billCurrency,
    billEnable, billContext;
static std::string priceScope, priceHost, priceModel;
static std::vector<std::string> billKeys;
static std::string totalBillingText() {
    if (!billingReady)
        return "本地累计不可用：" + billingError + "\r\n旧文件未覆盖；当前 API 翻译仍可使用。";
    auto s = billingBook.stats();
    if (s.overflow)
        return "统计数值过大，无法可靠显示汇总；明细仍保留。";
    std::string text = "本机累计已知 Token：" + std::to_string(s.total) + "（输入 " +
                       std::to_string(s.input) + " / 输出 " + std::to_string(s.output) + "）\r\n";
    text += "估算费用：CNY " + qt::moneyText(s.cny) + "；USD " + qt::moneyText(s.usd) + "\r\n";
    text += "API 尝试 " + std::to_string(s.attempts) + " 次 · 用量不完整/未知 " +
            std::to_string(s.missing) + " 次 · 未纳入费用 " + std::to_string(s.unpriced) +
            " 次 · 失败/未完成 " + std::to_string(s.failed + s.cancelled) + " 次";
    if (!billingError.empty())
        text += "\r\n本地保存失败，以下累计可能尚未刷盘：" + billingError;
    return text;
}
static void showBillEntry() {
    int index = (int)SendMessageW(billList, LB_GETCURSEL, 0, 0);
    if (index < 0 || (size_t)index >= billKeys.size())
        return;
    auto e = billingBook.find(billKeys[index]);
    if (!e)
        return;
    std::string info = dateText(e->at) + " · " + qt::billPurpose(e->purpose) + " · " +
                       qt::billState(e->state) + "\r\n" + e->host + " / " + e->model + "\r\n" +
                       qt::billText(*e);
    if (e->usage.cachedKnown)
        info += "\r\n服务缓存命中输入 Token：" + std::to_string(e->usage.cached) + "";
    if (e->rate.enabled) {
        info += "\r\n本次单价快照（" + e->rate.currency + " / 百万 Token）：输入 " +
                qt::decimalMicros(e->rate.input) + "，输出 " + qt::decimalMicros(e->rate.output);
        if (e->rate.cachedEnabled)
            info += "，缓存输入 " + qt::decimalMicros(e->rate.cached);
    } else
        info += "\r\n本次未设置单价。";
    if (e->state != qt::BillState::Success && e->state != qt::BillState::Cache &&
        e->state != qt::BillState::NotSent)
        info += "\r\n请求未完成，服务端可能继续计费。";
    SetWindowTextW(billDetail, wide(info).c_str());
}
static void refreshBillingWindow() {
    if (!billingWindow || !billList)
        return;
    SetWindowTextW(billSummary, wide(totalBillingText()).c_str());
    if (!IsWindowVisible(billingWindow))
        return;
    std::string selected;
    int old = (int)SendMessageW(billList, LB_GETCURSEL, 0, 0);
    if (old >= 0 && (size_t)old < billKeys.size())
        selected = billKeys[old];
    billKeys.clear();
    SendMessageW(billList, WM_SETREDRAW, FALSE, 0);
    SendMessageW(billList, LB_RESETCONTENT, 0, 0);
    int choose = 0;
    const auto &entries = billingBook.entries();
    for (auto i = entries.rbegin(); i != entries.rend(); ++i) {
        auto text = dateText(i->at) + " · " + qt::billPurpose(i->purpose) + " · " + i->model +
                    " · " + qt::billState(i->state);
        if (i->id == selected)
            choose = (int)billKeys.size();
        billKeys.push_back(i->id);
        SendMessageW(billList, LB_ADDSTRING, 0, (LPARAM)wide(text).c_str());
    }
    SendMessageW(billList, LB_SETCURSEL, choose, 0);
    SendMessageW(billList, WM_SETREDRAW, TRUE, 0);
    InvalidateRect(billList, nullptr, TRUE);
    showBillEntry();
}
static void showBilling(const std::string &base, const std::string &model) {
    try {
        loadBilling();
        if (!ensureToolWindow(billingWindow, L"QuietTranslate.Billing", L"用量 / 费用", 850, 700,
                              true))
            return;
        auto endpoint = qt::endpoint(base.empty() ? apiConfig.base : base);
        priceModel = qt::trim(model.empty() ? apiConfig.model : model);
        if (!qt::modelId(priceModel))
            throw std::runtime_error("请先填写有效模型 ID。");
        priceScope = billingScope(endpoint.base, priceModel);
        priceHost = endpoint.host;
        qt::BillingRate rate;
        if (auto p = billingBook.profile(priceScope))
            rate = p->rate;
        SetWindowTextW(billContext,
                       wide("单价范围：" + priceHost + " / " + priceModel + "").c_str());
        SendMessageW(billEnable, BM_SETCHECK, rate.enabled ? BST_CHECKED : BST_UNCHECKED, 0);
        SendMessageW(billCurrency, CB_SETCURSEL, rate.currency == "USD" ? 1 : 0, 0);
        SetWindowTextW(billInput, rate.enabled ? wide(qt::decimalMicros(rate.input)).c_str() : L"");
        SetWindowTextW(billOutput,
                       rate.enabled ? wide(qt::decimalMicros(rate.output)).c_str() : L"");
        SetWindowTextW(billCached,
                       rate.cachedEnabled ? wide(qt::decimalMicros(rate.cached)).c_str() : L"");
        fitLearningWindow(billingWindow);
        ShowWindow(billingWindow, SW_SHOW);
        refreshBillingWindow();
        SetForegroundWindow(billingWindow);
    } catch (const std::exception &e) {
        MessageBoxW(popup, wide(e.what()).c_str(), APP, MB_OK | MB_ICONWARNING);
    }
}
static std::string billingCsvField(std::string s) {
    if (!s.empty() && (s[0] == '=' || s[0] == '+' || s[0] == '-' || s[0] == '@'))
        s = "'" + s;
    std::string out = "\"";
    for (char c : s) {
        if (c == '"')
            out += '"';
        out += c;
    }
    return out + '"';
}
static void exportBilling() {
    if (!billingReady)
        throw std::runtime_error("本地用量文件未加载，拒绝导出误导性的空记录。");
    wchar_t path[32768] = L"QuietTranslate-api-usage.csv";
    OPENFILENAMEW of{};
    of.lStructSize = sizeof(of);
    of.hwndOwner = billingWindow;
    of.lpstrFilter = L"CSV 文件\0*.csv\0\0";
    of.lpstrFile = path;
    of.nMaxFile = 32768;
    of.lpstrDefExt = L"csv";
    of.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    if (!GetSaveFileNameW(&of))
        return;
    std::string csv =
        "\xef\xbb\xbf时间,服务,模型,用途,状态,输入Token,输出Token,总Token,币种,估算费用\r\n";
    auto token = [](bool k, uint64_t v) { return k ? std::to_string(v) : std::string("未知"); };
    for (const auto &e : billingBook.entries()) {
        uint64_t cost = 0;
        bool free = e.state == qt::BillState::Cache || e.state == qt::BillState::NotSent;
        bool priced = !free && e.rate.cost(e.usage, cost);
        std::vector<std::string> values = {
            dateText(e.at),
            e.host,
            e.model,
            qt::billPurpose(e.purpose),
            qt::billState(e.state),
            token(free || (!e.usage.invalid && e.usage.inputKnown), e.usage.input),
            token(free || (!e.usage.invalid && e.usage.outputKnown), e.usage.output),
            token(free || (!e.usage.invalid && e.usage.totalKnown), e.usage.total),
            priced ? e.rate.currency : "",
            priced ? qt::moneyText(cost)
            : free ? "0.000000"
                   : "未知/未计价"};
        for (size_t i = 0; i < values.size(); ++i) {
            if (i)
                csv += ',';
            csv += billingCsvField(values[i]);
        }
        csv += "\r\n";
    }
    auto stats = billingBook.stats();
    csv += "\r\n累计已知Token," + std::to_string(stats.total) + "\r\n估算CNY," +
           (stats.overflow ? std::string("无法可靠汇总") : qt::moneyText(stats.cny)) +
           "\r\n估算USD," +
           (stats.overflow ? std::string("无法可靠汇总") : qt::moneyText(stats.usd)) +
           "\r\n未纳入费用的请求," + std::to_string(stats.unpriced) +
           "\r\n说明,\"最近2000条明细与历史累计；估算非账单；币种不混加；不含原文译文或Key\"\r\n";
    atomicBytes(path, csv);
}
static LRESULT CALLBACK BillingProc(HWND h, UINT msg, WPARAM w, LPARAM l) {
    switch (msg) {
    case WM_CREATE:
        billSummary = child(h, L"EDIT", L"",
                            ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL | WS_TABSTOP,
                            BILL_SUMMARY);
        billContext = child(h, L"STATIC", L"", SS_LEFT | SS_ENDELLIPSIS, BILL_CONTEXT);
        billEnable = child(h, L"BUTTON", L"估算费用（单价 / 百万 Token）",
                           BS_AUTOCHECKBOX | WS_TABSTOP, BILL_ENABLE);
        billCurrency = child(h, L"COMBOBOX", L"", CBS_DROPDOWNLIST | WS_TABSTOP, BILL_CURRENCY);
        for (auto s : {L"CNY 人民币", L"USD 美元"})
            SendMessageW(billCurrency, CB_ADDSTRING, 0, (LPARAM)s);
        SendMessageW(billCurrency, CB_SETCURSEL, 0, 0);
        for (auto p : {std::pair<int, const wchar_t *>{1160, L"输入单价"},
                       {1161, L"输出单价"},
                       {1162, L"缓存输入（可选）"}})
            child(h, L"STATIC", p.second, SS_LEFT, p.first);
        billInput = child(h, L"EDIT", L"", ES_AUTOHSCROLL | WS_TABSTOP, BILL_INPUT);
        billOutput = child(h, L"EDIT", L"", ES_AUTOHSCROLL | WS_TABSTOP, BILL_OUTPUT);
        billCached = child(h, L"EDIT", L"", ES_AUTOHSCROLL | WS_TABSTOP, BILL_CACHED);
        for (HWND input : {billInput, billOutput, billCached})
            SendMessageW(input, EM_SETLIMITTEXT, 18, 0);
        child(h, L"BUTTON", L"保存本模型单价", BS_PUSHBUTTON | WS_TABSTOP, BILL_SAVE);
        child(h, L"BUTTON", L"补算本模型未定价明细", BS_PUSHBUTTON | WS_TABSTOP, BILL_REPRICE);
        billList =
            child(h, L"LISTBOX", L"", LBS_NOTIFY | WS_BORDER | WS_VSCROLL | WS_TABSTOP, BILL_LIST);
        billDetail = child(h, L"EDIT", L"",
                           ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL | WS_TABSTOP,
                           BILL_DETAIL);
        child(h, L"BUTTON", L"导出 CSV", BS_PUSHBUTTON | WS_TABSTOP, BILL_EXPORT);
        child(h, L"BUTTON", L"关闭", BS_PUSHBUTTON | WS_TABSTOP, BILL_CLOSE);
        return 0;
    case WM_SIZE: {
        RECT r;
        GetClientRect(h, &r);
        int width = MulDiv(r.right, 96, GetDpiForWindow(h)),
            height = MulDiv(r.bottom, 96, GetDpiForWindow(h));
        place(billSummary, 20, 16, width - 40, 94);
        place(billContext, 20, 120, width - 40, 25);
        place(billEnable, 20, 153, width - 230, 28);
        place(billCurrency, width - 205, 151, 185, 140);
        place(GetDlgItem(h, 1160), 20, 195, 150, 24);
        place(GetDlgItem(h, 1161), 190, 195, 150, 24);
        place(GetDlgItem(h, 1162), 360, 195, width - 380, 24);
        place(billInput, 20, 223, 150, 28);
        place(billOutput, 190, 223, 150, 28);
        place(billCached, 360, 223, 180, 28);
        place(GetDlgItem(h, BILL_SAVE), 20, 264, 180, 30);
        place(GetDlgItem(h, BILL_REPRICE), 214, 264, 250, 30);
        int listHeight = std::max(100, (height - 430) / 2);
        place(billList, 20, 308, width - 40, listHeight);
        place(billDetail, 20, 320 + listHeight, width - 40,
              std::max(100, height - 376 - listHeight));
        place(GetDlgItem(h, BILL_EXPORT), 20, height - 44, 150, 30);
        place(GetDlgItem(h, BILL_CLOSE), width - 120, height - 44, 100, 30);
        return 0;
    }
    case WM_GETMINMAXINFO:
        ((MINMAXINFO *)l)->ptMinTrackSize = {scale(780), scale(690)};
        return 0;
    case WM_COMMAND:
        try {
            switch (LOWORD(w)) {
            case BILL_LIST:
                if (HIWORD(w) == LBN_SELCHANGE)
                    showBillEntry();
                return 0;
            case BILL_SAVE: {
                if (!billingReady)
                    throw std::runtime_error("用量文件未安全加载，未改动旧文件。");
                qt::BillingRate rate;
                rate.enabled = SendMessageW(billEnable, BM_GETCHECK, 0, 0) == BST_CHECKED;
                rate.currency = SendMessageW(billCurrency, CB_GETCURSEL, 0, 0) == 1 ? "USD" : "CNY";
                if (rate.enabled) {
                    rate.input = qt::priceMicros(narrow(text(billInput)));
                    rate.output = qt::priceMicros(narrow(text(billOutput)));
                    auto cached = qt::trim(narrow(text(billCached)));
                    rate.cachedEnabled = !cached.empty();
                    if (rate.cachedEnabled)
                        rate.cached = qt::priceMicros(cached);
                }
                billingBook.setPrice({priceScope, priceHost, priceModel, rate});
                billingChanged();
                if (!flushBilling())
                    throw std::runtime_error("单价尚未保存到本机：" + billingError);
                refreshBillingWindow();
                SetWindowTextW(billDetail, L"单价已保存");
                return 0;
            }
            case BILL_REPRICE: {
                if (!billingReady)
                    throw std::runtime_error("用量文件未加载。");
                if (MessageBoxW(h, L"按当前单价补算本模型的未定价明细？", APP,
                                MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2) != IDYES)
                    return 0;
                auto n = billingBook.reprice(priceScope);
                billingChanged();
                flushBilling();
                refreshBillingWindow();
                SetWindowTextW(
                    billDetail,
                    wide("已为 " + std::to_string(n) + " 条保留明细设置估算单价。").c_str());
                return 0;
            }
            case BILL_EXPORT:
                exportBilling();
                return 0;
            case BILL_CLOSE:
                flushBilling();
                ShowWindow(h, SW_HIDE);
                return 0;
            }
        } catch (const std::exception &e) {
            MessageBoxW(h, wide(e.what()).c_str(), APP, MB_OK | MB_ICONWARNING);
        }
        break;
    case WM_CLOSE:
        flushBilling();
        ShowWindow(h, SW_HIDE);
        return 0;
    case WM_DPICHANGED: {
        auto r = (RECT *)l;
        SetWindowPos(h, nullptr, r->left, r->top, r->right - r->left, r->bottom - r->top,
                     SWP_NOZORDER);
        return 0;
    }
    case WM_CTLCOLORSTATIC:
        SetBkMode((HDC)w, TRANSPARENT);
        SetTextColor((HDC)w, RGB(36, 49, 68));
        return (LRESULT)bg;
    }
    return DefWindowProcW(h, msg, w, l);
}
