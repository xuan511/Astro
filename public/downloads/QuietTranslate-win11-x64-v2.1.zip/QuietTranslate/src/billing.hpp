#pragma once
#include "notebook.hpp"
#include <deque>
#include <limits>
namespace qt {
inline uint64_t billingCounter(const Json &j) {
    if (j.kind != Json::Number || j.text.empty() || j.text.size() > 20)
        throw std::runtime_error("用量汇总数值无效。");
    uint64_t n = 0;
    for (char c : j.text) {
        if (c < '0' || c > '9' || n > (UINT64_MAX - (c - '0')) / 10)
            throw std::runtime_error("用量汇总数值越界。");
        n = n * 10 + c - '0';
    }
    return n;
}
constexpr size_t billingKeep = 2000, billingFileLimit = 4 * 1024 * 1024;
inline uint64_t priceMicros(const std::string &input) {
    auto s = trim(input);
    if (s.empty() || s.size() > 18)
        throw std::runtime_error("请填写每百万 Token 单价，最多 6 位小数。");
    uint64_t whole = 0, fraction = 0;
    unsigned digits = 0;
    bool dot = false, any = false;
    for (char c : s) {
        if (c == '.' && !dot) {
            dot = true;
            continue;
        }
        if (c < '0' || c > '9')
            throw std::runtime_error("单价只接受非负数字和小数点。");
        any = true;
        if (dot) {
            if (++digits > 6)
                throw std::runtime_error("单价最多 6 位小数。");
            fraction = fraction * 10 + c - '0';
        } else {
            whole = whole * 10 + c - '0';
            if (whole > 10000)
                throw std::runtime_error("单价上限为每百万 Token 10000。");
        }
    }
    if (!any || (whole == 10000 && fraction))
        throw std::runtime_error("单价无效或超过上限。");
    while (digits++ < 6)
        fraction *= 10;
    return whole * 1000000 + fraction;
}
inline std::string decimalMicros(uint64_t value) {
    auto fraction = std::to_string(value % 1000000);
    return std::to_string(value / 1000000) + "." + std::string(6 - fraction.size(), '0') + fraction;
}
inline std::string moneyText(uint64_t pico) {
    if (pico && pico < 1000000)
        return "<0.000001";
    return decimalMicros(pico / 1000000 + (pico % 1000000 >= 500000));
}
struct BillingRate {
    bool enabled = false, cachedEnabled = false;
    std::string currency = "CNY";
    uint64_t input = 0, output = 0, cached = 0;
    std::string json() const {
        return "{\"enabled\":" + std::string(enabled ? "true" : "false") +
               ",\"currency\":" + jsonString(currency) + ",\"input\":" + std::to_string(input) +
               ",\"output\":" + std::to_string(output) +
               ",\"cached_enabled\":" + (cachedEnabled ? "true" : "false") +
               ",\"cached\":" + std::to_string(cached) + "}";
    }
    static BillingRate parse(const Json &j) {
        BillingRate r;
        r.enabled = fieldBool(j, "enabled");
        r.cachedEnabled = fieldBool(j, "cached_enabled");
        r.currency = fieldString(j, "currency", 3);
        if (r.currency != "CNY" && r.currency != "USD")
            throw std::runtime_error("计价币种无效。");
        r.input = natural(j.at("input"), 10000000000ULL);
        r.output = natural(j.at("output"), 10000000000ULL);
        r.cached = natural(j.at("cached"), 10000000000ULL);
        return r;
    }
    bool cost(const ApiUsage &u, uint64_t &amount) const {
        if (!enabled || !u.full())
            return false;
        if (u.cachedKnown && u.cached > u.input)
            return false;
        uint64_t cachedCount = u.cachedKnown ? u.cached : 0;
        auto checked = [](uint64_t a, uint64_t b, uint64_t &result) {
            if (b && a > UINT64_MAX / b)
                return false;
            result = a * b;
            return true;
        };
        uint64_t a, b, c;
        if (!checked(u.input - cachedCount, input, a) ||
            !checked(cachedCount, cachedEnabled ? cached : input, b) ||
            !checked(u.output, output, c))
            return false;
        if (a > UINT64_MAX - b || a + b > UINT64_MAX - c)
            return false;
        amount = a + b + c;
        return true;
    }
};
enum class BillState {
    Pending = 0,
    Success = 1,
    Failed = 2,
    Cancelled = 3,
    Cache = 4,
    Interrupted = 5,
    NotSent = 6
};
struct BillEntry {
    std::string id, scope, host, model;
    uint64_t at = 0;
    unsigned purpose = 0;
    BillState state = BillState::Pending;
    bool started = false;
    ApiUsage usage;
    BillingRate rate;
    std::string json() const {
        return "{\"id\":" + jsonString(id) + ",\"scope\":" + jsonString(scope) +
               ",\"host\":" + jsonString(host) + ",\"model\":" + jsonString(model) +
               ",\"at\":" + std::to_string(at) + ",\"purpose\":" + std::to_string(purpose) +
               ",\"state\":" + std::to_string((int)state) +
               ",\"started\":" + (started ? "true" : "false") + ",\"usage\":" + usage.json() +
               ",\"rate\":" + rate.json() + "}";
    }
    static BillEntry parse(const Json &j) {
        BillEntry e;
        e.id = fieldString(j, "id", 36);
        e.scope = fieldString(j, "scope", 64);
        e.host = fieldString(j, "host", 253);
        e.model = fieldString(j, "model", 200);
        if (!uuidText(e.id) || !hexText(e.scope, 64) || !modelId(e.model))
            throw std::runtime_error("用量记录标识无效。");
        e.at = natural(j.at("at"));
        e.purpose = (unsigned)natural(j.at("purpose"), 2);
        e.state = (BillState)natural(j.at("state"), 6);
        e.started = fieldBool(j, "started");
        e.usage = ApiUsage::parse(j.at("usage"));
        e.rate = BillingRate::parse(j.at("rate"));
        return e;
    }
};
struct BillingStats {
    uint64_t attempts = 0, success = 0, failed = 0, cancelled = 0, cache = 0, notSent = 0,
             input = 0, output = 0, total = 0, missing = 0, unpriced = 0, cny = 0, usd = 0;
    bool overflow = false;
    void addNumber(uint64_t &to, uint64_t n) {
        if (to > UINT64_MAX - n) {
            overflow = true;
            to = UINT64_MAX;
        } else
            to += n;
    }
    void add(const BillEntry &e) {
        if (e.state == BillState::Cache) {
            ++cache;
            return;
        }
        if (e.state == BillState::NotSent) {
            ++notSent;
            return;
        }
        ++attempts;
        if (e.state == BillState::Success)
            ++success;
        else if (e.state == BillState::Failed)
            ++failed;
        else if (e.state == BillState::Cancelled || e.state == BillState::Interrupted ||
                 e.state == BillState::Pending)
            ++cancelled;
        if (!e.usage.invalid) {
            if (e.usage.inputKnown)
                addNumber(input, e.usage.input);
            if (e.usage.outputKnown)
                addNumber(output, e.usage.output);
            if (e.usage.totalKnown)
                addNumber(total, e.usage.total);
            else
                addNumber(total, (e.usage.inputKnown ? e.usage.input : 0) +
                                     (e.usage.outputKnown ? e.usage.output : 0));
        }
        if (!e.usage.full())
            ++missing;
        uint64_t cost = 0;
        if (e.rate.cost(e.usage, cost))
            addNumber(e.rate.currency == "USD" ? usd : cny, cost);
        else
            ++unpriced;
    }
    std::string json() const {
        std::string s = "{";
        auto put = [&](const char *k, uint64_t n) {
            if (s.size() > 1)
                s += ',';
            s += jsonString(k) + ":" + std::to_string(n);
        };
        put("attempts", attempts);
        put("success", success);
        put("failed", failed);
        put("cancelled", cancelled);
        put("cache", cache);
        put("not_sent", notSent);
        put("input", input);
        put("output", output);
        put("total", total);
        put("missing", missing);
        put("unpriced", unpriced);
        put("cny", cny);
        put("usd", usd);
        s += ",\"overflow\":" + std::string(overflow ? "true" : "false") + "}";
        return s;
    }
    static BillingStats parse(const Json &j) {
        BillingStats s;
        auto get = [&](const char *k) { return billingCounter(j.at(k)); };
        s.attempts = get("attempts");
        s.success = get("success");
        s.failed = get("failed");
        s.cancelled = get("cancelled");
        s.cache = get("cache");
        s.notSent = get("not_sent");
        s.input = get("input");
        s.output = get("output");
        s.total = get("total");
        s.missing = get("missing");
        s.unpriced = get("unpriced");
        s.cny = get("cny");
        s.usd = get("usd");
        s.overflow = fieldBool(j, "overflow");
        return s;
    }
};
struct RateProfile {
    std::string scope, host, model;
    BillingRate rate;
};
class BillingBook {
    std::deque<BillEntry> rows;
    std::map<std::string, RateProfile> prices;
    BillingStats archived;
    void trimHistory() {
        while (rows.size() > billingKeep) {
            auto i = std::find_if(rows.begin(), rows.end(),
                                  [](const auto &e) { return e.state != BillState::Pending; });
            if (i == rows.end())
                throw std::runtime_error("未完成用量记录过多。");
            archived.add(*i);
            rows.erase(i);
        }
    }

  public:
    const std::deque<BillEntry> &entries() const {
        return rows;
    }
    const RateProfile *profile(const std::string &scope) const {
        auto i = prices.find(scope);
        return i == prices.end() ? nullptr : &i->second;
    }
    void setPrice(const RateProfile &p) {
        if (!hexText(p.scope, 64) || p.host.size() > 253 || !modelId(p.model))
            throw std::runtime_error("价格配置范围无效。");
        BillingRate::parse(Parser(p.rate.json()).parse());
        if (!prices.count(p.scope) && prices.size() >= 128)
            throw std::runtime_error("最多保存 128 套模型单价。");
        prices[p.scope] = p;
    }
    void begin(BillEntry e) {
        if (find(e.id))
            throw std::runtime_error("重复的用量记录。");
        e.state = BillState::Pending;
        e.started = false;
        e.usage = {};
        auto p = profile(e.scope);
        e.rate = p ? p->rate : BillingRate{};
        rows.push_back(std::move(e));
        trimHistory();
    }
    BillEntry *find(const std::string &id) {
        for (auto &e : rows)
            if (e.id == id)
                return &e;
        return nullptr;
    }
    const BillEntry *find(const std::string &id) const {
        for (const auto &e : rows)
            if (e.id == id)
                return &e;
        return nullptr;
    }
    void started(const std::string &id) {
        auto e = find(id);
        if (e && e->state == BillState::Pending)
            e->started = true;
    }
    void observe(const std::string &id, const ApiUsage &u) {
        auto e = find(id);
        if (e && e->state == BillState::Pending && u.any()) {
            e->usage = u;
            e->started = true;
        }
    }
    void finish(const std::string &id, BillState state) {
        auto e = find(id);
        if (!e || e->state != BillState::Pending)
            return;
        if (!e->started && (state == BillState::Failed || state == BillState::Success))
            state = BillState::NotSent;
        e->state = state;
        if (state == BillState::Cache || state == BillState::NotSent)
            e->usage = {};
    }
    size_t reprice(const std::string &scope) {
        auto p = profile(scope);
        if (!p || !p->rate.enabled)
            throw std::runtime_error("请先保存该模型单价。");
        size_t n = 0;
        for (auto &e : rows)
            if (e.scope == scope && !e.rate.enabled && e.state != BillState::Pending &&
                e.state != BillState::Cache && e.state != BillState::NotSent) {
                e.rate = p->rate;
                ++n;
            }
        return n;
    }
    BillingStats stats() const {
        auto s = archived;
        for (const auto &e : rows)
            s.add(e);
        return s;
    }
    std::string json() const {
        std::string s = "{\"schema\":1,\"archive\":" + archived.json() + ",\"prices\":[";
        bool first = true;
        for (const auto &p : prices) {
            if (!first)
                s += ',';
            first = false;
            s += "{\"scope\":" + jsonString(p.second.scope) +
                 ",\"host\":" + jsonString(p.second.host) +
                 ",\"model\":" + jsonString(p.second.model) + ",\"rate\":" + p.second.rate.json() +
                 "}";
        }
        s += "],\"entries\":[";
        first = true;
        for (const auto &e : rows) {
            if (!first)
                s += ',';
            first = false;
            s += e.json();
        }
        s += "]}";
        if (s.size() > billingFileLimit)
            throw std::runtime_error("用量记录超过 4 MiB，未覆盖旧文件。");
        return s;
    }
    static BillingBook parse(const std::string &text) {
        auto j = Parser(text, billingFileLimit).parse();
        if (natural(j.at("schema"), 1) != 1)
            throw std::runtime_error("用量记录版本无效。");
        BillingBook b;
        b.archived = BillingStats::parse(j.at("archive"));
        auto &p = j.at("prices");
        auto &a = j.at("entries");
        if (p.kind != Json::Array || p.array.size() > 128 || a.kind != Json::Array ||
            a.array.size() > billingKeep + 8)
            throw std::runtime_error("用量记录容量无效。");
        for (const auto &v : p.array) {
            RateProfile r{fieldString(v, "scope", 64), fieldString(v, "host", 253),
                          fieldString(v, "model", 200), BillingRate::parse(v.at("rate"))};
            b.setPrice(r);
        }
        std::set<std::string> ids;
        for (const auto &v : a.array) {
            auto e = BillEntry::parse(v);
            if (!ids.insert(e.id).second)
                throw std::runtime_error("重复用量记录。");
            if (e.state == BillState::Pending)
                e.state = BillState::Interrupted;
            b.rows.push_back(std::move(e));
        }
        b.trimHistory();
        return b;
    }
};
inline std::string billPurpose(unsigned p) {
    return p == 1 ? "词典中文补充" : p == 2 ? "短句测试" : "正文翻译";
}
inline std::string billState(BillState s) {
    switch (s) {
    case BillState::Success:
        return "完成";
    case BillState::Failed:
        return "失败";
    case BillState::Cancelled:
        return "取消";
    case BillState::Cache:
        return "本地缓存";
    case BillState::Interrupted:
        return "上次未完整结束";
    case BillState::NotSent:
        return "未发起 API";
    default:
        return "等待接口结果";
    }
}
inline std::string billText(const BillEntry &e) {
    if (e.state == BillState::Cache || e.state == BillState::NotSent)
        return "本次 " + billState(e.state) + " · 新增 Token 0 · 新增费用 0";
    auto token = [](bool known, uint64_t n) {
        return known ? std::to_string(n) : std::string("未知");
    };
    std::string s = "输入 " + token(!e.usage.invalid && e.usage.inputKnown, e.usage.input) +
                    " / 输出 " + token(!e.usage.invalid && e.usage.outputKnown, e.usage.output) +
                    " / 总 " + token(!e.usage.invalid && e.usage.totalKnown, e.usage.total) +
                    " Token";
    uint64_t cost = 0;
    if (e.rate.cost(e.usage, cost))
        s += " · 估算 " + e.rate.currency + " " + moneyText(cost);
    else
        s += e.usage.full() ? " · 单价未设置/无法计算费用" : " · 费用未知（可能计费）";
    return s;
}
} // namespace qt
