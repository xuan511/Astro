#pragma once
// Included after captureCopied, native capture wrappers and UIA Com helpers.
struct CopyTarget {
    HWND top = nullptr, focus = nullptr;
    DWORD topPid = 0, focusPid = 0, thread = 0;
    explicit CopyTarget(HWND h) : top(h) {
        if (!top || GetForegroundWindow() != top)
            throw std::runtime_error("前台已变化，未发送复制按键。");
        thread = GetWindowThreadProcessId(top, &topPid);
        GUITHREADINFO g{};
        g.cbSize = sizeof(g);
        if (!thread || !GetGUIThreadInfo(thread, &g) || !withinTarget(top, g.hwndFocus))
            throw std::runtime_error("无法确认文本焦点，未发送复制按键。");
        focus = g.hwndFocus;
        GetWindowThreadProcessId(focus, &focusPid);
        verify();
    }
    void verify() const {
        DWORD pid = 0, fp = 0;
        GUITHREADINFO g{};
        g.cbSize = sizeof(g);
        if (GetForegroundWindow() != top || !GetGUIThreadInfo(thread, &g) || g.hwndFocus != focus ||
            (g.flags & (GUI_INMENUMODE | GUI_POPUPMENUMODE | GUI_SYSTEMMENUMODE)) ||
            !GetWindowThreadProcessId(top, &pid) || !GetWindowThreadProcessId(focus, &fp) ||
            pid != topPid || fp != focusPid || !withinTarget(top, focus))
            throw std::runtime_error("前台或文本焦点变化，已取消复制取词。");
    }
};
static bool belongsTo(IUIAutomation *uia, IUIAutomationElement *element, HWND top) {
    Com<IUIAutomationTreeWalker> walker;
    if (FAILED(uia->get_RawViewWalker(walker.put())))
        return false;
    Com<IUIAutomationElement> current;
    element->AddRef();
    current.p = element;
    for (int i = 0; i < 48 && current; ++i) {
        BOOL password = FALSE;
        if (FAILED(current->get_CurrentIsPassword(&password)) || password)
            return false;
        UIA_HWND hwnd = nullptr;
        if (SUCCEEDED(current->get_CurrentNativeWindowHandle(&hwnd)) && hwnd) {
            if ((HWND)hwnd == top)
                return true;
            if (!withinTarget(top, (HWND)hwnd))
                return false;
        }
        Com<IUIAutomationElement> parent;
        if (FAILED(walker->GetParentElement(current.p, parent.put())))
            return false;
        current.p->Release();
        current.p = parent.p;
        parent.p = nullptr;
    }
    return false;
}
static std::wstring processBase(DWORD pid) {
    // Only query the active process image NAME. No VM_READ, process memory, directory or file
    // reads.
    Handle p(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid));
    if (!p.h)
        throw std::runtime_error("无法确认前台程序身份，未发送复制按键。");
    wchar_t path[32768];
    DWORD size = 32768;
    if (!QueryFullProcessImageNameW(p.h, 0, path, &size))
        throw std::runtime_error("无法确认前台程序身份。");
    std::wstring s(path, size);
    auto pos = s.find_last_of(L"\\/");
    if (pos != std::wstring::npos)
        s.erase(0, pos + 1);
    std::transform(s.begin(), s.end(), s.begin(), [](wchar_t c) { return (wchar_t)towlower(c); });
    return s;
}
static void copySafety(const CopyTarget &t) {
    t.verify();
    auto process = narrow(processBase(t.topPid));
    if (qt::terminalProcess(process))
        throw std::runtime_error("终端窗口不自动发送复制按键，请用手动复制模式。");
    wchar_t cls[128]{};
    GetClassNameW(t.focus, cls, 128);
    auto name = qt::normalize(narrow(cls));
    if ((name == "edit" || name.rfind("richedit", 0) == 0 ||
         name.rfind("windowsforms10.edit.", 0) == 0) &&
        (GetWindowLongPtrW(t.focus, GWL_STYLE) & ES_PASSWORD))
        throw std::runtime_error("密码输入框拒绝取词。");
    HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    if (FAILED(hr))
        throw std::runtime_error("无法检查焦点安全属性，未发送按键。");
    struct Exit {
        ~Exit() {
            CoUninitialize();
        }
    } exit;
    Com<IUIAutomation> uia;
    if (FAILED(CoCreateInstance(CLSID_CUIAutomation8, nullptr, CLSCTX_INPROC_SERVER,
                                IID_IUIAutomation, (void **)uia.put())))
        throw std::runtime_error("无法检查辅助功能焦点，未发送按键。");
    Com<IUIAutomation2> limit;
    if (SUCCEEDED(uia->QueryInterface(IID_IUIAutomation2, (void **)limit.put()))) {
        limit->put_ConnectionTimeout(400);
        limit->put_TransactionTimeout(250);
    }
    Com<IUIAutomationElement> focus;
    if (FAILED(uia->GetFocusedElement(focus.put())) || !focus || !belongsTo(uia.p, focus.p, t.top))
        throw std::runtime_error("无法确认焦点归属或密码属性，未发送复制按键。可使用手动复制。");
    t.verify();
}
static void waitCopyRelease(const CopyTarget &target, uint16_t trigger) {
    qt::ReleaseGate gate(GetTickCount64());
    std::array<bool, 256> initiallyHeld{};
    for (int k = 1; k < 256; ++k) {
        initiallyHeld[k] = (GetAsyncKeyState(k) & 0x8000) != 0;
        if (initiallyHeld[k] && !qt::releaseKeyAllowed((uint16_t)k, trigger))
            throw std::runtime_error("请先松开其他按键或鼠标，再选中文字按翻译热键。");
    }
    for (;;) {
        target.verify();
        bool held = false;
        for (int k = 1; k < 256; ++k) {
            bool down = (GetAsyncKeyState(k) & 0x8000) != 0;
            if (down && !initiallyHeld[k])
                throw std::runtime_error("等待热键释放期间出现新输入，已取消复制。");
            if (!down)
                initiallyHeld[k] = false;
            held |= down;
        }
        if (gate.ready(GetTickCount64(), held, true))
            return;
        Sleep(10);
    }
}
static DWORD lastInputTick() {
    LASTINPUTINFO info{};
    info.cbSize = sizeof(info);
    if (!GetLastInputInfo(&info))
        throw std::runtime_error("无法核对用户输入状态。");
    return info.dwTime;
}
static std::string universalCopy(HWND top, std::string &route, uint16_t trigger) {
    CopyTarget target(top);
    waitCopyRelease(target, trigger);
    DWORD baseline = lastInputTick();
    copySafety(target);
    target.verify();
    if (lastInputTick() != baseline)
        throw std::runtime_error("检查焦点期间出现新输入，未发送复制按键。");
    DWORD before = GetClipboardSequenceNumber(), tick = GetTickCount();
    if (!tick)
        tick = 1;
    INPUT keys[4]{};
    for (size_t i = 0; i < qt::copyKeys.size(); ++i) {
        auto k = qt::copyKeys[i];
        keys[i].type = INPUT_KEYBOARD;
        keys[i].ki.wVk = k.vk;
        keys[i].ki.time = tick;
        keys[i].ki.dwFlags =
            (k.up ? KEYEVENTF_KEYUP : 0) | (k.extended ? KEYEVENTF_EXTENDEDKEY : 0);
    }
    target.verify();
    UINT sent = SendInput(4, keys, sizeof(INPUT));
    if (sent != 4) {
        // Release only keys whose injected down events were reported inserted.
        INPUT up[2]{};
        UINT n = 0;
        if (sent >= 2 && sent < 3) {
            up[n] = keys[2];
            ++n;
        }
        if (sent >= 1) {
            up[n] = keys[3];
            ++n;
        }
        if (n)
            SendInput(n, up, sizeof(INPUT));
        throw std::runtime_error("复制按键未完整送达（可能被权限策略阻止），已停止。请手动复制。");
    }
    ULONGLONG deadline = GetTickCount64() + 1300;
    while (GetTickCount64() < deadline) {
        target.verify();
        if (!qt::allowedCopyInput(lastInputTick(), baseline, tick))
            throw std::runtime_error("复制期间出现新的用户输入，已取消，未提交翻译。");
        DWORD sequence = GetClipboardSequenceNumber();
        if (sequence && sequence != before) {
            DWORD ownerPid = 0;
            HWND owner = GetClipboardOwner();
            if (owner)
                GetWindowThreadProcessId(owner, &ownerPid);
            if (!qt::copyOwner(before, sequence, target.topPid, target.focusPid, ownerPid))
                throw std::runtime_error("剪贴板的新内容不属于原目标程序，已拒绝读取。");
            auto source = captureCopied(sequence);
            target.verify();
            if (!qt::allowedCopyInput(lastInputTick(), baseline, tick))
                throw std::runtime_error("读取复制文本期间出现新输入，已取消翻译。");
            route = "通用复制 · Ctrl+Insert · 剪贴板已更新";
            return source;
        }
        Sleep(10);
    }
    throw std::runtime_error("目标程序没有提供新的可复制文本，未使用旧剪贴板。请确认选区或快捷键映"
                             "射；不可选文字可用“指向文字”。");
}
static std::string pointText(HWND top, POINT point, std::string &route) {
    if (GetForegroundWindow() != top || !withinTarget(top, WindowFromPoint(point)))
        throw std::runtime_error("鼠标必须指向当前前台窗口内的文字。");
    HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    if (FAILED(hr))
        throw std::runtime_error("无法初始化指向取词。");
    struct Exit {
        ~Exit() {
            CoUninitialize();
        }
    } exit;
    Com<IUIAutomation> uia;
    if (FAILED(CoCreateInstance(CLSID_CUIAutomation8, nullptr, CLSCTX_INPROC_SERVER,
                                IID_IUIAutomation, (void **)uia.put())))
        throw std::runtime_error("无法初始化指向取词。");
    Com<IUIAutomation2> limit;
    if (SUCCEEDED(uia->QueryInterface(IID_IUIAutomation2, (void **)limit.put()))) {
        limit->put_ConnectionTimeout(400);
        limit->put_TransactionTimeout(250);
    }
    Com<IUIAutomationElement> element;
    if (FAILED(uia->ElementFromPoint(point, element.put())) || !element ||
        !belongsTo(uia.p, element.p, top))
        throw std::runtime_error("无法确认鼠标下文字的归属或安全属性。");
    CONTROLTYPEID type = 0;
    if (FAILED(element->get_CurrentControlType(&type)) || type != UIA_TextControlTypeId)
        throw std::runtime_error(
            "鼠标下不是独立文字标签。请指向弹窗正文；图片/扫描件需要 OCR，本版未提供。");
    BSTR raw = nullptr;
    if (FAILED(element->get_CurrentName(&raw)) || !raw)
        throw std::runtime_error("该标签没有辅助功能文字。");
    std::wstring w(raw, SysStringLen(raw));
    SysFreeString(raw);
    auto source = qt::trim(narrow(w));
    if (GetForegroundWindow() != top || !withinTarget(top, WindowFromPoint(point)))
        throw std::runtime_error("指向取词期间前台变化，已取消。");
    if (source.empty() || source.size() > 4000 || source.find('\0') != std::string::npos ||
        (!qt::english(source) && !qt::hasHan(source)))
        throw std::runtime_error("请选择不超过 4000 UTF-8 字节的英文文字标签。");
    route = "指向文字 · 仅当前标签 · 无剪贴板操作";
    return source;
}

static std::string compatibleCopy(HWND top, std::string &route, uint16_t trigger = 0) {
    CopyTarget t(top);
    wchar_t cls[128]{};
    GetClassNameW(t.focus, cls, 128);
    auto c = qt::normalize(narrow(cls));
    if (c == "scintilla" || c.rfind("windowsforms10.scintilla.", 0) == 0 || c == "edit" ||
        c.rfind("richedit", 0) == 0 || c.rfind("windowsforms10.edit.", 0) == 0 ||
        c.rfind("windowsforms10.richedit", 0) == 0)
        return captureOneKeyCopy(
            top,
            route); // Keep empty/password/oversize errors. Never turn them into a generic copy.
    return universalCopy(top, route, trigger);
}
