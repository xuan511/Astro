#pragma once
#include "billing.hpp"
#include <array>
static qt::BillingBook billingBook;
static bool billingLoaded = false, billingReady = false, billingDirty = false;
static std::string billingError;
static HWND billingLabel = nullptr, billingWindow = nullptr;
struct BillingTask {
    bool active = false;
    qt::BillEntry live;
};
static std::array<BillingTask, 3> billingTasks;
static std::string billingLastMain, billingLastStudy, billingLastTest;
static void refreshBillingWindow();
static void showBilling(const std::string &base = "", const std::string &model = "");
static bool flushBilling() {
    if (!billingDirty)
        return true;
    try {
        if (!billingReady)
            throw std::runtime_error("用量文件未安全加载，拒绝覆盖。");
        protectFile(learningDirectory() + L"\\api-usage.bin", billingBook.json());
        billingDirty = false;
        billingError.clear();
        if (host)
            KillTimer(host, 11);
        return true;
    } catch (const std::exception &e) {
        billingError = e.what();
        return false;
    }
}
static void billingChanged() {
    billingDirty = true;
    if (host)
        SetTimer(host, 11, 800, nullptr);
}
static void loadBilling() {
    if (billingLoaded)
        return;
    billingLoaded = true;
    try {
        auto plain = protectedFile(learningDirectory() + L"\\api-usage.bin");
        if (!plain.empty())
            billingBook = qt::BillingBook::parse(plain);
        billingReady = true;
        if (!plain.empty() && plain != billingBook.json()) {
            billingDirty = true;
            flushBilling();
        }
    } catch (const std::exception &e) {
        billingError = e.what();
        billingReady = false;
    }
}
static std::string billingScope(const std::string &base, const std::string &model) {
    return hashText(qt::endpoint(base).base + "\n" + model);
}
static void setBillingMain(const std::string &s) {
    billingLastMain = s;
    if (billingLabel)
        SetWindowTextW(billingLabel, wide(s).c_str());
}
static void billingEnd(unsigned channel, qt::BillState state) {
    auto &t = billingTasks.at(channel);
    if (!t.active)
        return;
    if (!t.live.started && (state == qt::BillState::Success || state == qt::BillState::Failed))
        state = qt::BillState::NotSent;
    t.live.state = state;
    if (state == qt::BillState::Cache || state == qt::BillState::NotSent)
        t.live.usage = {};
    if (billingReady) {
        billingBook.finish(t.live.id, state);
        if (auto p = billingBook.find(t.live.id))
            t.live = *p;
        billingChanged();
    }
    auto description = qt::billText(t.live);
    if (!billingReady)
        description += " · 本地累计未记录";
    if (channel == 0)
        setBillingMain(description);
    else if (channel == 1)
        billingLastStudy = description;
    else
        billingLastTest = description;
    t.active = false;
    if (!flushBilling()) {
        if (channel == 0)
            setBillingMain(description + " · 本地保存失败");
    }
    refreshBillingWindow();
}
static void billingBegin(unsigned channel, const qt::ApiConfig &c) {
    loadBilling();
    billingEnd(channel, qt::BillState::Cancelled);
    auto &t = billingTasks.at(channel);
    t = {};
    t.active = true;
    t.live.id = newDevice();
    t.live.scope = billingScope(c.base, c.model);
    t.live.host = qt::endpoint(c.base).host;
    t.live.model = c.model;
    t.live.at = unixMillis();
    t.live.purpose = channel;
    if (billingReady) {
        billingBook.begin(t.live);
        if (auto e = billingBook.find(t.live.id))
            t.live = *e;
        billingChanged();
        flushBilling();
    }
    if (channel == 0)
        setBillingMain("等待 API 用量…");
}
static bool billingFrame(unsigned channel, const qt::Frame &f) {
    if (f.type != 8 && f.type != 9)
        return false;
    auto &t = billingTasks.at(channel);
    if (!t.active)
        return true;
    if (f.type == 9) {
        if (f.text != "api-request")
            throw std::runtime_error("API 用量事件无效。");
        t.live.started = true;
        if (billingReady)
            billingBook.started(t.live.id);
    } else {
        auto u = qt::ApiUsage::parse(qt::Parser(f.text).parse());
        if (u.any()) {
            t.live.usage = u;
            t.live.started = true;
            if (billingReady)
                billingBook.observe(t.live.id, u);
        }
    }
    if (billingReady)
        billingChanged();
    if (channel == 0)
        setBillingMain(qt::billText(t.live));
    return true;
}
