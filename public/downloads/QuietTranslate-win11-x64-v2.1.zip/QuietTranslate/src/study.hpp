#pragma once
#include "glossary.hpp"
#include <set>
#include <algorithm>
namespace qt {
struct StudyCard {
    std::string term, pos, meaning, usage, patterns, example, translation;
};
inline const std::vector<StudyCard> &studyCards() {
    static const std::vector<StudyCard> cards = {
        {"assert", "动词", "断言；在硬件语境中指使信号进入有效状态。",
         "不要直接译成“拉高”：低有效信号的有效状态可能是低电平。", "assert a signal / assert reset",
         "The controller asserts reset when the supply voltage is too low.",
         "供电电压过低时，控制器使复位信号有效。"},
        {"deassert", "动词", "撤销信号的有效状态。",
         "与 assert 相对；具体电平由信号的有效极性决定。",
         "deassert reset / deassert the interrupt line",
         "The device deasserts the interrupt line after the status is cleared.",
         "状态清除后，设备撤销中断线的有效状态。"},
        {"require", "动词", "要求；需要。",
         "require + 名词；require sb to do sth；be required to do。先找清谁被要求执行动作。",
         "require initialization / be required to wait",
         "The driver is required to wait until the transfer completes.",
         "驱动程序必须等到传输完成。"},
        {"allow", "动词", "允许；使……成为可能。",
         "allow sb/sth to do；被动形式 be allowed to do。不要把允许误读为必须。",
         "allow access / allow the CPU to sleep",
         "DMA allows the CPU to perform other tasks during a transfer.",
         "DMA 使 CPU 能在传输期间执行其他任务。"},
        {"prevent", "动词", "防止；阻止。", "prevent sb/sth from doing。from 后面使用动名词。",
         "prevent overflow / prevent data from being overwritten",
         "The lock prevents two threads from modifying the buffer at the same time.",
         "这把锁防止两个线程同时修改缓冲区。"},
        {"ensure", "动词", "确保。",
         "ensure that + 从句；ensure + 名词。规范中的要求需要结合主语和条件判断。",
         "ensure that / ensure data integrity",
         "Ensure that the clock is stable before enabling the peripheral.",
         "启用外设之前，确保时钟已经稳定。"},
        {"unless", "连词", "除非；如果不。",
         "unless + 条件从句，通常相当于 if ... not。应把否定条件完整读出。",
         "unless otherwise specified",
         "The register must not be written unless the peripheral is disabled.",
         "除非外设已被禁用，否则不得写入该寄存器。"},
        {"otherwise", "副词", "否则；在其他情况下；另有。",
         "常接在条件说明之后；otherwise specified 表示“另有规定”。",
         "unless otherwise specified / otherwise return an error",
         "If the buffer is full, discard the byte; otherwise, store it.",
         "如果缓冲区已满，就丢弃该字节；否则将其存入。"},
        {"whereas", "连词", "而；然而（用于对照）。", "用于对照两个事实，通常不是时间关系。",
         "A ..., whereas B ...", "SRAM is volatile, whereas flash retains data without power.",
         "SRAM 是易失性存储器，而闪存能在断电后保留数据。"},
        {"respectively", "副词", "分别地。", "前后两组对象按出现顺序一一对应，不能交换对应关系。",
         "A and B ... X and Y, respectively",
         "Pins A and B are connected to SDA and SCL, respectively.",
         "引脚 A 和 B 分别连接到 SDA 和 SCL。"},
        {"enable", "动词", "启用；使……能够。",
         "enable + 功能；enable sb/sth to do。手册中的 enabled 不一定表示外设正在活动。",
         "enable interrupts / enable DMA", "Set this bit to enable receive interrupts.",
         "将此位置位以启用接收中断。"},
        {"disable", "动词", "禁用；使失效。",
         "disable + 功能或设备；be disabled 为被动形式。禁用不一定等于切断供电。",
         "disable the peripheral / disable interrupts",
         "Disable the peripheral before changing its configuration.",
         "更改配置之前，先禁用该外设。"},
        {"shall", "情态动词", "应；在规范中常表示强制要求。",
         "后接动词原形；shall not 常表示禁止。强制程度以该文档的术语定义为准。",
         "shall be / shall not modify", "The application shall not modify reserved bits.",
         "应用程序不得修改保留位。"},
        {"should", "情态动词", "应该；宜。",
         "后接动词原形。规范中常用于建议，但不能脱离文档定义决定强制程度。",
         "should be / should avoid", "The buffer size should be a multiple of the packet size.",
         "缓冲区大小宜为数据包大小的整数倍。"},
        {"may", "情态动词", "可以（许可）；可能（可能性）。",
         "根据上下文区分许可与可能。may not 也可能有歧义，需要结合规范定义。",
         "may occur / may be used", "A timeout may occur if the device does not respond.",
         "如果设备没有响应，就可能发生超时。"},
        {"must", "情态动词", "必须。", "must + 动词原形；must not 表示禁止，并非“不必”。",
         "must be / must not access", "The clock must be enabled before the register is accessed.",
         "访问该寄存器之前，必须启用时钟。"},
        {"not", "副词", "不；未。",
         "否定作用范围决定含义。not required 表示不要求，must not 表示禁止。",
         "must not / not necessarily / not required",
         "A valid address does not necessarily refer to writable memory.",
         "有效地址不一定指向可写内存。"},
        {"valid", "形容词", "有效的；符合约束的。",
         "valid + 名词；be valid for。有效不一定代表当前可用或允许写入。",
         "valid address / valid data / valid until",
         "The data is valid only after the ready flag is set.", "只有就绪标志置位后，数据才有效。"},
        {"available", "形容词", "可用的；可获得的。",
         "available for + 名词；available to + 使用者。与 valid（有效）含义不同。",
         "available memory / available for use",
         "This feature is available only in privileged mode.", "此功能仅在特权模式下可用。"},
        {"pending", "形容词", "待处理的；尚未完成的。",
         "pending interrupt 表示中断请求等待处理，不表示处理程序已经执行。",
         "pending interrupt / pending request",
         "The interrupt remains pending until its flag is cleared.",
         "在中断标志被清除之前，该中断一直处于待处理状态。"},
        {"reserved", "形容词；reserve 的过去分词", "保留的。",
         "寄存器中的 reserved bits 应按手册规定操作，不能一概认为总要写 0。",
         "reserved bits / reserved for future use",
         "These bits are reserved; preserve their values when updating the register.",
         "这些位是保留位；更新寄存器时应保留它们的值。"},
        {"volatile", "形容词；C/C++ 限定符", "易失的；易变限定符。",
         "存储器语境下常指断电丢失；C/C++ 中涉及访问语义，不能保证原子性或线程同步。",
         "volatile memory / volatile-qualified object",
         "The status register is accessed through a pointer to volatile-qualified data.",
         "通过指向带有 volatile 限定数据的指针访问状态寄存器。"},
        {"atomic", "形容词", "原子的；不可分割的。",
         "atomic operation 相对于特定观察者不可再分割。原子性与内存顺序需要分别判断。",
         "atomic operation / atomic access",
         "Use an atomic operation to update the shared counter.", "使用原子操作更新共享计数器。"},
        {"interrupt", "名词；动词", "中断；打断。",
         "interrupt 可能是硬件事件，也可能作普通动词。interrupt handler 为中断处理程序。",
         "interrupt handler / interrupt request",
         "The interrupt handler copies the received byte into a ring buffer.",
         "中断处理程序将接收到的字节复制到环形缓冲区中。"},
        {"latency", "名词", "延迟。",
         "强调从事件到响应的等待时间，与单位时间工作量 throughput 不同。",
         "interrupt latency / reduce latency",
         "Disabling interrupts for too long increases interrupt latency.",
         "禁用中断的时间过长会增加中断延迟。"},
        {"throughput", "名词", "吞吐量。",
         "强调单位时间完成的数据量或任务量；高吞吐量不保证低延迟。",
         "data throughput / improve throughput",
         "Larger transfers can improve throughput by reducing per-transfer overhead.",
         "较大的传输可通过减少每次传输的额外开销来提高吞吐量。"},
        {"offset", "名词", "偏移量。",
         "常相对于基地址、文件开头或字段起点。务必确认单位是字节、位还是元素。",
         "byte offset / offset from the base address",
         "The field begins at an offset of four bytes from the start of the header.",
         "该字段起始于距离头部开头四个字节的位置。"},
        {"align", "动词", "对齐。",
         "align A to/with B；be aligned to a boundary。指地址约束时要核对具体字节边界。",
         "align the buffer / aligned to a four-byte boundary",
         "The buffer must be aligned to a four-byte boundary.", "缓冲区必须按四字节边界对齐。"},
        {"retain", "动词", "保留；保持。", "强调原有内容仍然存在，常与断电、复位后的数据保持有关。",
         "retain data / retain its value", "This register retains its value during a warm reset.",
         "该寄存器在热复位期间保留其值。"},
        {"restore", "动词", "恢复；还原。",
         "restore A from B；restore A to a state。注意来源和目标状态。",
         "restore state / restore data from a backup",
         "Restore the previous configuration if validation fails.",
         "如果验证失败，则恢复之前的配置。"},
        {"perform", "动词", "执行；进行。", "perform + 操作名词，技术文档中的常见动作表达。",
         "perform a check / perform an operation",
         "Perform a CRC check before executing the new firmware.",
         "执行新固件之前，先进行 CRC 校验。"},
        {"occur", "不及物动词", "发生。",
         "事件作主语；通常不说 be occurred。常见形式 occurs、occurred、occurring。",
         "an error occurs / occur during", "An error may occur during the erase operation.",
         "擦除操作期间可能发生错误。"},
        {"trigger", "动词；名词", "触发；触发条件。",
         "trigger + 事件；be triggered by + 原因。区分原因和被触发的事件。",
         "trigger an interrupt / triggered by an edge",
         "A rising edge on this pin triggers an interrupt.", "该引脚上的上升沿会触发中断。"},
        {"indicate", "动词", "表示；指示；表明。",
         "indicate that + 从句；indicate + 状态。状态位通常用于指示事实，不必然控制该事实。",
         "indicate an error / indicate that",
         "A value of one indicates that the transfer is complete.", "值为 1 表示传输已经完成。"},
        {"specify", "动词", "指定；规定；说明。",
         "specify + 参数；as specified in + 文档。specified 是过去分词。",
         "specify a timeout / as specified in the manual",
         "Use the clock frequency specified in the datasheet.", "使用数据手册中规定的时钟频率。"},
        {"assume", "动词", "假设；认定。",
         "assume that + 从句；do not assume 表示不能把某条件当作理所当然。",
         "assume that / assume a value",
         "Do not assume that a successful write makes the data persistent.",
         "不要假定写入成功就意味着数据已经持久保存。"},
        {"implement", "动词", "实现；实施。",
         "implement + 功能或接口。与简单地调用或使用接口不同。",
         "implement an interface / implement a protocol",
         "The driver implements a timeout for every blocking operation.",
         "驱动程序为每个阻塞操作实现了超时机制。"},
        {"support", "动词；名词", "支持；支持能力。",
         "support + 功能/设备。supported by 表示由谁支持，不一定表示默认开启。",
         "support a feature / supported by hardware",
         "This peripheral supports both polling and interrupt-driven transfers.",
         "该外设同时支持轮询传输和中断驱动传输。"},
        {"issue", "名词；动词", "问题；发出（命令或请求）。",
         "issue a command 中 issue 是动词，不应译为“问题”。",
         "issue a command / issue a request / known issue",
         "Issue a reset command after updating the configuration.", "更新配置后，发出复位命令。"},
        {"handle", "动词；名词", "处理；句柄。",
         "handle an error 为处理错误；a file handle 为文件句柄。",
         "handle an interrupt / file handle",
         "The application must handle partial writes correctly.", "应用程序必须正确处理部分写入。"},
        {"access", "名词；动词", "访问；访问权限。",
         "动词 access 后直接接对象；名词常说 access to。", "access memory / access to the register",
         "User-mode code has no access to this register.", "用户态代码没有访问该寄存器的权限。"},
        {"apply", "动词", "应用；施加；适用。",
         "apply A to B 表示将 A 应用于 B；apply to 表示适用于。",
         "apply a voltage / apply to this device", "The same restriction applies to all channels.",
         "同一限制适用于所有通道。"},
        {"assign", "动词", "分配；赋值。",
         "assign A to B。地址、资源和变量值的“分配/赋值”需按语境选择。",
         "assign a value / assign a priority", "Assign a higher priority to time-critical tasks.",
         "为时间要求严格的任务分配更高的优先级。"},
        {"consistent", "形容词", "一致的；相符的。",
         "consistent with 表示与……一致；不代表内容一定正确。",
         "consistent with / a consistent state",
         "The cached value must remain consistent with the hardware state.",
         "缓存值必须与硬件状态保持一致。"},
        {"constraint", "名词", "约束；限制条件。",
         "constraint on + 对象；meet/satisfy a constraint。",
         "timing constraints / satisfy alignment constraints",
         "The design must satisfy the timing constraints of the interface.",
         "该设计必须满足接口的时序约束。"},
        {"depend on", "动词短语", "取决于；依赖于。",
         "depend on + 名词/从句；具体结果随所述条件变化。",
         "depend on the configuration / depend on whether",
         "The reset value depends on the selected operating mode.", "复位值取决于所选的工作模式。"},
        {"due to", "介词短语", "由于；因为。",
         "后面常接名词或名词短语，给出原因。不要与 due（到期）混淆。",
         "due to an error / due to insufficient memory",
         "The allocation failed due to insufficient memory.", "由于内存不足，分配失败。"},
        {"according to", "介词短语", "根据；按照。", "后接规则、规范或信息来源；不等于表示原因。",
         "according to the specification", "Configure the pins according to the board schematic.",
         "按照电路板原理图配置引脚。"},
        {"as long as", "连词短语", "只要；在……期间（视语境）。",
         "技术条件句中常表示满足某条件即可，不能机械译成“和……一样长”。",
         "as long as the clock is enabled",
         "The counter continues to run as long as the clock is enabled.",
         "只要时钟保持启用，计数器就会继续运行。"},
        {"read-only", "形容词", "只读的。", "用于修饰寄存器或存储区；通常无法通过普通写入修改。",
         "read-only register / read-only memory",
         "This field is read-only and reflects the current hardware state.",
         "该字段为只读字段，反映当前硬件状态。"},
        {"read-modify-write", "名词短语；形容词", "读—改—写。",
         "先读取，再修改部分位，最后写回；对 W1C 等特殊寄存器可能有副作用。",
         "a read-modify-write operation",
         "A read-modify-write operation may clear unrelated status flags.",
         "一次读—改—写操作可能会清除无关的状态标志。"},
        {"blocking", "形容词", "阻塞的。",
         "blocking call 会等待条件满足；不要与屏蔽中断的语义自动等同。",
         "blocking call / blocking operation",
         "A blocking read waits until data becomes available or a timeout occurs.",
         "阻塞读取会等待数据可用或发生超时。"},
        {"polling", "名词；poll 的动名词", "轮询。",
         "循环检查状态。轮询与事件驱动是不同等待策略，需要考虑 CPU 开销。",
         "polling mode / polling the status register",
         "Polling the status register continuously can waste CPU time.",
         "持续轮询状态寄存器可能浪费 CPU 时间。"},
        {"watchdog", "名词", "看门狗。", "通常指未按时服务时触发复位或其他故障处理的机制。",
         "watchdog timer / service the watchdog",
         "The watchdog resets the system if the application stops responding.",
         "如果应用程序停止响应，看门狗会复位系统。"},
        {"initialize", "动词", "初始化。",
         "initialize A before doing B；初始化与复位、启用并非总是同一操作。",
         "initialize a buffer / initialize the peripheral",
         "Initialize the buffer before starting the transfer.", "开始传输之前，先初始化缓冲区。"},
        {"overwrite", "动词", "覆盖；覆写。",
         "overwrite existing data 强调新内容替换旧内容，可能导致原数据丢失。",
         "overwrite data / be overwritten",
         "Unread data may be overwritten when the ring buffer is full.",
         "环形缓冲区已满时，尚未读取的数据可能被覆盖。"},
        {"acknowledge", "动词", "确认；应答。",
         "acknowledge a request/interrupt 的具体动作依协议和硬件定义。",
         "acknowledge an interrupt / acknowledge receipt",
         "The receiver acknowledges each valid packet.", "接收方会对每个有效数据包作出确认。"},
        {"overhead", "名词", "额外开销。", "强调完成主要工作所附带的成本，不限于 CPU 时间。",
         "protocol overhead / scheduling overhead",
         "Batching requests reduces the overhead of connection setup.",
         "批量处理请求可减少建立连接的额外开销。"}};
    return cards;
}
inline const StudyCard *findStudyCard(const std::string &term) {
    auto key = normalize(term);
    for (const auto &card : studyCards())
        if (card.term == key)
            return &card;
    return nullptr;
}
inline std::string studyText(const StudyCard &c) {
    return c.term + "  [" + c.pos + "]\r\n\r\n中文含义\r\n" + c.meaning +
           "\r\n\r\n用法与易错点\r\n" + c.usage + "\r\n\r\n常见搭配\r\n" + c.patterns +
           "\r\n\r\n例句\r\n" + c.example + "\r\n" + c.translation;
}
inline std::string baseForm(const std::string &word) {
    static const std::map<std::string, std::string> irregular = {
        {"requires", "require"},
        {"required", "require"},
        {"requiring", "require"},
        {"allows", "allow"},
        {"allowed", "allow"},
        {"allowing", "allow"},
        {"prevents", "prevent"},
        {"prevented", "prevent"},
        {"preventing", "prevent"},
        {"ensures", "ensure"},
        {"ensured", "ensure"},
        {"ensuring", "ensure"},
        {"enabled", "enable"},
        {"enables", "enable"},
        {"enabling", "enable"},
        {"disabled", "disable"},
        {"disables", "disable"},
        {"disabling", "disable"},
        {"asserts", "assert"},
        {"asserted", "assert"},
        {"asserting", "assert"},
        {"deasserts", "deassert"},
        {"deasserted", "deassert"},
        {"deasserting", "deassert"},
        {"aligned", "align"},
        {"alignment", "alignment"},
        {"aligning", "align"},
        {"retained", "retain"},
        {"retains", "retain"},
        {"retaining", "retain"},
        {"restored", "restore"},
        {"restores", "restore"},
        {"restoring", "restore"},
        {"performed", "perform"},
        {"performs", "perform"},
        {"performing", "perform"},
        {"occurs", "occur"},
        {"occurred", "occur"},
        {"occurring", "occur"},
        {"triggered", "trigger"},
        {"triggers", "trigger"},
        {"triggering", "trigger"},
        {"indicated", "indicate"},
        {"indicates", "indicate"},
        {"indicating", "indicate"},
        {"specified", "specify"},
        {"specifies", "specify"},
        {"specifying", "specify"},
        {"assumed", "assume"},
        {"assumes", "assume"},
        {"assuming", "assume"},
        {"implemented", "implement"},
        {"implements", "implement"},
        {"implementing", "implement"},
        {"supported", "support"},
        {"supports", "support"},
        {"supporting", "support"},
        {"issued", "issue"},
        {"issues", "issue"},
        {"issuing", "issue"},
        {"handled", "handle"},
        {"handles", "handle"},
        {"handling", "handle"},
        {"accessed", "access"},
        {"accesses", "access"},
        {"accessing", "access"},
        {"applied", "apply"},
        {"applies", "apply"},
        {"applying", "apply"},
        {"assigned", "assign"},
        {"assigns", "assign"},
        {"assigning", "assign"},
        {"constraints", "constraint"},
        {"initialized", "initialize"},
        {"initializes", "initialize"},
        {"initializing", "initialize"},
        {"overwritten", "overwrite"},
        {"overwrites", "overwrite"},
        {"overwriting", "overwrite"},
        {"acknowledged", "acknowledge"},
        {"acknowledges", "acknowledge"},
        {"registers", "register"},
        {"interrupts", "interrupt"},
        {"buffers", "buffer"},
        {"threads", "thread"},
        {"pointers", "pointer"},
        {"operations", "operation"},
        {"memory-mapped", "memory-mapped"}};
    auto key = normalize(word);
    auto i = irregular.find(key);
    return i == irregular.end() ? key : i->second;
}
struct Keyword {
    std::string surface, term;
    size_t position;
    int score;
};
inline bool alpha(unsigned char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}
inline bool dictionaryWord(const std::string &word) {
    if (word.empty() || word.size() > 40 || !alpha((unsigned char)word.front()) ||
        !alpha((unsigned char)word.back()))
        return false;
    for (unsigned char c : word)
        if (!alpha(c) && c != '-' && c != '\'')
            return false;
    return true;
}
inline std::vector<Keyword> keywords(const std::string &source, size_t maxCount = 8) {
    if (source.size() > 12000)
        throw std::runtime_error("选区过长，无法提取学习词语。");
    struct Token {
        std::string word;
        size_t begin, end;
        bool valid;
    };
    std::vector<Token> tokens;
    for (size_t i = 0; i < source.size();) {
        if (!alpha((unsigned char)source[i])) {
            ++i;
            continue;
        }
        size_t begin = i++;
        while (i < source.size() &&
               (alpha((unsigned char)source[i]) || isdigit((unsigned char)source[i]) ||
                source[i] == '_' || source[i] == '-' || source[i] == '\''))
            ++i;
        auto raw = source.substr(begin, i - begin);
        auto key = normalize(raw);
        bool valid = dictionaryWord(key) &&
                     (begin == 0 ||
                      (!isalnum((unsigned char)source[begin - 1]) && source[begin - 1] != '_'));
        tokens.push_back({key, begin, i, valid});
    }
    std::vector<Keyword> candidates;
    std::set<std::string> seen;
    std::map<std::string, bool> phrases;
    for (const auto &card : studyCards())
        if (card.term.find(' ') != std::string::npos)
            phrases[card.term] = true;
    for (const auto &item : glossary())
        if (item.first.find(' ') != std::string::npos && !phrases.count(item.first))
            phrases[item.first] = false;
    for (const auto &phrase : phrases) {
        for (size_t i = 0; i < tokens.size(); ++i) {
            std::string joined;
            for (size_t j = i; j < std::min(tokens.size(), i + 5); ++j) {
                if (!tokens[j].valid)
                    break;
                if (j > i) {
                    auto gap =
                        source.substr(tokens[j - 1].end, tokens[j].begin - tokens[j - 1].end);
                    if (gap.find_first_not_of(" \t\r\n") != std::string::npos)
                        break;
                    joined += ' ';
                }
                joined += tokens[j].word;
                if (joined == phrase.first && seen.insert(joined).second)
                    candidates.push_back(
                        {source.substr(tokens[i].begin, tokens[j].end - tokens[i].begin), joined,
                         tokens[i].begin, (phrase.second ? 1100 : 1000) + (int)joined.size()});
                if (joined.size() >= phrase.first.size())
                    break;
            }
        }
    }
    static const std::set<std::string> stops = {
        "the",  "this",   "that",    "these",   "those",    "with",  "from",  "into",  "onto",
        "then", "when",   "while",   "before",  "after",    "until", "each",  "both",  "some",
        "such", "only",   "also",    "have",    "has",      "had",   "been",  "being", "were",
        "will", "would",  "could",   "does",    "which",    "whose", "their", "there", "they",
        "them", "your",   "than",    "between", "during",   "using", "used",  "use",   "other",
        "same", "about",  "above",   "below",   "under",    "over",  "more",  "most",  "less",
        "very", "either", "whether", "through", "following"};
    for (const auto &t : tokens) {
        if (!t.valid)
            continue;
        auto term = baseForm(t.word);
        bool card = findStudyCard(term) != nullptr, technical = !lookup(term).empty();
        if (!card && !technical && (term.size() < 4 || stops.count(term)))
            continue;
        if (seen.insert(term).second)
            candidates.push_back({source.substr(t.begin, t.end - t.begin), term, t.begin,
                                  card        ? 900
                                  : technical ? 800
                                              : 200 + (int)std::min<size_t>(term.size(), 12)});
    }
    std::stable_sort(candidates.begin(), candidates.end(), [](const auto &a, const auto &b) {
        return a.score != b.score ? a.score > b.score : a.position < b.position;
    });
    // Prefer a recognized phrase over its component words in the compact list.
    std::vector<Keyword> result;
    for (const auto &c : candidates) {
        bool covered = false;
        for (const auto &p : result)
            if (p.term.find(' ') != std::string::npos && c.position >= p.position &&
                c.position < p.position + p.surface.size())
                covered = true;
        if (!covered) {
            result.push_back(c);
            if (result.size() >= maxCount)
                break;
        }
    }
    if (maxCount == 0)
        return {};
    return result;
}
inline std::string limited(const std::string &value, size_t n) {
    size_t end = std::min(value.size(), n);
    while (end < value.size() && ((unsigned char)value[end] & 0xc0) == 0x80)
        --end;
    return value.substr(0, end) + (end < value.size() ? "…" : "");
}
inline const Json *field(const Json &j, const std::string &key) {
    auto i = j.object.find(key);
    return j.kind == Json::Object && i != j.object.end() ? &i->second : nullptr;
}
inline std::string stringField(const Json &j, const std::string &key, size_t limit = 1000) {
    auto p = field(j, key);
    return p && p->kind == Json::String ? limited(p->text, limit) : "";
}
struct DictionarySense {
    std::string pos, definition, example;
};
struct DictionaryEntry {
    std::string word, phonetic;
    std::vector<DictionarySense> senses;
    std::vector<std::string> sources;
    std::string license;
    std::string report() const {
        std::string out = word + (phonetic.empty() ? "" : "  /" + phonetic + "/") +
                          "\r\n\r\n在线词典：词典提供的词义，尚未按原句消歧。\r\n";
        for (size_t i = 0; i < senses.size(); ++i) {
            auto &s = senses[i];
            out += "\r\n" + std::to_string(i + 1) + ". [" + s.pos + "] " + s.definition + "\r\n";
            out +=
                s.example.empty() ? "例句：该义项未提供例句。\r\n" : "例句：" + s.example + "\r\n";
        }
        out += "\r\n来源：Free Dictionary API\r\n";
        for (auto &s : sources)
            out += s + "\r\n";
        out += "许可：" + (license.empty() ? "响应未提供许可信息，请查看词条来源。" : license) +
               "\r\n";
        return out;
    }
    std::string translationInput() const {
        std::string out;
        for (size_t i = 0; i < senses.size(); ++i) {
            auto &s = senses[i];
            out += std::to_string(i + 1) + ". Definition: " + s.definition + "\n";
            if (!s.example.empty())
                out += "Example: " + s.example + "\n";
        }
        return out;
    }
};
inline DictionaryEntry parseDictionary(const std::string &response, const std::string &requested) {
    auto root = Parser(response).parse();
    if (root.kind != Json::Array || root.array.empty())
        throw std::runtime_error(
            "词典未收录该词，或返回格式异常。可尝试原形；技术缩写不一定有通用词条。");
    DictionaryEntry entry;
    entry.word = requested;
    for (const auto &item : root.array) {
        if (item.kind != Json::Object)
            continue;
        if (entry.phonetic.empty())
            entry.phonetic = stringField(item, "phonetic", 100);
        if (entry.phonetic.empty()) {
            auto phonetics = field(item, "phonetics");
            if (phonetics && phonetics->kind == Json::Array)
                for (const auto &phonetic : phonetics->array) {
                    entry.phonetic = stringField(phonetic, "text", 100);
                    if (!entry.phonetic.empty())
                        break;
                }
        }
        auto lic = field(item, "license");
        if (lic) {
            auto name = stringField(*lic, "name", 120), url = stringField(*lic, "url", 250);
            if (!name.empty() && entry.license.size() < 800) {
                if (!entry.license.empty())
                    entry.license += "; ";
                entry.license += name + (url.empty() ? "" : " " + url);
            }
        }
        auto src = field(item, "sourceUrls");
        if (src && src->kind == Json::Array)
            for (const auto &url : src->array)
                if (url.kind == Json::String && entry.sources.size() < 3)
                    entry.sources.push_back(limited(url.text, 250));
        auto meanings = field(item, "meanings");
        if (!meanings || meanings->kind != Json::Array)
            continue;
        for (const auto &meaning : meanings->array) {
            auto defs = field(meaning, "definitions");
            if (!defs || defs->kind != Json::Array)
                continue;
            auto pos = stringField(meaning, "partOfSpeech", 60);
            bool duplicate = false;
            for (auto &s : entry.senses)
                if (s.pos == pos)
                    duplicate = true;
            if (duplicate)
                continue;
            const Json *chosen = nullptr;
            for (const auto &d : defs->array) {
                if (stringField(d, "definition", 600).empty())
                    continue;
                if (!chosen)
                    chosen = &d;
                if (!stringField(d, "example", 500).empty()) {
                    chosen = &d;
                    break;
                }
            }
            if (chosen)
                entry.senses.push_back({pos.empty() ? "词性未提供" : pos,
                                        stringField(*chosen, "definition", 600),
                                        stringField(*chosen, "example", 500)});
            if (entry.senses.size() >= 2)
                break;
        }
        if (entry.senses.size() >= 2)
            break;
    }
    if (entry.senses.empty())
        throw std::runtime_error("词典没有可显示的释义，未生成虚构例句。");
    return entry;
}
} // namespace qt
