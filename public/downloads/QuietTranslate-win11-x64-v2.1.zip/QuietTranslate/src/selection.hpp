#pragma once
#include <string>
#include <stdexcept>
#include <algorithm>
#include <cstdint>
namespace qt {
constexpr size_t maxSelectionUnits = 4000;
class CopiedSequenceGuard {
    uint32_t last = 0;

  public:
    void reset(uint32_t sequence) {
        last = sequence;
    }
    bool accept(uint32_t sequence) {
        if (!sequence || sequence == last)
            return false;
        last = sequence;
        return true;
    }
};
// Read only the explicitly supplied clipboard block, with a bounded scan and mandatory NUL.
inline std::u16string copiedText(const char16_t *data, size_t units) {
    if (!data || !units)
        throw std::runtime_error("当前剪贴板没有有效文本。请先手动 Ctrl+C 复制需要翻译的英文。");
    const size_t bound = std::min(units, maxSelectionUnits + 1);
    size_t n = 0;
    while (n < bound && data[n] != 0)
        ++n;
    if (n > maxSelectionUnits)
        throw std::runtime_error("剪贴板文本超过 4000 字符，请缩短选区后重新复制。");
    if (n == bound)
        throw std::runtime_error("剪贴板文本格式异常，已放弃读取。");
    if (!n)
        throw std::runtime_error("剪贴板文本为空。请先手动复制英文。");
    for (size_t i = 0; i < n; ++i) {
        unsigned c = data[i];
        if (c >= 0xd800 && c <= 0xdbff) {
            if (i + 1 >= n || data[i + 1] < 0xdc00 || data[i + 1] > 0xdfff)
                throw std::runtime_error("剪贴板 Unicode 文本无效。");
            ++i;
        } else if (c >= 0xdc00 && c <= 0xdfff)
            throw std::runtime_error("剪贴板 Unicode 文本无效。");
    }
    return std::u16string(data, n);
}
} // namespace qt
