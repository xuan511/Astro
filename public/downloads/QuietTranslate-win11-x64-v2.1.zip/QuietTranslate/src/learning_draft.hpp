#pragma once
#include "notebook.hpp"
namespace qt {
// Scope-bound edit buffer. Background refreshes cannot bind a note to another selection.
class LearningDraft {
    std::string selectedKey, selectedScope, baseNote, note;
    bool baseStar = false, baseKnown = false, star = false, known = false;

  public:
    const std::string &key() const {
        return selectedKey;
    }
    const std::string &scope() const {
        return selectedScope;
    }
    bool dirty() const {
        return !selectedKey.empty() && (note != baseNote || star != baseStar || known != baseKnown);
    }
    void load(const BookEntry *e, const std::string &s) {
        selectedScope = s;
        selectedKey = e ? e->key : "";
        note = baseNote = e ? e->note : "";
        star = baseStar = e && e->star;
        known = baseKnown = e && e->known;
    }
    void update(const std::string &n, bool st, bool kn) {
        note = n;
        star = st;
        known = kn;
    }
    bool commit(Notebook &book, const std::string &scope, const std::string &device, uint64_t now) {
        if (!dirty())
            return false;
        if (scope != selectedScope)
            throw std::runtime_error("笔记状态已变化，请重新选择词条或撤销编辑。");
        auto e = book.find(selectedKey);
        if (!e || e->deleted)
            throw std::runtime_error(
                "该词条已删除，笔记草稿仍保留在编辑框。请复制保留或撤销编辑，不自动恢复删除记录。");
        auto nextNote = note != baseNote ? note : e->note;
        bool nextStar = star != baseStar ? star : e->star,
             nextKnown = known != baseKnown ? known : e->known;
        if (nextNote == e->note && nextStar == e->star && nextKnown == e->known) {
            load(e, scope);
            return false;
        }
        auto key = selectedKey;
        book.edit(key, nextNote, nextStar, nextKnown, "", device, now);
        load(book.find(key), scope);
        return true;
    }
};
} // namespace qt
