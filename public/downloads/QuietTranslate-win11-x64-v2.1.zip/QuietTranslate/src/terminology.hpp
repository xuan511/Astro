#pragma once
#include "core.hpp"
#include <algorithm>
#include <string_view>

namespace qt {
// Deliberately case-sensitive: names/acronyms, not a list of English words to skip.
// Longest match wins; token boundaries exclude identifiers, paths and compound words.
struct TechnicalTerm {
    size_t begin = 0, end = 0;
};
inline bool termPart(unsigned char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' ||
           c == '+' || c == '#' || c == '-' || c == '/' || c == '\\' || c == '.';
}
inline bool termBoundary(const std::string &s, size_t at, size_t length) {
    // A full stop ending a name is punctuation; dots inside identifiers/domains are not.
    auto joins = [&](size_t p) {
        if (s[p] == '.' && (p + 1 == s.size() || !termPart((unsigned char)s[p + 1])))
            return false;
        return termPart((unsigned char)s[p]);
    };
    return (!at || !termPart((unsigned char)s[at - 1])) &&
           (at + length == s.size() || !joins(at + length));
}
inline std::vector<TechnicalTerm> technicalTerms(const std::string &s) {
    static constexpr std::string_view names[] = {
        "Windows",       "Linux",      "macOS",      "Android",
        "iOS",           "Ubuntu",     "Debian",     "Fedora",
        "Arch Linux",    "WSL2",       "WSL",        "Visual Studio Code",
        "Visual Studio", "VS Code",    "VSCode",     "Notepad++",
        "PowerShell",    "GitHub",     "GitLab",     "Git Bash",
        "Git",           "GCC",        "Clang",      "CMake",
        "Makefile",      "FreeRTOS",   "Zephyr",     "RT-Thread",
        "ESP-IDF",       "RISC-V",     "ARM",        "CMSIS",
        "HAL",           "LLDB",       "GDB",        "OpenOCD",
        "Python",        "JavaScript", "TypeScript", "Java",
        "Rust",          "C++",        "C#",         ".NET",
        "Node.js",       "Qt",         "Docker",     "Kubernetes",
        "Redis",         "MySQL",      "PostgreSQL", "SQLite",
        "MQTT",          "TCP/IP",     "TCP",        "UDP",
        "HTTPS",         "HTTP",       "TLS",        "SSL",
        "USB",           "UART",       "USART",      "SPI",
        "I2C",           "I2S",        "CPU",        "GPU",
        "MCU",           "SoC",        "FPGA",       "API",
        "SDK",           "IDE",        "JTAG",       "SWD",
        "DMA",           "ADC",        "DAC",        "ROM",
        "RAM",           "SRAM",       "DRAM",       "EEPROM",
        "Flash",         "SQL",        "JSON",       "XML",
        "HTML",          "CSS",        "PDF",        "UTF-8",
        "ASCII",         "STM32",      "ESP32"};
    std::vector<TechnicalTerm> out;
    if (s.size() > 4000)
        return out;
    for (size_t at = 0; at < s.size();) {
        size_t best = 0;
        for (auto name : names)
            if (name.size() > best && s.compare(at, name.size(), name.data(), name.size()) == 0 &&
                termBoundary(s, at, name.size())) {
                // Clear plural grammar points to ordinary physical/UI windows, even at a
                // sentence start. This is a conservative hint, not a general language parser.
                if (name == "Windows") {
                    auto rest = trim(s.substr(at + name.size(), 40));
                    std::transform(rest.begin(), rest.end(), rest.begin(), [](unsigned char c) {
                        return char(c >= 'A' && c <= 'Z' ? c + ('a' - 'A') : c);
                    });
                    if (rest.compare(0, 4, "are ") == 0 || rest.compare(0, 5, "were ") == 0 ||
                        rest.compare(0, 5, "have ") == 0 || rest.compare(0, 7, "let in ") == 0)
                        continue;
                }
                best = name.size();
            }
        // Restrict family recognition to known chip families, with a digit in the suffix.
        // Do not classify arbitrary ALL_CAPS, English Title Case or unknown identifiers as names.
        for (auto family : {std::string_view("STM32"), std::string_view("ESP32")}) {
            if (s.compare(at, family.size(), family.data(), family.size()) != 0)
                continue;
            size_t end = at + family.size();
            bool digit = false;
            while (end < s.size() && end - at < 40) {
                char c = s[end];
                if (!((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-'))
                    break;
                digit = digit || (c >= '0' && c <= '9');
                ++end;
            }
            if (digit && end > at + family.size() && termBoundary(s, at, end - at))
                best = std::max(best, end - at);
        }
        if (!best) {
            ++at;
            continue;
        }
        out.push_back({at, at + best});
        at += best;
    }
    return out;
}
inline std::vector<std::string> matchedTermNames(const std::string &s) {
    std::vector<std::string> names;
    for (auto m : technicalTerms(s)) {
        auto name = s.substr(m.begin, m.end - m.begin);
        if (std::find(names.begin(), names.end(), name) == names.end() && names.size() < 32)
            names.push_back(name);
    }
    return names;
}
inline bool standaloneTechnicalName(const std::string &source) {
    auto s = trim(source);
    // Allow one pair of presentation quotes, but never strip code/path fragments or a sentence.
    if (s.size() > 2 &&
        ((s.front() == '`' && s.back() == '`') || (s.front() == '"' && s.back() == '"')))
        s = s.substr(1, s.size() - 2);
    auto terms = technicalTerms(s);
    if (terms.size() != 1 || terms[0].begin != 0)
        return false;
    size_t end = terms[0].end;
    if (end == s.size())
        return true;
    // A simple version suffix: Windows 11, Python 3.12, VS Code 1.90. No prose suffix.
    if (s[end] != ' ')
        return false;
    size_t pos = end + 1;
    if (pos == s.size() || s[pos] < '0' || s[pos] > '9' || s.size() - pos > 20)
        return false;
    bool lastDigit = false;
    for (; pos < s.size(); ++pos) {
        if (s[pos] >= '0' && s[pos] <= '9')
            lastDigit = true;
        else if (s[pos] == '.' && lastDigit)
            lastDigit = false;
        else
            return false;
    }
    return lastDigit;
}
} // namespace qt
