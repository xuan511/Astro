#pragma once
#include <cstdint>
#include <functional>
#include <stdexcept>
#include <string>
#include <vector>
namespace qt {
// Scalar-only Scintilla messages. No remote buffers, code injection or full-document retrieval.
// IDs verified against the Scintilla header shipped by Notepad++ (2026-11-02).
namespace sci {
constexpr uint32_t length = 2006, character = 2007, codePage = 2137, start = 2143, end = 2145,
                   selectionMode = 2423, selections = 2570, caretVirtual = 2581,
                   anchorVirtual = 2583, nthStart = 2585, nthEnd = 2587;
}
struct SelectedSpan {
    int64_t begin = 0, end = 0;
    bool operator==(const SelectedSpan &b) const {
        return begin == b.begin && end == b.end;
    }
};
struct NativeSelection {
    std::string bytes;
    unsigned codePage = 0;
    size_t ranges = 0;
};
using ScalarQuery = std::function<int64_t(uint32_t, int64_t)>;
inline std::vector<SelectedSpan> scintillaSpans(const ScalarQuery &query) {
    const auto mode = query(sci::selectionMode, 0);
    if (mode != 0 && mode != 2)
        throw std::runtime_error("Scintilla 矩形选区暂不支持原生取词，请改用普通文本选区。");
    auto count = query(sci::selections, 0);
    if (count < 0 || count > 8)
        throw std::runtime_error("Scintilla 选区过多，请保留不超过 8 段普通选区。");
    const bool legacy = count == 0; // Older controls may not implement multiple-selection messages.
    if (legacy)
        count = 1;
    std::vector<SelectedSpan> spans;
    size_t total = 0;
    const auto length = query(sci::length, 0);
    if (length < 0)
        throw std::runtime_error("Scintilla 文本长度无效。");
    for (int64_t i = 0; i < count; ++i) {
        if (!legacy && (query(sci::caretVirtual, i) != 0 || query(sci::anchorVirtual, i) != 0))
            throw std::runtime_error("选区包含虚拟空格，请改选实际文本。");
        SelectedSpan s{query(legacy ? sci::start : sci::nthStart, legacy ? 0 : i),
                       query(legacy ? sci::end : sci::nthEnd, legacy ? 0 : i)};
        if (s.begin < 0 || s.end < s.begin || s.end > length)
            throw std::runtime_error("Scintilla 选区位置无效。");
        if (s.begin == s.end)
            continue;
        auto size = uint64_t(s.end - s.begin);
        if (size > 4000 || total + size + (spans.empty() ? 0 : 1) > 4000)
            throw std::runtime_error("选区超过 4000 字节，请缩短后重试。");
        total += size + (spans.empty() ? 0 : 1);
        spans.push_back(s);
    }
    if (spans.empty())
        throw std::runtime_error("Scintilla 没有选中文字，请先拖选英文再按快捷键。");
    return spans;
}
inline NativeSelection scintillaSelection(const ScalarQuery &query) {
    auto spans = scintillaSpans(query);
    auto cp = query(sci::codePage, 0);
    if (cp < 0 || cp > 65535)
        throw std::runtime_error("Scintilla 文本编码无效。");
    auto read = [&] {
        std::string out;
        for (auto span : spans) {
            if (!out.empty())
                out += '\n';
            for (int64_t p = span.begin; p < span.end; ++p) {
                auto c = query(sci::character, p);
                if (c < -128 || c > 255 || c == 0)
                    throw std::runtime_error("Scintilla 选区含无效字符，已停止取词。");
                out += char(static_cast<unsigned char>(c));
            }
        }
        return out;
    };
    auto bytes = read();
    // Read only the SAME selected positions a second time. Reject edits/selection changes.
    if (spans != scintillaSpans(query) || cp != query(sci::codePage, 0) || bytes != read() ||
        spans != scintillaSpans(query) || cp != query(sci::codePage, 0))
        throw std::runtime_error("取词期间选区或内容发生变化，请重新选择后重试。");
    return {bytes, (unsigned)cp, spans.size()};
}
inline bool freshCopy(uint32_t before, uint32_t after, uint32_t expectedPid, uint32_t ownerPid) {
    return after != 0 && before != after && expectedPid != 0 && expectedPid == ownerPid;
}
} // namespace qt
