# 1.8 OCR 入口

无法复制的可见英文可用托盘/译文窗口的 OCR 框选，或 Ctrl+Alt+Shift+O。它是独立的明确操作，不是原生/UIA失败后的自动截屏后备；不改变下文原有复制策略。识别先核对再翻译，详见 OCR.md。实际 Windows 框选仍待验收。

# 1.6 通用取词

本次 VS Code 截图 `focus=Chrome_WidgetWin_1; patterns=4; ranges=4; empty=4` 表示接口只返回空光标范围。1.6 在读取失败后提供可许可的通用复制，不再要求应用属于 Edit/RichEdit。

## VS Code 先这样用

1. 退出旧版托盘，再运行 **轻译 1.6**。
2. 设置 / 快捷键 → 取词方式 → **通用一键复制** → 保存并确认。通用复制是新能力，升级不会静默获得按键注入许可。
3. 回到编辑器，**实际选中文字 → 按一次翻译热键并松开**，不用先手动 Ctrl+C。
4. 需要先确认取词是否正确，可开启托盘 **仅测试取词（暂停主翻译）**，只显示取得的原文和路径，不发本次主翻译请求。确认后关闭该测试项并重新选文翻译。

## 方式和范围

| 方式 | 行为 |
| --- | --- |
| 智能取词 | Scintilla 原生 → 当前焦点 UIA 选区 → 在许可后通用复制 |
| 通用一键复制 | Scintilla 原生、已识别 Edit/RichEdit 的 WM_COPY、其他控件 Ctrl+Insert |
| 手动复制 | 自己 Ctrl+C 后按翻译热键；只读新的当前文本 |
| 指向文字 | 鼠标指向前台弹窗正文/独立文字标签，按热键；读取整个当前 UIA Text 标签 |
| 严格原生 / UIA | 不注入按键、不操作剪贴板；取不到选区就失败 |

VS Code、Office、Markdown 源码/预览、PDF 文字层和网页都有通用复制路径。**有路径不等于该软件已实测通过。** 逐项实际状态、验收条件和不支持情形见 [COMPATIBILITY-MATRIX.md](COMPATIBILITY-MATRIX.md)。

普通 Windows 弹窗正文可能不能拖选，此时选择指向文字；不会自动用 Ctrl+C 复制整个弹窗。它读取当前标签/段落，不保证只取鼠标下一个单词。扫描 PDF、图片或 Canvas 若没有文字层/辅助文字，需要 OCR，本版未提供，不能算作已支持。

## 通用复制守卫

- 仅在明确热键任务内等待原翻译热键释放；只允许初始已按下的热键/修饰键松开，出现新按键或鼠标按下取消。等待最多 1.8 秒、连续约 40ms 无键按下；没有常驻键盘钩子、按键日志或后台轮询。
- 在释放后核对前台、原生焦点、进程身份、菜单状态、辅助功能密码属性和输入时间。安全属性无法确认即不发按键。
- 查询当前前台进程镜像元数据，立即只保留文件名以排除独立终端。只用 PROCESS_QUERY_LIMITED_INFORMATION，不读文件内容或进程内存，不保存/上传完整路径。
- 只发送一个 Ctrl+Insert 按下/释放包，不改为 Ctrl+C，不发送剪切/粘贴/文本，不自动重试。部分输入插入失败时补释放已报告按下的键。
- 复制后最长等约 1.3 秒。剪贴板必须有新序号，拥有者进程必须为原前台或焦点进程；再验证前台/焦点/输入没有变化，才读取有界 CF_UNICODETEXT。来源不明、序号未变、复制失败都拒绝旧内容。
- 已知原生编辑控件有空选区、密码或超限时直接报错，不转入可能复制当前行的通用操作。

**重要的实际行为差异：** 通用复制会像手动复制一样更新当前剪贴板，系统历史/同步或其他监听软件可能记录，软件不恢复旧内容。未知编辑器的空选区语义不能可靠判断，VS Code 等可能在没有实际选区时复制当前行；请先选中文字。自定义快捷键可能改变 Ctrl+Insert 的含义，不能承诺在任意重映射/竞争输入下完全无干扰。需要完全不注入按键/不动剪贴板时选严格模式。

复制许可 `UniversalCopyAllowed` 默认关闭。选择智能/通用模式并保存确认后生效；旧手动模式继续保留。原有 API Key、模型和联网偏好不变。所有正常方式沿用最多 4000 UTF-8 字节翻译上限，剪贴板块最多扫描 4001 UTF-16 单元验证长度/NUL/代理对；取词失败不发主翻译请求。

## 原生 / UIA

Scintilla 保留只查询选区位置/编码并读取选中字节标量的路径，最多 8 段/4000 原始字节，支持 64 位偏移、UTF-8 及常见 Windows 编码；双次读取复核，矩形/虚拟空格明确拒绝。不用远程缓冲/进程内存、整篇正文或剪贴板。

UIA 只读取非退化 GetSelection；Raw View 父链最多 48 层，焦点编辑/文档子树最多 256 节点、16 层、256 次模式检查；不扫描其他分栏的旧选区。内部等待预算约 1 秒，每次调用限制按接口能力配置；主进程另有 5/8 秒看门狗。不得将这些有限检查视为编辑器事务锁。

捕获期间隐藏翻译窗，避免挡住指向位置；取得源文本或出错后再显示，不主动把焦点转给翻译窗口。系统安全桌面、UAC、密码、目标权限高于本软件或复制被应用阻止时，不提升权限或绕过限制。

## 测试的真实含义

本环境只有 Linux 便携 ASan/UBSan、Windows x64 交叉编译与静态检查。新复制策略测试没有实际向 Windows 程序注入按键。提供但未执行：

- `windows-universal-copy-smoke.ps1 -AllowInputAndClipboardChanges`：在 Windows PowerShell 5.1 下编译自己的临时通用控件 EXE，只向其发送复制组合键，检查新源文、路径和 Ctrl/Insert 释放；会更新剪贴板。它不是 VS Code/Office/PDF/浏览器实测。
- `windows-capture-smoke.ps1`：自己的 Edit/RichEdit/密码/空选区和文字标签，默认不发键或写剪贴板；显式加 `-AllowClipboardChanges` 测试原生 WM_COPY。
- `windows-scintilla-smoke.ps1 -ScintillaDll <明确指定的可信真实DLL>`：自己的长文档与真实控件，检查偏移 >65535 的 UTF-8 选区和剪贴板不变；缺 DLL/交互桌面为 SKIP，不算通过。

参考：<https://support.microsoft.com/en-gb/accessibility/windows/keyboard-shortcuts-in-windows>、<https://github.com/microsoft/vscode/blob/main/src/vs/editor/contrib/clipboard/browser/clipboard.ts>、<https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-sendinput>。
