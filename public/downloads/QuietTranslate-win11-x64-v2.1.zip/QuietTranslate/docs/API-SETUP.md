# 2.1 API 配置指南

## 保留产品名与技术缩写

默认勾选 **保留技术名称**：Windows / VS Code / API 等已识别的单独名称本地显示原文，不请求 API；整句仍正常发送，保留名称并翻译说明。Qwen-MT 使用官方 `terms` 自映射与英文 `domains`；通用 Chat 使用固定翻译指令。小写 windows、driver、memory 不按名称跳过。需要普通词义或网关不接受新增参数时，关闭并保存；不自动重试。详见 [TERMINOLOGY.md](TERMINOLOGY.md)。

## 本次与累计费用

API 配置 → **用量 / 费用**，为当前地址/模型填写输入、输出单价（每百万 Token），选择 CNY/USD，勾选估算并保存。译文下方显示本次输入/输出/总 Token 和估算金额；托盘同名入口查看本机累计和最近 2000 条明细。价格取自你的服务商控制台；没有内置实时价格，不要求提供额外账号权限。已有单价的历史使用当时快照；可为仍保留的未定价记录主动补算。

流式默认勾选**请求流式用量回传**，发送 `stream_options.include_usage=true`，读取末尾 usage；某些网关不支持该字段，可取消勾选或关闭流式后主动测试。不自动重试。没有返回用量时显示未知，无法算费用；不根据文本长度猜 Token。短句测试和词典中文补充也可能计费，均纳入统计。本地缓存新增为 0，旧版未记录用量不补录。

费用仅为估算，不含免费额度、折扣、税费和阶梯定价；实际扣款以服务商账单为准。详细字段、计价和导出说明见 [BILLING.md](BILLING.md)。

## 阿里云百炼如何填写

这里需要的是**百炼模型服务 API Key**，不是云账号 AccessKey ID/AccessKey Secret。无需将 Key 发到聊天，也不要写到源码里。

1. 设置 → API 配置，选择北京或新加坡预设。可以用控制台提供的业务空间专属 Base URL 覆盖预设。
2. Key、地址的地域必须一致。旧公共域名按官方文档仍可用，预设北京为 `https://dashscope.aliyuncs.com/compatible-mode/v1`，新加坡为 `https://dashscope-intl.aliyuncs.com/compatible-mode/v1`。
3. 官方推荐的新域名形如 `https://你的业务空间ID.cn-beijing.maas.aliyuncs.com/compatible-mode/v1`，其他地域也请直接复制控制台的完整 Base URL。不要保留 `{WorkspaceId}` 占位符，不要加 `/chat/completions`。
4. 模型先试 `qwen-mt-flash`，请求类型选 **Qwen-MT 专用翻译**。偏简单句/低成本可换 `qwen-mt-lite`。点选内置 MT 模型会同步选择专用类型；手动输入后也应核对。
5. 流式默认开，Token 上限 2048。点“短句测试（会计费）”，固定发送 `The driver requires a stable clock.`，使用当前表单和 Key，最多等待约 35 秒。
6. 测试返回供你判断；得到一个 HTTP 成功响应不等于译文一定正确。确认后“保存并启用 API”。

若使用 `qwen-flash` 等通用模型，选择 **千问通用 Chat**，请求带 `enable_thinking=false`；仅适用于支持该参数及非思考模式的模型。不能关闭思考的模型不适合此选项，可换标准 Chat，但等待和费用可能不同。模型 ID 可能对应不同版本，请以账号实际支持的 ID 为准。

## 自定义兼容平台/网关

选择自定义预设，填服务商的 HTTPS Base URL 和 Key。通常选择标准 OpenAI 兼容 Chat。模型可直接填控制台的精确 ID，如包含 `/` 的命名，也可按“获取模型列表”。获取列表只访问 `GET <Base URL>/models`，不发送你选中的原文；拿不到列表不影响手动填模型。

列表最多显示 256 个不同 ID，不代表每个都可用，不区分视觉、音频、工具或文本能力，也不自动推荐价格。请选支持文本 Chat 翻译的模型，并做短句测试。服务不支持流式时先关闭流式再测试，软件不会自动重复计费请求。

多数兼容服务使用 `max_tokens`。若服务文档要求 `max_completion_tokens`，在 Token 上限右侧切换新式参数。Qwen-MT 专用请求固定使用 `max_tokens`。这些上限不等于账户货币预算，也不保证所有思考模型的全部费用被同样限制；建议在服务商控制台设置余额/额度告警。

当前仅保存一套 API 配置。你可以随时换模型，保存会取消任务、清空旧缓存，不将旧模型译文当作新模型结果。换地址时必须重新输入 Key，空白 Key 不能沿用到新地址。仅在弹窗输入后测试/保存，不读取其他软件或环境变量中的凭据。

## 数据及费用

API 翻译把当前请求文本以 POST JSON 发给配置的地址（智能保留中文开启时，简单混合选区只提交一段英文；复杂混合选区仍提交整段），标准 Chat 另加固定翻译指令；不带整份文档、文件名、窗口标题、对话历史或学习候选词。Qwen-MT 只发原文和英→中参数。手动词典补充会单独把查询词发给 dictionaryapi.dev，再用当前引擎翻译它返回的释义与例句。

启动、打开设置和空闲不发 API 请求。只有翻译、获取列表、短句测试、已授权词典补充等明确操作联网。不会自动切模型、换服务或重试。重复点击、重试和取消后再查可能产生新用量；关闭本地进程无法承诺终止服务端计费。缓存命中时不发生成请求。

Key 保存到本软件设置中的 DPAPI 密文，仅当前 Windows 用户通常可解密；不保证同账户恶意进程无法读取。不要把设置文件视为跨机器可携带的 Key。删除 Key 同时关闭联网；删除不是系统备份或物理磁盘的安全擦除。加载失败会报错且不自动转发到其他翻译服务。

## 常见错误

| 情况 | 核对项 |
| --- | --- |
| 401/403 | 是否为百炼 API Key、地址地域是否一致、是否有业务空间/模型权限、是否开通模型 |
| 404 | Base URL 是否正确，有没有多写 `/chat/completions`，该模型/接口是否存在 |
| 400 或其他服务拒绝 | 请求类型、Token 参数名、该模型是否支持关闭思考和流式；错误信息不回显原始服务正文 |
| 429 | 控制台额度、余额、并发/速率限制；不会自动反复重试 |
| 流式 Content-Type 不兼容 | 关闭流式后再次主动测试；这会是一个新请求 |
| 达到长度上限 | 缩短原文或提高 Token 上限；截断结果未当作完整译文缓存 |
| 取词失败/原文空白 | 属于取词阶段，尚未发翻译请求；Scintilla 用原生；VS Code/Office/网页/PDF 文字层可启用通用复制；不可拖选标签用指向文字；扫描件/图片可主动框选 OCR，核对识别结果后翻译 |

## 官方参考（2026-11-02 查阅）

- 地址、兼容接口和地域：<https://help.aliyun.com/zh/model-studio/compatibility-of-openai-with-dashscope>
- Qwen-MT 请求/流式格式：<https://help.aliyun.com/zh/model-studio/qwen-mt-api>
- Qwen-MT 选型：<https://help.aliyun.com/zh/model-studio/machine-translation>
- 通用 Chat 和思考参数：<https://help.aliyun.com/zh/model-studio/qwen-api-via-openai-chat-completions>
- 价格：<https://help.aliyun.com/zh/model-studio/model-pricing>

本包不内置任何真实 Key。已验证可移植逻辑和 Windows 交叉编译；真实服务可用性、账单、延迟和本机 UI 尚待你的环境验收。

## 混合文本输入精简

“智能保留中文”默认开启，本机提取单段英文、中文原样拼回，纯中文及已识别名称/代码可不发请求。多段英文交错等复杂情况保留整段上下文；不增加请求数。不适合丢失中文上下文的歧义词可关闭。详见 USER-GUIDE.md。此开关只影响自带 Key 的主翻译，测试及词典补充不受影响。
