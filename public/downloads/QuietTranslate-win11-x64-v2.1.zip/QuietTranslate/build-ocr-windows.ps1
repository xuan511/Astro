# Run explicitly in VS 2022 x64 Native Tools developer environment with CMake and tar.
# These downloads are build-time only; the distributed app never downloads OCR models.
$ErrorActionPreference = 'Stop'
foreach ($tool in @('cl','rc','cmake','tar')) { if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) { throw "Missing build tool: $tool. Use VS 2022 x64 Native Tools with CMake." } }
$root = $PSScriptRoot
$deps = Join-Path $root 'build\ocr-deps'
$prefix = Join-Path $deps 'prefix'
New-Item -ItemType Directory -Force $deps | Out-Null
function Fetch([string]$Name,[string]$Url,[string]$Hash) {
    $path = Join-Path $deps $Name
    if (-not (Test-Path $path)) { Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $path }
    if ((Get-FileHash $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $Hash) { throw "Upstream hash mismatch: $Name. No source was built." }
    return $path
}
$tessArchive=Fetch 'tesseract.tar.gz' 'https://codeload.github.com/tesseract-ocr/tesseract/tar.gz/refs/tags/5.5.1' 'a7a3f2a7420cb6a6a94d80c24163e183cf1d2f1bed2df3bbc397c81808a57237'
$leptArchive=Fetch 'leptonica.tar.gz' 'https://codeload.github.com/DanBloomberg/leptonica/tar.gz/refs/tags/1.85.0' 'c01376bce0379d4ea4bc2ec5d5cbddaa49e2f06f88242619ab8c059e21adf233'
$model=Fetch 'eng.traineddata' 'https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/4.1.0/eng.traineddata' '7d4322bd2a7749724879683fc3912cb542f19906c83bcc1a52132556427170b2'
foreach ($archive in @($tessArchive,$leptArchive)) { & tar -xf $archive -C $deps; if ($LASTEXITCODE) { throw 'Source extraction failed' } }
$lept=Join-Path $deps 'leptonica-1.85.0'
$tess=Join-Path $deps 'tesseract-5.5.1'
$leptBuild=Join-Path $deps 'lept-build'
$tessBuild=Join-Path $deps 'tess-build'
& cmake -S $lept -B $leptBuild -A x64 "-DCMAKE_INSTALL_PREFIX=$prefix" -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded -DBUILD_SHARED_LIBS=OFF -DBUILD_PROG=OFF -DSW_BUILD=OFF -DENABLE_ZLIB=OFF -DENABLE_PNG=OFF -DENABLE_JPEG=OFF -DENABLE_GIF=OFF -DENABLE_TIFF=OFF -DENABLE_WEBP=OFF -DENABLE_OPENJPEG=OFF
if ($LASTEXITCODE) { throw 'Leptonica configure failed' }
& cmake --build $leptBuild --config Release --parallel 4
if ($LASTEXITCODE) { throw 'Leptonica build failed' }
& cmake --install $leptBuild --config Release
if ($LASTEXITCODE) { throw 'Leptonica install failed' }
& cmake -S $tess -B $tessBuild -A x64 "-DCMAKE_PREFIX_PATH=$prefix" -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded -DWIN32_MT_BUILD=ON -DBUILD_SHARED_LIBS=OFF -DSW_BUILD=OFF -DBUILD_TRAINING_TOOLS=OFF -DBUILD_TESTS=OFF -DOPENMP_BUILD=OFF -DGRAPHICS_DISABLED=ON -DDISABLED_LEGACY_ENGINE=ON -DENABLE_NATIVE=OFF -DDISABLE_TIFF=ON -DDISABLE_ARCHIVE=ON -DDISABLE_CURL=ON -DINSTALL_CONFIGS=OFF
if ($LASTEXITCODE) { throw 'Tesseract configure failed' }
& cmake --build $tessBuild --config Release --target libtesseract --parallel 4
if ($LASTEXITCODE) { throw 'Tesseract build failed' }
$leptLib = @(Get-ChildItem (Join-Path $prefix 'lib') -Filter '*leptonica*.lib')
$tessLib = @(Get-ChildItem $tessBuild -Recurse -Filter '*tesseract*.lib' | Where-Object { $_.FullName -match 'Release' })
if ($leptLib.Count -ne 1 -or $tessLib.Count -ne 1) { throw 'Expected one static release library per dependency' }
Push-Location $root
try {
    & rc /nologo /c 65001 /fo build\app-ocr.res app-ocr.rc
    if ($LASTEXITCODE) { throw 'OCR resource compilation failed' }
    & cl /nologo /std:c++17 /EHsc /utf-8 /O2 /W4 /MT "/I$tess\include" "/I$tessBuild\include" /Fobuild\ocr_worker.obj src\ocr_worker.cpp build\app-ocr.res $tessLib[0].FullName $leptLib[0].FullName /Febuild\QuietTranslate.OCR.exe /link /SUBSYSTEM:WINDOWS /MANIFEST:NO /DYNAMICBASE /NXCOMPAT /HIGHENTROPYVA user32.lib gdi32.lib shell32.lib crypt32.lib dwmapi.lib
    if ($LASTEXITCODE) { throw 'OCR helper compilation failed' }
    New-Item -ItemType Directory -Force build\ocr-data | Out-Null
    Copy-Item $model build\ocr-data\eng.traineddata -Force
} finally { Pop-Location }
Write-Output 'Built build\QuietTranslate.OCR.exe and build\ocr-data\eng.traineddata. No runtime model download is needed.'
